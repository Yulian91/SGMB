$(document).ready(function () {
  var funcion = ''; /** Declarar e inicializar la variable funcion */
  buscar_datos(); /** Inicializar la función buscar datos */
  select_cliente(); /** Inicializar la función seleccionar el cliente */
  select_pais(); /** Inicializar la función seleccionar el pais */
  select_ciudad(); /** Inicializar la función seleccionar la ciudad */
  select_sede(); /** Inicializar la función seleccionar la sede */
  select_area(); /** Inicializar la función seleccionar el area */
  edit_cliente(); /** Inicializar la función editar los datos del cliente */
  edit_pais(); /** Inicializar la función editar los datos del pais */
  edit_ciudad(); /** Inicializar la función editar los datos de la ciudad */
  edit_sede(); /** Inicializar la función editar los datos de la sede */
  edit_area(); /** Inicializar la función editar los datos del area */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE DEL CLIENTE AL CUAL SE LE ASIGNARA EL EQUIPO.
   * @param {String} response = Este parametro trae el id del cliente y el nombre del cliente registrado en la base de datos.
  */
  function select_cliente() {
    funcion = 'select_cliente';
    $.post('../../Controllers/control_cliente.php', { funcion }, (response) => {
      const clientes = JSON.parse(response);
      let template = '';
      clientes.forEach(cliente => {
        template += `
                <option value="${cliente.id}">${cliente.nombre} </option>
            `;
      })
      $('#cliente').html(template);
    });
  }
  // FIN FUNCIÓN SELECCIONAR CLIENTE

   /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE DEL CLIENTE EL CUAL SE REQUIERE MODIFICAR.
   * @param {String} response = Este parametro trae todos el id y el nombre del cliente el cual se requiere modificar.
  */
  function edit_cliente() {
    funcion = 'select_cliente';
    $.post('../../Controllers/control_cliente.php', { funcion }, (response) => {
      const clientes = JSON.parse(response);
      let template = '';
      clientes.forEach(cliente => {
        template += `
                <option value="${cliente.id}">${cliente.nombre} </option>
            `;
      })
      $('#cliente_edit').html(template);
    });
  }
  // FIN FUNCIÓN EDITAR CLIENTE

  /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE DEL PAIS DONDE QUEDARA INSTALADO EL EQUIPO.
   * @param {String} response = Este parametro trae el id y el nombre del pais registrados en la base de datos.
  */
  function select_pais() {
    funcion = 'select_pais';
    $.post('../../Controllers/control_pais.php', { funcion }, (response) => {
      const paises = JSON.parse(response);
      let template = '';
      paises.forEach(pais => {
        template += `
                      <option value="${pais.id_pais}">${pais.nombre_pais}</option>
              `;
      })
      $('#pais').html(template);
    });
  }
  // FIN FUNCIÓN SELECCIONAR PAIS

  /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE EL CUAL SE REQUIERE MODIFICAR.
   * @param {String} response = Este parametro trae el id y el nombre del pais el cual se requiere modificar.
  */
  function edit_pais() {
    funcion = 'select_pais';
    $.post('../../Controllers/control_pais.php', { funcion }, (response) => {
      const paises = JSON.parse(response);
      let template = '';
      paises.forEach(pais => {
        template += `
                      <option value="${pais.id_pais}">${pais.nombre_pais}</option>
              `;
      })
      $('#pais_edit').html(template);
    });
  }
  // FIN FUNCIÓN EDITAR PAIS

  /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE DE LA CIUDAD DONDE QUEDARA INSTALADO EL EQUIPO..
   * @param {String} response = Este parametro trae el id y el nombre de la ciudad registrados en la base de datos.
  */
  function select_ciudad() {
    funcion = 'select_ciudad';
    $.post('../../Controllers/control_ciudad.php', { funcion }, (response) => {
      const ciudades = JSON.parse(response);
      let template = '';
      ciudades.forEach(ciudad => {
        template += `
                      <option value="${ciudad.id_ciudad}">${ciudad.nombre_ciudad}</option>
              `;
      })
      $('#ciudad').html(template);
    });
  }
  // FIN FUNCIÓN SELECCIONAR CIUDAD

  /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE DE LA CIUDAD LA CUAL SE REQUIERE MODIFICAR.
   * @param {String} response = Este parametro trae el id y el nombre de la ciudad la cual se requiere modificar.
  */
  function edit_ciudad() {
    funcion = 'select_ciudad';
    $.post('../../Controllers/control_ciudad.php', { funcion }, (response) => {
      const ciudades = JSON.parse(response);
      let template = '';
      ciudades.forEach(ciudad => {
        template += `
                      <option value="${ciudad.id_ciudad}">${ciudad.nombre_ciudad}</option>
              `;
      })
      $('#ciudad_edit').html(template);
    });
  }
  // FIN FUNCIÓN EDITAR CIUDAD

  /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE DE LA SEDE DONDE QUEDARA INSTALADO EL EQUIPO..
   * @param {String} response = Este parametro trae todos el id y el nombre de la sede registradas en la base de datos.
  */
  function select_sede() {
    funcion = 'select_sede';
    $.post('../../Controllers/control_sede.php', { funcion }, (response) => {
      const sedes = JSON.parse(response);
      let template = '';
      sedes.forEach(sede => {
        template += `
                      <option value="${sede.id_sede}">${sede.nombre_sede}</option>
              `;
      })
      $('#sede').html(template);
    });
  }
  // FIN FUNCIÓN SELECCIONAR SEDE

  /**
   * FUNCIÓN PARA SELECCIONAR EL NOMBRE DEL CLIENTE LA CUAL SE REQUIERE MODIFICAR.
   * @param {String} response = Este parametro trae el id y el nombre de la sede la cual se requiere modificar.
  */
  function edit_sede() {
    funcion = 'select_sede';
    $.post('../../Controllers/control_sede.php', { funcion }, (response) => {
      const sedes = JSON.parse(response);
      let template = '';
      sedes.forEach(sede => {
        template += `
                      <option value="${sede.id_sede}">${sede.nombre_sede}</option>
              `;
      })
      $('#sede_edit').html(template);
    });
  }
  // FIN FUNCIÓN EDITAR SEDE

  /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE DEL AREA DE SERVICIO DONDE QUEDARA INSTALADO EL EQUIPO..
   * @param {String} response = Este parametro trae el id y el nombre de la areas de servicio registradas en la base de datos.
  */
  function select_area() {
    funcion = 'select_area';
    $.post('../../Controllers/control_area.php', { funcion }, (response) => {
      const areas = JSON.parse(response);
      let template = '';
      areas.forEach(area => {
        template += `
                      <option value="${area.id_area}">${area.nombre_area}</option>
              `;
      })
      $('#area').html(template);
    });
  }
  // FIN FUNCIÓN SELECCIONAR AREA

  /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE DEL AREA DE SERVICIO LA CUAL SE REQUIERE MODIFICAR.
   * @param {String} response = Este parametro trae el id y el nombre de las areas la cual se requiere modificar.
  */
  function edit_area() {
    funcion = 'select_area';
    $.post('../../Controllers/control_area.php', { funcion }, (response) => {
      const areas = JSON.parse(response);
      let template = '';
      areas.forEach(area => {
        template += `
                      <option value="${area.id_area}">${area.nombre_area}</option>
              `;
      })
      $('#area_edit').html(template);
    });
  }
  // FIN FUNCIÓN EDITAR AREA

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR LOS DATOS DEL EQUIPO EN EL INVENTARIO.
   * @param {string} id_equipo = Obtiene el dato del id del equipo. Este dato lo envia el input=equipo del formulario crear inventario.
   * @param {string} frecuencia_mtto = Obtiene el dato de la frecuencia de matto del equipo. Este dato lo envia el input=frecuencia_matto del formulario crear inventario.
   * @param {string} fijo_movil = Obtiene el dato si el equipo es fijo o movil. Este dato lo envia el input=fijo_movil del formulario crear inventario.
   * @param {string} cliente = Obtiene el dato del cliente al cual se asignara el equipo. Este dato lo envia el input=cliente del formulario crear inventario.
   * @param {string} pais = Obtiene el dato del pais donde quedara instalado el equipo. Este dato lo envia el input=pais del formulario crear inventario.
   * @param {string} ciudad = Obtiene el dato de la ciudad donde quedara instalado el equipo. Este dato lo envia el input=ciudad del formulario crear inventario.
   * @param {string} sede = Obtiene el dato de la sede donde quedara instalado el equipo. Este dato lo envia el input=sede del formulario crear inventario.
   * @param {string} area = Obtiene el dato del area de servicio donde quedara instalado el equipo. Este dato lo envia el input=area del formulario crear inventario.
   */
  $('#form-crear-inventario').submit(e => {
    let id_equipo = $('#equipo').val();
    let frecuencia_mtto = $('#frecuencia_matto').val();
    let fijo_movil = $('#fijo_movil').val();
    let cliente = $('#cliente').val();
    let pais = $('#pais').val();
    let ciudad = $('#ciudad').val();
    let sede = $('#sede').val();
    let area = $('#area').val();

    funcion = 'crear_inventario';
    $.post('../../Controllers/control_inventario.php', { id_equipo, frecuencia_mtto, fijo_movil, cliente, pais, ciudad, sede, area, funcion }, (response1) => {
      if (response1 == 'add') {
        funcion = 'arrendar';
        $.post('../../Controllers/control_equipo.php', { id_equipo, funcion }, (response2) => {
          if (response2 == 'arrendado') {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: 'El equipo ' + id_equipo + ' se agrego a un contrato de arriendo y/o matto correctamente.',
              showConfirmButton: false,
              timer: 1500
            })
            $('#form-crear-inventario').trigger('reset');
            buscar_datos();
          }
        });

      }
      else {
        Swal.fire(
          '¡No fue arrendado o agregado a un contrato de matto!',
          'El equipo ' + id_equipo + ' ya se encuentra arrendado o en un contrato de mantenimiento.',
          'error'
        )
        $('#form-crear-inventario').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA EDITAR LOS DATOS DEL EQUIPO EN EL INVENTARIO.
   * @param {string} id_equipo = Obtiene el dato del id del equipo el cual se requiere modificar.
   * @param {string} frecuencia_mtto = Obtiene el dato de la frecuencia de matto del equipo el cual se requiere modificar.
   * @param {string} fijo_movil = Obtiene el dato si el equipo es fijo o movil el cual se requiere modificar.
   * @param {string} cliente = Obtiene el dato del cliente al cual se asigno el equipo el cual se requiere modificar.
   * @param {string} pais = Obtiene el dato del pais donde quedara instalado el equipo el cual se requiere modificar.
   * @param {string} ciudad = Obtiene el dato de la ciudad donde quedara instalado el equipo el cual se requiere modificar.
   * @param {string} sede = Obtiene el dato de la sede donde quedara instalado el equipo el cual se requiere modificar.
   * @param {string} area = Obtiene el dato del area de servicio donde quedara instalado el equipo el cual se requiere modificar.
   */
  $('#form-editar-inventario').submit(e => {
    let id_editado = $('#editar_invent').val();
    let equipo = $('#id_equipo').val();
    let frecuencia_mtto = $('#frec_matto_edit').val();
    let fijo_movil = $('#fijo_movil_edit').val();
    let cliente = $('#cliente_edit').val();
    let pais = $('#pais_edit').val();
    let ciudad = $('#ciudad_edit').val();
    let sede = $('#sede_edit').val();
    let area = $('#area_edit').val();

    funcion = 'editar';
    $.post('../../Controllers/control_inventario.php', { id_editado, equipo, frecuencia_mtto, fijo_movil, cliente, pais, ciudad, sede, area, funcion }, (response) => {
      if (response == 'edit') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del equipo fueron ' + equipo + ' actualizados correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-inventario').trigger('reset');
        buscar_datos();
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS DATOS DE LOS EQUIPOS.
   * @param {String} consulta = Este parametro trae todos los datoss de los equipos registradas en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_inventario';
    $.post('../../Controllers/control_inventario.php', { consulta, funcion }, (response) => {
      const inventarios = JSON.parse(response);
      let template = '';
      inventarios.forEach(inventario => {
        template += `
          <tr id_inv="${inventario.id_inventario}" nombre_equipo=${inventario.nombre_equipo} marca="${inventario.marca}" no_activo="${inventario.no_activo}" equipo="${inventario.id_equipo}" frecuencia="${inventario.frecuencia}"  fijomovil="${inventario.fijo_movil}"
            cliente="${inventario.id_cliente}" pais="${inventario.id_pais}" ciudad="${inventario.id_ciudad}" sede="${inventario.id_sede}" area="${inventario.id_area}">
            <td>${inventario.id_inventario}</td>
            <td>${inventario.nombre_equipo}</td>
            <td>${inventario.marca}</td>
            <td>${inventario.modelo}</td>
            <td>${inventario.serie}</td>
            <td>${inventario.frecuencia}</td>
            <td>${inventario.nombre_cliente}</td>
            <td>${inventario.ciudad}</td>
            <td>${inventario.sede}</td>
            <td>${inventario.area}</td>
            <td>
              <button class="editar btn btn-primary" title="Editar los datos del equipo en contrato" type="button" data-toggle="modal" data-target="#editar_inventario">
                <i class="fas fa-pencil-alt"></i>
              </button>
              <a class="btn btn-warning" href="../Admin/Cronograma.php?id_inv=${inventario.id_inventario}&equipo=${inventario.nombre_equipo}&marca=${inventario.marca}" title="Agendar mantenimiento">
                <i class="fas fa-calendar-check"></i>
              </a>
              <button class="eliminar_inv btn btn-danger" title="Retirar el equipo del contrato">
                <i class="fas fa-times"></i>
              </button>
            </td>
          </tr>
        `;
      })
      $('#datos_inventario').html(template); /** Proyectar el listado de todos los datos de los equipos en la tabla. */
    });
  }
  // FIN FUNCIÓN BUSCAR DATOS

  /**
   * EVENTO BUSCAR, AL PRESIONAR DENTRO DEL BUSCADOR SE EJECUTA LA FUNCIÓN BUSCAR.
   * EL CUAL BUSCA POR UN DATO ESPECIFICO DE UN EQUIPO.
  */
  $(document).on('keyup', '#buscar_inventario', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });
  // FIN EVENTO BUSCAR

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DEL EQUIPO SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE LOS DATOS DEL EQUIPO REGISTRADOS EN LA BD PARA MODIFICAR.
   */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_inv');
    const equipo = $(elemento).attr('equipo');
    const nombre = $(elemento).attr('nombre_equipo');
    const marca = $(elemento).attr('marca');
    const frecuencia_mtto = $(elemento).attr('frecuencia');
    const fijo_movil = $(elemento).attr('fijomovil');
    const cliente = $(elemento).attr('cliente');
    const pais = $(elemento).attr('pais');
    const ciudad = $(elemento).attr('ciudad');
    const sede = $(elemento).attr('sede');
    const area = $(elemento).attr('area');
    $('#editar_invent').val(id);
    $('#id_equipo').val(equipo);
    $('#equipo_edit').val(nombre + ' ' + marca);
    $('#frec_matto_edit').val(frecuencia_mtto);
    $('#fijo_movil_edit').val(fijo_movil);
    $('#cliente').val(cliente);
    $('#pais').val(pais);
    $('#ciudad').val(ciudad);
    $('#sede').val(sede);
    $('#area').val(area);
  });
  // FIN EVENTO CLICK

  /**
  * EVENTO CLICK, AL PRESIONAR EL BOTON ELIMINAR LOS DATOS DEL EQUIPO DE LA TABLA INVENTARIO DE EQUIPOS SE EJECUTA EL EVENTO ELIMINAR.
  * EL CUAL BORRA LOS DATOS DEL EQUIPO REGISTRADO EN LA BASE DE DATOS.
  */
  $(document).on('click', '.eliminar_inv', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id_inv = $(elemento).attr('id_inv');
    const id = $(elemento).attr('equipo');

    Swal.fire({
      title: '¿Desea retirar el equipo del contrato arrndo o matto?',
      text: "¡El equipo saldra del contrato y retornara al stock del inventario de equipos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        funcion = "eliminar_inv";
        $.post('../../Controllers/control_inventario.php', { id_inv, funcion }, (response) => {
          if (response == 'delete') {
            funcion = "no_arrendar";
            $.post('../../Controllers/control_equipo.php', { id, funcion }, (response2) => {
              if (response2 == 'stock') {
                Swal.fire(
                  'Borrado!',
                  'El equipo fue retirado del contrato y se retorno al stock.',
                  'success'
                )
              }
              else {
                alert('NO ES POSIBLE ELIMINAR EL EQUIPO DEL INVENTARIO')
              }
            });
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue retirado!',
              'El equipo no fue retirado del contrato arriendo o matto.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR EQUIPO SE EJECUTA EL EVENTO BTN_LIMPIAR.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar', (e) => {
    $('#form-editar-inventario').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON RETIRAR EL EQUIPO DEL CONTRATO SE EJECUTA EL EVENTO BTN_NO_ARRENDAR.
   * EL CUAL DEVUELVE EL EQUIPO EN ESTADO ARRENDADO A STOCK.
   */
  $(document).on('click', '#btn_no_arrendar', (e) => {
    $('#form-crear-inventario').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

})