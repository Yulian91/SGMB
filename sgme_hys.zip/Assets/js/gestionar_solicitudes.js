$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  var edit = false; /** Declarar e iniciar la variable edit en falso */
  buscar_datos(); /** Inicializar la funcion buscar datos */
  select_inventario(); /** Inicializar la función seleccionar un equipo del inventario */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA SELECCIONAR LOS DATOS DEL EQUIPO AL CUAL SE LE REALIZARA LA SOLICITUD.
   * @param {String} response = Este parametro trae el id, nombre, marca, serie del equipo registrado en la base de datos.
  */
  function select_inventario() {
    funcion = 'select_inventario';
    $.post('/sgme_hys/Controllers/control_inventario.php', { funcion }, (response) => {
      const inventarios = JSON.parse(response);
      let template = '';
      inventarios.forEach(inventario => {
        template += `
                <option value="${inventario.id}">${inventario.nombre_equipo} / ${inventario.marca} / ${inventario.serie}</option>
            `;
      })
      $('#equipo').html(template);
    });
  }
  // FIN FUNCIÓN SELECCIONAR EQUIPO DEL INVENTARIO

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR LOS DATOS DEL EQUIPO.
   * @param {string} id_solicitud = Obtiene el dato del id de la solicitud. Este dato lo envia el input=id_solicitud del formulario crear solicitud.
   * @param {string} inventario = Obtiene el dato del equipo del inventario. Este dato lo envia el input=equipo del formulario crear solicitud.
   * @param {string} tipo = Obtiene el dato del tipo de solicitud que se realizara. Este dato lo envia el input=tipo del formulario crear solicitud.
   * @param {string} prioridad = Obtiene el dato de la prioridad de la solicitud. Este dato lo envia el input=prioridad del formulario crear solicitud.
   * @param {string} usuario = Obtiene el dato del usuario quien realiza la solicitud. Este dato lo envia el input=usuario del formulario crear solicitud.
   * @param {string} motivo = Obtiene el dato del motivo por el cual se realiza la solicitud. Este dato lo envia el input=motivo_solicitud del formulario crear solicitud.
   */
  $('#form-crear-solicitud').submit(e => {
    let id_solicitud = $('#id_solicitud').val();
    let inventario = $('#equipo').val();
    let tipo = $('#tipo').val();
    let prioridad = $('#prioridad').val();
    let usuario = $('#usuario').val();
    let motivo = $('#motivo_solicitud').val();

    if (edit == false) {
      funcion = 'crear_solicitud';
    } else {
      funcion = 'editar_solicitud';
    }

    $.post('/sgme_hys/Controllers/control_solicitud.php', { id_solicitud, inventario, tipo, prioridad, usuario, motivo, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'La solicitud fue registrada correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-solicitud').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          '¡No fue registrada!',
          'No fue posible registrar la solicitud.',
          'error'
        )
      }
      if (response == 'edit') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos de la solicitud Nro ' + id_solicitud + ' fueron actualizados correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-solicitud').trigger('reset');
        buscar_datos();
      }
      edit = false;
    })
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS DATOS DE LAS SOLICITUDES .
   * @param {String} consulta = Este parametro trae todos los datos de la solicitudes registradas en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_solicitud';
    $.post('/sgme_hys/Controllers/control_solicitud.php', { consulta, funcion }, (response) => {
      const solicitudes = JSON.parse(response);
      let template = '';
      solicitudes.forEach(solicitud => {
        template += `
          <tr id_solicitud="${solicitud.id_solicitud}" inventario="${solicitud.id_inventario}" f_solicitud="${solicitud.fecha_solicitud}" equipo="${solicitud.nombre_equipo}" 
            tipo="${solicitud.tipo_solicitud}"tipo="${solicitud.tipo_solicitud}" prioridad="${solicitud.prioridad}" usuario="${solicitud.usuario_cliente}" motivo="${solicitud.motivo}" >
            <td>${solicitud.id_solicitud}</td>
            <td>${solicitud.fecha_solicitud}</td>
            <td>${solicitud.nombre_equipo}</td>
            <td>${solicitud.nombre_cliente}</td>
            <td>${solicitud.usuario_cliente}</td>
            <td>${solicitud.tipo_solicitud}</td>
            <td>${solicitud.prioridad}</td>
            <td>${solicitud.motivo}</td>
            <div class="text-right">`;
            if (solicitud.id_tipo_sesion == 1) {
              if (solicitud.estatus_sol == 'PENDIENTE') {
                template += `
                        <td><h1 class="badge badge-info">${solicitud.estatus_sol}</h1></td>
                        <td>
                          <button class="editar btn btn-primary" title="Editar los datos de la solicitud" type="button" data-toggle="modal" data-target="#crear_solicitud">
                            <i class="fas fa-pencil-alt"></i>
                          </button>
                          <a class="estado_proceso btn btn-info" href="../Admin/Cronograma.php?id_inv=${solicitud.id_inventario}&equipo=${solicitud.nombre_equipo}&marca=${solicitud.marca_equipo}" title="Agendar solicitud de servicio">
                            <i class="fas fa-calendar-check"></i>
                          </a>
                          <button class="estado_cancelar btn btn-danger" title="Cancelar la solicitud de servicio">
                            <i class="fas fa-times"></i>
                          </button>
                        </td>
                      `;
              }
              if (solicitud.estatus_sol == 'PROCESO') {
                template += `
                        <td><h1 class="badge badge-success">${solicitud.estatus_sol}</h1></td>
                        <td>
                          <button class="estado_cerrado btn btn-danger" title="Finalizar la solicitud de servicio">
                            <i class="fas fa-times"></i>
                          </button>
                          <button class="estado_reactivar btn btn-info" title="Reactivar la solicitud de servicio">
                            <i class="fas fa-file-import"></i>
                          </button>
                        </td>
                      `;
              }
              if (solicitud.estatus_sol == 'CANCELADO') {
                template += `
                        <td><h1 class="badge badge-danger">${solicitud.estatus_sol}</h1></td>
                        <td>
                          <button class="eliminar btn btn-danger" title="Eliminar la solicitud de servicio">
                            <i class="fas fa-trash-alt"></i>
                          </button>
                        </td>
                      `;
              }
              if (solicitud.estatus_sol == 'FINALIZADO') {
                template += `
                        <td><h1 class="badge badge-danger">${solicitud.estatus_sol}</h1></td>
                        <td>
                          <button class="eliminar btn btn-danger" title="Eliminar la solicitud de servicio">
                            <i class="fas fa-trash-alt"></i>
                          </button>
                        </td>
                      `;
              }
            } else if (solicitud.id_tipo_sesion == 2) {
              if (solicitud.estatus_sol == 'PENDIENTE') {
                template += `
                        <td><h1 class="badge badge-info">${solicitud.estatus_sol}</h1></td>
                        <td>
                          <button class="editar btn btn-primary" title="Editar los datos de la solicitud" type="button" data-toggle="modal" data-target="#crear_solicitud">
                            <i class="fas fa-pencil-alt"></i>
                          </button>
                          <a class="estado_proceso btn btn-info" href="../Admin/Cronograma.php?id_inv=${solicitud.id_inventario}&equipo=${solicitud.nombre_equipo}&marca=${solicitud.marca_equipo}" title="Agendar solicitud de servicio">
                            <i class="fas fa-calendar-check"></i>
                          </a>
                          <button class="estado_cancelar btn btn-danger" title="Cancelar la solicitud de servicio">
                            <i class="fas fa-times"></i>
                          </button>
                        </td>
                      `;
              }
              if (solicitud.estatus_sol == 'PROCESO') {
                template += `
                        <td><h1 class="badge badge-success">${solicitud.estatus_sol}</h1></td>
                        <td>
                          <button class="estado_cerrado btn btn-danger" title="Finalizar la solicitud de servicio">
                            <i class="fas fa-times"></i>
                          </button>
                          <button class="estado_reactivar btn btn-info" title="Reactivar la solicitud de servicio">
                            <i class="fas fa-file-import"></i>
                          </button>
                        </td>
                      `;
              }
              if (solicitud.estatus_sol == 'CANCELADO') {
                template += `
                        <td><h1 class="badge badge-danger">${solicitud.estatus_sol}</h1></td>
                        <td>
                          <button class="eliminar btn btn-danger" title="Eliminar la solicitud de servicio">
                            <i class="fas fa-trash-alt"></i>
                          </button>
                        </td>
                      `;
              }
              if (solicitud.estatus_sol == 'FINALIZADO') {
                template += `
                        <td><h1 class="badge badge-danger">${solicitud.estatus_sol}</h1></td>
                        <td>
                          <button class="eliminar btn btn-danger" title="Eliminar la solicitud de servicio">
                            <i class="fas fa-trash-alt"></i>
                          </button>
                        </td>
                      `;
              }
            } else if (solicitud.id_tipo_sesion == 3) {
              if (solicitud.estatus_sol == 'PENDIENTE') {
                template += `
                        <td><h1 class="badge badge-info">${solicitud.estatus_sol}</h1></td>
                        <td>
                          <button class="editar btn btn-primary" title="Editar los datos de la solicitud" type="button" data-toggle="modal" data-target="#crear_solicitud">
                            <i class="fas fa-pencil-alt"></i>
                          </button>
                          <a class="estado_proceso btn btn-info" href="../Admin/Cronograma.php?id_inv=${solicitud.id_inventario}&equipo=${solicitud.nombre_equipo}&marca=${solicitud.marca_equipo}" title="Agendar solicitud de servicio">
                            <i class="fas fa-calendar-check"></i>
                          </a>
                          <button class="estado_cancelar btn btn-danger" title="Cancelar la solicitud de servicio">
                            <i class="fas fa-times"></i>
                          </button>
                        </td>
                      `;
              }
            } else if (solicitud.id_tipo_sesion == 4) {
              if (solicitud.estatus_sol == 'PENDIENTE') {
                template += `
                        <td><h1 class="badge badge-info">${solicitud.estatus_sol}</h1></td>
                        
                      `;
              }
              if (solicitud.estatus_sol == 'PROCESO') {
                template += `
                        <td><h1 class="badge badge-success">${solicitud.estatus_sol}</h1></td>
                        
                      `;
              }
              if (solicitud.estatus_sol == 'CANCELADO') {
                template += `
                        <td><h1 class="badge badge-danger">${solicitud.estatus_sol}</h1></td>
                        
                      `;
              }
              if (solicitud.estatus_sol == 'FINALIZADO') {
                template += `
                        <td><h1 class="badge badge-danger">${solicitud.estatus_sol}</h1></td>
                        
                      `;
              }
            }
        template += `
            </div>
          </tr>
        `;
      })
      $('#solicitudes').html(template); /** Proyectar el listado de todos los datos de las solicitudes en la tabla. */
    });
  }
  // FIN FUNCION BUSCAR DATOS

  /**
   * EVENTO BUSCAR, AL PRESIONAR DENTRO DEL BUSCADOR EJECUTA LA FUNCIÓN BUSCAR.
   * EL CUAL BUSCA POR UN DATO ESPECIFICO DE UNA SOLICITUD.
  */
  $(document).on('keyup', '#buscar_solicitudes', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });
  // FIN EVENTO CLICK

   /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON RETIRAR EL EQUIPO DEL CONTRATO A/M DE LA TABLA INVENTARIO EQUIPO SE EJECUTA EL EVENTO NO ARRENDAR.
   * EL CUAL RETIRA EL EQUIPO DEL CONTRATO ASIGNADO Y SE PODRA REALIZAR LAS OPCIONES DE EDITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.estado_proceso', (e) => {
    funcion = "estado_proceso";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_solicitud');
    const inventario = $(elemento).attr('inventario');

    $.post('../../Controllers/control_solicitud.php', { id, inventario, funcion }, (response) => {
      if (response == 'proceso') {
        buscar_datos();
      } else {
        alert('ERROR');
      }
    });
  });
  // FIN EVENTO CLICK

   /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON REACTIVAR LA SOLICITUD DE LA TABLA GESTIONAR SOLICITUDES SE EJECUTA EL EVENTO ESTADO_REACTIVAR.
   * EL CUAL REACTIVA LA SOLICITUD DE SERVICIO Y SE PODRA REALIZAR LAS OPCIONES DE EDITAR, BORRAR, CANCELAR, ENTRE OTRAS.
   */
  $(document).on('click', '.estado_reactivar', (e) => {
    funcion = "estado_reactivar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_solicitud');
    const inventario = $(elemento).attr('inventario');

    $.post('../../Controllers/control_solicitud.php', { id, inventario, funcion }, (response) => {
      if (response == 'reactivar') {
        buscar_datos();
      } else {
        alert('ERROR');
      }
    });
  });
  // FIN EVENTO CLICK

   /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR LA SOLICITUD DE LA TABLA GESTIONAR SOLICITUDES SE EJECUTA EL EVENTO ESTADO_CANCELAR.
   * EL CUAL CANCELA LA SOLICITUD DE SERVICIO Y SE PODRA ELIMINAR DICHA SOLICITUD.
   */
  $(document).on('click', '.estado_cancelar', (e) => {
    funcion = "cancelar_solicitud";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_solicitud');
    const inventario = $(elemento).attr('inventario');

    Swal.fire({
      title: '¿Desea cancelar la solicitud de servicio Nro ' + id + '?',
      text: "¡Se cancelara la solicitud de servicio pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_solicitud.php', { id, inventario, funcion }, (response) => {
          if (response == 'cancelado') {
            Swal.fire(
              'Solicitud Cancelada!',
              'La solicitud de servicio # ' + id + ' fue cancelada.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue cancelada!',
              'No fue posible cancelar la solicitud # ' + id_solicitud + ' de servicio.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

   /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CERRAR SOLICITUD DE LA TABLA GESTIONAR SOLICITUD SE EJECUTA EL EVENTO ESTADO_CERRADO.
   * EL CUAL CIERRA LA SOLICITUD DE SERVICIO Y SE .
   */
  $(document).on('click', '.estado_cerrado', (e) => {
    funcion = "estado_cerrado";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_solicitud');
    const inventario = $(elemento).attr('inventario');

    Swal.fire({
      title: '¿Desea finalizar la solicitud de servicio?',
      text: "¡La solicitud de servicio sera finalizada, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('/sgme_hys/Controllers/control_solicitud.php', { id, inventario, funcion }, (response) => {
          if (response == 'cerrado') {
            Swal.fire(
              '¡Solicitud Finalizada!',
              'La solicitud de servicio # ' + id + ' fue finalizada.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue finalizada!',
              'La solicitud de servicio # ' + id + ' no fue finalizada.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON BORRAR LOS DATOS DE LA SOLICITUD DE LA TABLA GESTIONAR SALICITUDES SE EJECUTA EL EVENTO ELIMINAR.
   * EL CUAL BORRARA LOS DATOS DE LA SOLICITUD REGISTRADA EN LA BASE DE DATOS.
   */
  $(document).on('click', '.eliminar', (e) => {
    funcion = "eliminar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_solicitud');

    Swal.fire({
      title: '¿Desea eliminar los datos de la solicitud # ' + id + '?',
      text: "¡Los datos de la solicitud se eliminaran de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_solicitud.php', { id, funcion }, (response) => {
          edit = false;
          if (response == 'delete') {
            Swal.fire(
              'Borrado!',
              'Los datos de la solicitud Nro ' + id_solicitud + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue borrado!',
              'Los datos de la solicitud Nro ' + id_solicitud + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DE LA SOLICITUD SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE LOS DATOS DE LA SOLICITUD REGISTRADO EN LA BD PARA MODIFICAR.
   */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_solicitud');
    const inventario = $(elemento).attr('inventario');
    const usuario_cli = $(elemento).attr('usuario');
    const tipo_solicitud = $(elemento).attr('tipo');
    const prioridad = $(elemento).attr('prioridad');
    const motivo = $(elemento).attr('motivo');
    $('#id_solicitud').val(id);
    $('#equipo').val(inventario);
    $('#usuario').val(usuario_cli);
    $('#tipo').val(tipo_solicitud);
    $('#prioridad').val(prioridad);
    $('#motivo_solicitud').val(motivo);
    edit = true;
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR SOLICITUD SE EJECUTA EL EVENTO BTN_LIMPIAR.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar', (e) => {
    $('#form-crear-solicitud').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

})

/**
  * FUNCIÓN PARA SELECCIONAR OTRO SERVICIO EN EL FORMULARIO CREAR SOLICITUDES.
  * @param {String} id = Este parametro envia el id del otro servicio a la base de datos.
*/
function otro_servicio(id) {
  if (id == "0") {
    $("#otro_tipo_solicitud").show();
  } else {
    $("#otro_tipo_solicitud").hide();
  }
}
// FIN FUNCIÓN SELECCIONAR OTRO SERVICIO