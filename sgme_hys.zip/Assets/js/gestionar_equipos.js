$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  buscar_datos(); /** Inicializar la funcion buscar datos */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          /** Inicializar la función cargar datos desde el servidor */
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR LOS DATOS DEL EQUIPO.
   * @param {string} nombre_equipo = Obtiene el dato del nombre del equipo. Este dato lo envia el input=equipo del formulario crear equipo.
   * @param {string} n_activo = Obtiene el dato del numero de activo del equipo. Este dato lo envia el input=n_activo del formulario crear equipo.
   * @param {string} marca = Obtiene el dato de la marca del equipo. Este dato lo envia el input=marca del formulario crear equipo.
   * @param {string} modelo = Obtiene el dato del modelo del equipo. Este dato lo envia el input=modelo del formulario crear equipo.
   * @param {string} serie = Obtiene el dato el serial del equipo. Este dato lo envia el input=serie del formulario crear equipo.
   * @param {string} pro_terc = Obtiene el dato si el equipo es propio o tercero. Este dato lo envia el input=pro_terc del formulario crear equipo.
   * @param {string} estado = Obtiene el dato del estado del equipo. Este dato lo envia el input=estado del formulario crear equipo.
   * @param {string} garantia = Obtiene el dato de la garantia del equipo. Este dato lo envia el input=garantia del formulario crear equipo.
   */
  $('#form-crear-equipo').submit(e => {
    let nombre_equipo = $('#equipo').val();
    let n_activo = $('#n_activo').val();
    let marca = $('#marca').val();
    let modelo = $('#modelo').val();
    let serie = $('#serie').val();
    let pro_terc = $('#pro_terc').val();
    let estado = $('#estado').val();
    let garantia = $('#garantia').val();

    funcion = 'crear_equipo';
    $.post('../../Controllers/control_equipo.php', { nombre_equipo, n_activo, marca, modelo, serie, pro_terc, estado, garantia, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El equipo ' + nombre_equipo + ' fue creado correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-equipo').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          '¡No fue creado!',
          'El equipo con la serie ' + serie + ' ya existe.',
          'error'
        )
        $('#form-crear-equipo').trigger('reset');
        buscar_datos();
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA EDITAR  LOS DATOS DEL EQUIPO.
   * @param {string} id_editado = Obtiene el datO del id del equipo el cual se requiere modificar.
   * @param {string} nombre_equipo = Obtiene el dato del nombre del equipo el cual se requiere modificar.
   * @param {string} n_activo = Obtiene el dato del numero de activo del equipo el cual se requiere modificar.
   * @param {string} marca = Obtiene el dato de la marca del equipo el cual se requiere modificar.
   * @param {string} modelo = Obtiene el dato del modelo del equipo el cual se requiere modificar.
   * @param {string} serie = Obtiene el dato el serial del equipo el cual se requiere modificar. 
   * @param {string} pro_terc = Obtiene el dato si el equipo es propio o tercero el cual se requiere modificar.
   * @param {string} estado = Obtiene el dato del estado del equipo el cual se requiere modificar.
   * @param {string} garantia = Obtiene el dato de la garantia del equipo el cual se requiere modificar.
   */
  $('#form-editar-equipo').submit(e => {
    let id_editado = $('#id_equipo').val();
    let nombre = $('#nombre_eq').val();
    let n_activo = $('#activo_eq').val();
    let marca = $('#marca_eq').val();
    let modelo = $('#modelo_eq').val();
    let serie = $('#serie_eq').val();
    let pro_terc = $('#prop_tercero_eq').val();
    let estado = $('#estado_eq').val();
    let garantia = $('#garantia_eq').val();

    funcion = 'editar';
    $.post('../../Controllers/control_equipo.php', { id_editado, nombre, n_activo, marca, modelo, serie, pro_terc, estado, garantia, funcion }, (response) => {
      if (response == 'update') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del equipo ' + nombre + ' fueron actualizados correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-equipo').trigger('reset');
        buscar_datos();
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS DATOS DE LOS EQUIPOS.
   * @param {String} consulta = Este parametro trae todos los datoss de los equipos registradas en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_equipo';
    $.post('../../Controllers/control_equipo.php', { consulta, funcion }, (response) => {
      const equipos = JSON.parse(response);
      let template = '';
      equipos.forEach(equipo => {
        template += `
            <tr id_equipo="${equipo.id_equipo}" nombre="${equipo.nombre}" no_activo="${equipo.no_activo}" marca="${equipo.marca}"
              modelo="${equipo.modelo}" serie="${equipo.serie}" pro_terc="${equipo.propio_tercero}" estado="${equipo.estado}"
              garantia="${equipo.garantia}">
              <td>${equipo.no_activo}</td>
              <td>${equipo.nombre}</td>
              <td>${equipo.marca}</td>
              <td>${equipo.modelo}</td>
              <td>${equipo.serie}</td>
              <td>${equipo.propio_tercero}</td>
              <td>${equipo.estado}</td>
              <td>${equipo.garantia}</td>
              <div class="text-right">`;
                if (equipo.estatus == 'STOCK') {
                  template += `
                    <td><h1 class="badge badge-info">${equipo.estatus}</h1></td>
                    <td>
                      <button class="editar btn btn-primary" title="Editar los datos del equipo" type="button" data-toggle="modal" data-target="#editar_equipo">
                        <i class="fas fa-pencil-alt"></i>
                      </button>
                      <a class="btn btn-warning" href="../../Views/Admin/Inventario_Equipos.php?id=${equipo.id_equipo}&equipo=${equipo.nombre}&serie=${equipo.serie}" title="Agregar el equipo a un contrato de arriendo y/o matto" >
                        <i class="fas fa-handshake"></i>
                      </a>
                      <button class="eliminar_eq btn btn-danger" title="Borrar los datos del equipo">
                        <i class="fas fa-trash-alt"></i>
                      </button>
                    </td>
                  `;
                } else {
                  template += `
                    <td><h1 class="badge badge-danger">${equipo.estatus}</h1></td>
                    <td>
                      <a class="btn btn-primary" href="../../Views/Admin/Inventario_Equipos.php" title="Click para ir al modulo de los equipos en contrato">
                        <i class="fas fa-clipboard-list"></i>
                      </a>
                    </td>
                  `;
                }
                template += `
              </div>
            </tr>
          `;
      })
      $('#datos_equipos').html(template); /** Proyectar el listado de todos los datos de los equipos en la tabla. */
    });
  }
  // FIN FUNCION BUSCAR DATOS

  /**
   * EVENTO BUSCAR, AL PRESIONAR DENTRO DEL BUSCADOR EJECUTA LA FUNCIÓN BUSCAR.
   * EL CUAL BUSCA POR UN DATO ESPECIFICO DE UN EQUIPO.
  */
  $(document).on('keyup', '#buscar_equipos', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });
  // FIN EVENTO BUSCAR

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DEL EQUIPO SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE LOS DATOS DEL EQUIPO REGISTRADOS EN LA BD PARA MODIFICAR.
   */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id_editado = $(elemento).attr('id_equipo');
    const nombre = $(elemento).attr('nombre');
    const n_activo = $(elemento).attr('no_activo');
    const marca = $(elemento).attr('marca');
    const modelo = $(elemento).attr('modelo');
    const serial = $(elemento).attr('serie');
    const pro_terc = $(elemento).attr('pro_terc');
    const estado = $(elemento).attr('estado');
    const garantia = $(elemento).attr('garantia');
    $('#id_equipo').val(id_editado);
    $('#nombre_eq').val(nombre);
    $('#activo_eq').val(n_activo);
    $('#marca_eq').val(marca);
    $('#modelo_eq').val(modelo);
    $('#serie_eq').val(serial);
    $('#prop_tercero_eq').val(pro_terc);
    $('#estado_eq').val(estado);
    $('#garantia_eq').val(garantia);
  });
  // FIN EVENTO CLICK

   /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON RETIRAR EL EQUIPO DEL CONTRATO A/M DE LA TABLA INVENTARIO EQUIPO SE EJECUTA EL EVENTO NO ARRENDAR.
   * EL CUAL RETIRA EL EQUIPO DEL CONTRATO ASIGNADO Y SE PODRA REALIZAR LAS OPCIONES DE EDITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.no_arrendar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_equipo');
    const nombre = $(elemento).attr('nombre');

    Swal.fire({
      title: '¿Desea retornar el equipo ' + nombre + ' al stock?',
      text: "El equipo cambiara el estado de contrato de arriendo y/o de matto a stock!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        funcion = "no_arrendar";
        $.post('../../Controllers/control_equipo.php', { id, funcion }, (response) => {
          if (response == 'stock') {
            Swal.fire(
              '¡Equipo en Stock!',
              'El equipo ' + nombre + ' queda en stock.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '`¡No fue devuelto al stock!',
              'El equipo ' + nombre + ' no fue posible devolverlo al stock.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

   /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON BORRAR LOS DATOS DEL EQUIPO DE LA TABLA INVENTARIO DE EQUIPOS SE EJECUTA EL EVENTO ELIMINAR EQ.
   * EL CUAL BORRARA LOS DATOS DEL EQUIPO REGISTRADO EN LA BASE DE DATOS.
   */
  $(document).on('click', '.eliminar_eq', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_equipo');
    const nombre_equipo = $(elemento).attr('nombre');

    Swal.fire({
      title: '¿Desea borrar el equipo ' + nombre_equipo + '?',
      text: "¡Los datos del equipo seran borrados de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        funcion = "eliminar_eq";
        $.post('../../Controllers/control_equipo.php', { id, nombre_equipo, funcion }, (response) => {
          if (response == 'delete') {
            Swal.fire(
              '¡Borrado!',
              'Los datos del equipo ' + nombre_equipo + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue borrado!',
              'Los datos del equipo ' + nombre_equipo + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR EQUIPO SE EJECUTA EL EVENTO BTN_LIMPIAR.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar', (e) => {
    $('#form-crear-equipo').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

})