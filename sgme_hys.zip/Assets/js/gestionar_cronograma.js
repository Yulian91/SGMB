var crear_cronograma = new bootstrap.Modal(document.getElementById('crear_cronograma'));

document.addEventListener('DOMContentLoaded', function () {
  buscar_datos();
  var calendarEl = document.getElementById('calendar');
  var calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',

    locale: 'es',
    navLinks: true,
    editable: true,
    eventLimit: true,
    selectable: true,
    selectHelper: false,

    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,listWeek'
    },

  /**
   * FUNCIÓN PARA MOSTRAR LOS DATOS PERSONALES DE ALGUN USUARIO ESPECIFICO.
   * @param {String} dato = Este parametro trae todos los datos del usuario registrado en la base de datos.
   * @param {String} funcion = Esta función es para realizar la busqueda de los datos del usuario especifico.
  */
    events: function ()  {
      funcion = 'eventos';
      $.post('../../Controllers/control_cronograma.php', { funcion }, (response) => {
        const eventos = JSON.parse(response);
        eventos.forEach(evento => {
          id = evento.id;
        })
      });
    },

    dateClick: function (info) {
      document.getElementById('titulo_evento').textContent = 'Agendar Mantenimientos';
      document.getElementById('fecha_inicio').value = info.dateStr;
      document.getElementById('fecha_final').value = info.dateStr;
      crear_cronograma.show();
    },

    eventClick: function (info) {
      var evento = info.event
      console.log(evento);
    }

  });
  calendar.render();

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR LOS DATOS DEL EVENTO.
   * @param {string} inventario = Obtiene el id del inventario. Este dato lo envia el input=inventario del formulario crear evento.
   * @param {string} titulo = Obtiene el dato del titulo del evento. Este dato lo envia el input=titulo del formulario crear cliente.
   * @param {string} fecha_inicio = Obtiene el dato de la fecha y hora del inicio del evento. Este dato lo envia el input=fecha_inicio y hora_inicio del formulario crear evento.
   * @param {string} fecha_final = Obtiene el dato de la fecha y hora del final del evento. Este dato lo envia el input=fecha_final y hora_final del formulario crear evento.
   * @param {string} descripcion = Obtiene el dato de la descripción del evento. Este dato lo envia el input=descripcion del formulario crear evento.
   */
  $('#form-crear-evento').submit(e => {
    let inventario = $('#inventario').val();
    let titulo = $('#titulo').val();
    let fecha_inicio = $('#fecha_inicio').val() + " " + $('#hora_inicio').val();
    let fecha_final = $('#fecha_final').val() + " " + $('#hora_final').val();
    let descripcion = $('#descripcion').val();
    funcion = 'crear_evento';
    $.post('../../Controllers/control_cronograma.php', { inventario, titulo, fecha_inicio, fecha_final, descripcion, funcion }, (response) => {
      if (response == 'add') {
        crear_cronograma.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El Equipo ' + inventario + ' se agendo correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-evento').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          'El equipo no se agendo correctamente!',
          'Por favor registre otra hora para el mantenimiento.',
          'error'
        )
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR LOS DATOS DEL EVENTO.
   * @param {string} id_cronograma = Obtiene el id del evento el cual se requiere modificar.
   * @param {string} inventario = Obtiene el id del inventario el cual se requiere modificar.
   * @param {string} titulo = Obtiene el dato del titulo del evento el cual se requiere modificar.
   * @param {string} fecha_inicio = Obtiene el dato de la fecha y hora del inicio del evento el cual se requiere modificar.
   * @param {string} fecha_final = Obtiene el dato de la fecha y hora del final del evento el cual se requiere modificar.
   * @param {string} descripcion = Obtiene el dato de la descripción del evento el cual se requiere modificar.
   */
  $('#form-editar-evento').submit(e => {
    let id_cronograma = $('#id_evento').val();
    let inventario = $('#inventario_edit').val();
    let titulo = $('#titulo_edit').val();
    let fecha_inicio = $('#fecha_inicio_edit').val() + " " + $('#hora_inicio_edit').val();
    let fecha_final = $('#fecha_final_edit').val() + " " + $('#hora_final_edit').val();
    let descripcion = $('#descripcion_edit').val();
    funcion = 'editar_evento';
    $.post('../../Controllers/control_cronograma.php', { id_cronograma, inventario, titulo, fecha_inicio, fecha_final, descripcion, funcion }, (response) => {
      if (response == 'edit') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del mantenimiento ' + id_cronograma + ' se actualizaron correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-evento').trigger('reset');
        buscar_datos();
      } else {
        Swal.fire(
          '¡No fue posible actualizar el matto!',
          'Los datos del mantenimiento ' + id_cronograma + ' No se actualizaron.',
          'error'
        )
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS DATOS DE LOS EVENTOS.
   * @param {String} consulta = Este parametro trae todos los datos de los mantenimientos programados en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_evento';
    $.post('../../Controllers/control_cronograma.php', { consulta, funcion }, (response) => {
      const eventos = JSON.parse(response);
      let template = '';
      eventos.forEach(evento => {
        template += `
          <tr id_cronograma="${evento.id_cronograma}" id_inventario="${evento.id_inventario}" nombre_eq="${evento.nombre_eq}" marca_eq="${evento.marca_eq}" modelo_eq="${evento.modelo_eq}" 
          serie_eq="${evento.serie_eq}" evento="${evento.titulo}" f_inicio="${evento.f_inicio}" f_final="${evento.f_final}" descripcion="${evento.descripcion}">
            <td>${evento.id_cronograma}</td>
            <td>${evento.nombre_eq}</td>
            <td>${evento.serie_eq}</td>
            <td>${evento.titulo}</td>
            <td>${evento.f_inicio}</td>
            <td>${evento.f_final}</td>
            <td>${evento.sede}</td>
            <td>${evento.descripcion}</td>
            <div class="text-right">`;
              if (evento.estado == 'PENDIENTE') {
                template += `
                  <td><h1 class="badge badge-info">${evento.estado}</h1></td>
                  <td>
                    <a class="estado_proceso btn btn-info" href="../../Views/Admin/Reportes.php?id=${evento.id_inventario}&equipo=${evento.nombre_eq}&marca=${evento.marca_eq}&modelo=${evento.modelo_eq}&serie=${evento.serie_eq}&sede=${evento.sede}&area=${evento.area}&evento=${evento.titulo}" title="Crear Reporte">
                      <i class="fas fa-file-alt"></i>
                    </a>
                    <button class="estado_cancelar btn btn-danger" title="Cancelar el mantenimiento programado">
                      <i class="fas fa-times"></i>
                    </button>
                    <button class="editar btn btn-primary" title="Editar los datos del matto agendado" type="button" data-toggle="modal" data-target="#editar_cronograma">
                      <i class="fas fa-pencil-alt"></i>
                    </button>
                  </td>
                `;
              }
              if (evento.estado == 'PROCESO') {
                template += `
                  <td><h1 class="badge badge-success">${evento.estado}</h1></td>
                  <td>
                    <button class="estado_cerrado btn btn-danger" title="Finalizar el mantenimiento programado">
                      <i class="fas fa-calendar-times"></i>
                    </button>
                    <button class="estado_reactivar btn btn-info" title="Reactivar el mantenimiento programado">
                      <i class="fas fa-file-import"></i>
                    </button>
                  </td>
                `;
              }
              if (evento.estado == 'CANCELADO') {
                template += `
                  <td><h1 class="badge badge-danger">${evento.estado}</h1></td>
                  <td>
                    <button class="eliminar_cancel btn btn-danger" title="Eliminar definitivamente el mantenimiento programado">
                      <i class="fas fa-trash-alt"></i>
                    </button>
                  </td>
                `;
              }
              if (evento.estado == 'FINALIZADO') {
                template += `
                  <td><h1 class="badge badge-danger">${evento.estado}</h1></td>
                  <td>
                    <button class="eliminar_final btn btn-danger" title="Eliminar definitivamente el mantenimiento programado">
                      <i class="fas fa-trash-alt"></i>
                    </button>
                  </td>
                `;
              }
              template += `
            </div>
          </tr>
        `;
      })
      $('#listado_matto').html(template); /** Proyectar el listado de todos los mantenimientos programados en la tabla. */
    });
  }
  // FIN FUNCIÓN BUSCAR DATOS

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DEL MATTO PROGRAMADO SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE LOS DATOS DEL MANTENIMIENTO PROGRAMADO EN LA BD PARA MODIFICAR.
   */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_cronograma');
    const id_inv = $(elemento).attr('id_inventario');
    const nombre_eq = $(elemento).attr('nombre_eq');
    const evento = $(elemento).attr('evento');
    const f_inicio = $(elemento).attr('f_inicio');
    const f_final = $(elemento).attr('f_final');
    const descripcion = $(elemento).attr('descripcion');
    $('#id_evento').val(id);
    $('#inventario_edit').val(id_inv);
    $('#nombre_equipo').val(nombre_eq);
    $('#titulo_edit').val(evento);
    $('#fecha_inicio_edit').val(f_inicio);
    $('#fecha_final_edit').val(f_final);
    $('#descripcion_edit').val(descripcion);
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR CIUDAD SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '.estado_proceso', (e) => {
    funcion = "estado_proceso";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_cronograma');
    const inventario = $(elemento).attr('id_inventario');

    $.post('../../Controllers/control_cronograma.php', { id, inventario, funcion }, (response) => {
      if (response == 'proceso') {
        buscar_datos();
      } else {
        alert('ERROR, NO SE PUEDE ENVIAR DATOS');
      }
    });
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR CIUDAD SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '.estado_reactivar', (e) => {
    funcion = "estado_reactivar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_cronograma');
    const inventario = $(elemento).attr('id_inventario');

    $.post('../../Controllers/control_cronograma.php', { id, inventario, funcion }, (response) => {
      if (response == 'reactivar') {
        buscar_datos();
      } else {
        alert('ERROR, NO SE PUEDE REACTIVAR EL MATTO');
      }
    });
    //e.preventDefault();
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR CIUDAD SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '.estado_cancelar', (e) => {
    funcion = "estado_cancelar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_cronograma');
    const inventario = $(elemento).attr('id_inventario');

    Swal.fire({
      title: '¿Desea cancelar el mantenimiento programado?',
      text: "Se cancelara el mantenimiento programado, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_cronograma.php', { id, inventario, funcion }, (response) => {
          if (response == 'cancelado') {
            Swal.fire(
              'Mantenimiento Cancelado!',
              'Se cancelo el mantenimiento programado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue cancelado!',
              'No fue posible cancelar el mantenimiento programado.',
              'error'
            )
          }
        });
      }
    })
    //e.preventDefault();
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR CIUDAD SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '.estado_cerrado', (e) => {
    funcion = "estado_cerrado";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_cronograma');
    const inventario = $(elemento).attr('id_inventario');

    Swal.fire({
      title: '¿Desea finalizar el mantenimiento?',
      text: "El mantenimiento sera finalizado, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_cronograma.php', { id, inventario, funcion }, (response) => {
          if (response == 'cerrado') {
            Swal.fire(
              'Mantenimiento Finalizado!',
              'El mantenimiento fue finalizado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue finalizado!',
              'El mantenimiento no fue finalizado.',
              'error'
            )
          }
        });
      }
    })
    //e.preventDefault();
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR CIUDAD SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '.eliminar_cancel', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_cronograma');
    const inventario = $(elemento).attr('id_inventario');

    Swal.fire({
      title: '¿Se eliminara el mantenimiento cancelado?',
      text: "¡Se eliminaran el mantenimiento cancelado de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        funcion = "eliminar";
        $.post('../../Controllers/control_cronograma.php', { id, inventario, funcion }, (response) => {
          if (response == 'delete') {
            Swal.fire(
              '!Mantenimiento Eliminado¡',
              'Se elimino el mantenimiento cancelado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '!No fue eliminado¡',
              'No fue posible eliminar el mantenimiento cancelado.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR CIUDAD SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '.eliminar_final', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_cronograma');
    const inventario = $(elemento).attr('id_inventario');

    Swal.fire({
      title: '¿Se eliminara el mantenimiento finalizado?',
      text: "!Se eliminaran el mantenimiento finalizado de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        funcion = "eliminar";
        $.post('../../Controllers/control_cronograma.php', { id, inventario, funcion }, (response) => {
          if (response == 'delete') {
            Swal.fire(
              '!Mantenimiento Eliminado¡',
              'Se elimino el mantenimiento finalizado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '!No fue eliminado¡',
              'No fue posible eliminar el mantenimiento finalizado.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

});