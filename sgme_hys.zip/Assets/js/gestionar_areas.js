$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  var edit = false; /** Declarar e iniciar la variable edit en falso */
  buscar_datos(); /** Inicializar la funcion buscar datos */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          //menu_princiapl(respuesta)
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR EL NOMBRE DEL AREA.
   * @param {string} nombre = Obtiene el dato del nombre del area. Este dato lo envia el input=nombre del formulario crear area.
   */
  $('#form-crear-area').submit(e => {
    let nombre = $('#nombre').val();
    
    funcion = 'crear_area';
    $.post('../../Controllers/control_area.php', { nombre, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El area '+nombre+' se creo correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-area').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          '¡No fue creado!',
          'El area '+nombre+' ya existe.',
          'error'
        )
        $('#form-crear-area').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * EVENTO SUBMIT. CONTIENE LA FUNCIÓN PARA EDITAR LOS DATOS DEL AREA.
   * @param {int} id_area = Obtiene el id del area la cual se modificara.
   * @param {string} nombre = Obtiene el nombre del area la cual se modificara.
   */
  $('#form-editar-area').submit(e => {
    let id_area = $('#id_area').val();
    let nombre = $('#nombre_edit').val();

    funcion = 'editar_area';
    $.post('../../Controllers/control_area.php', { id_area, nombre, funcion }, (response) => {
      if (response == 'update') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del area '+nombre+' se actualizaron correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-area').trigger('reset');
        buscar_datos();
      } else {
        Swal.fire(
          '¡No fue actualizado!',
          'Los datos del area ' + nombre + ' no fueron borrados.',
          'error'
        )
        $('#form-editar-area').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS NOMBRES DE LAS AREAS.
   * @param {String} consulta = Este parametro trae todos los nombres de las areas registradas en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_area';
    $.post('../../Controllers/control_area.php', { consulta, funcion }, (response) => { /** URL del controlador */
      const areas = JSON.parse(response);
      let template = '';
      areas.forEach(area => {
        template += `
                    <tr idarea="${area.id_area}" nombrearea="${area.nombre}">
                      <td>${area.id_area}</td>
                      <td>${area.nombre}</td>
                        <div class="text-right">`;
        if (area.estatus == 'ACTIVO') {
          template += `
                              <td><h1 class="badge badge-info">${area.estatus}</h1></td>
                              <td>
                                <button class="editar btn btn-primary" title="Editar los datos del area" type="button" data-toggle="modal" data-target="#editar_area">
                                  <i class="fas fa-pencil-alt"></i>
                                </button>
                                <button class="inhabilitar btn btn-danger" title="Inactivar los datos del area">
                                  <i class="fas fa-times"></i>
                                </button>
                              </td>
                            `;
        } else {
          template += `
                              <td><h1 class="badge badge-danger">${area.estatus}</h1></td>
                              <td>
                                <button class="habilitar btn btn-primary" title="Activar los datos del area">
                                  <i class="fas fa-check-square"></i>
                                </button>
                                <button class="eliminar btn btn-danger" title="Eliminar definitivamente los datos del area">
                                  <i class="fas fa-trash-alt"></i>
                                </button>
                              </td>
                            `;
        }
        template += `
                        </div>
                    </tr>
              `;
      })
      $('#areas').html(template); /** Proyectar el listado de los nombres de todas las areas en la tabla. */
    });
  }
  // FIN FUNCIÓN BUSCAR DATOS

  /**
   * EVENTO BUSCAR, AL PRESIONAR DENTRO DEL BUSCADOR SE EJECUTA LA FUNCIÓN BUSCAR.
   * EL CUAL BUSCA POR UN DATO ESPECIFICO DE UN AREA.
  */
  $(document).on('keyup', '#buscar_area', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor); 
    }
    else {
      buscar_datos();
    }
  });
  // FIN EVENTO BUSCAR

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DEL AREA SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE LOS DATOS DEL AREA REGISTRADOS EN LA BD PARA MODIFICAR.
   */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idarea');
    const nombre = $(elemento).attr('nombrearea');
    $('#id_area').val(id);
    $('#nombre_edit').val(nombre);
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON INACTIVAR DATOS DEL AREA DE LA TABLA GESTIONAR AREAS SE EJECUTA EL EVENTO INHABILITAR.
   * EL CUAL INHABILITA LOS DATOS DEL AREA Y NO SE PODRA REALIZAR NINGUNA DE LAS OPCIONES COMO EDITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.inhabilitar', (e) => {
    funcion = "inhabilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idarea');
    const nombre = $(elemento).attr('nombrearea');
    Swal.fire({
      title: '¿Desea inactivar el area ' + nombre + '?',
      text: "¡Los datos del area seran inactivados, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_area.php', { id, nombre, funcion }, (response) => {
          edit == false;
          if (response == 'inactivado') {
            Swal.fire(
              '¡Inactivado!',
              'Los datos del area ' + nombre + ' fueron inactivados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue inactivado!',
              'Los datos del area ' + nombre + ' no fueron inactivados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ACTIVAR DATOS DEL AREA DE LA TABLA GESTIONAR AREAS SE EJECUTA EL EVENTO HABILITAR.
   * EL CUAL HABILITA LOS DATOS DEL AREA Y SE PODRA REALIZAR LAS OPCIONES DE EDITAR, INHABILITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.habilitar', (e) => {
    funcion = "habilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idarea');
    const nombre = $(elemento).attr('nombrearea');
    Swal.fire({
      title: '¿Desea activar el area ' + nombre + '?',
      text: "¡Los datos del area seran activados!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_area.php', { id, nombre, funcion }, (response) => {
          edit == false;
          if (response == 'activo') {
            Swal.fire(
              '¡Activado!',
              'Los datos del area ' + nombre + ' fueron activados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue activado!',
              'Los datos del area ' + nombre + ' no fueron activados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ELIMINAR LOS DATOS DEL AREA DE LA TABLA GESTIONAR AREAS SE EJECUTA EL EVENTO ELIMINAR.
   * EL CUAL BORRA LOS DATOS DEL AREA REGISTRADO EN LA BASE DE DATOS.
   */
  $(document).on('click', '.eliminar', (e) => {
    funcion = "eliminar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idarea');
    const nombre = $(elemento).attr('nombrearea');

    Swal.fire({
      title: '¿Desea eliminar el area ' + nombre + '?',
      text: "¡Los datos del area seran borrados de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_area.php', { id, funcion }, (response) => {
          edit == false;
          if (response == 'delete') {
            Swal.fire(
              '¡Borrado!',
              'Los datos del area ' + nombre + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue borrado!',
              'Los datos del area ' + nombre + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR AREA SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar_1', (e) => {
    $('#form-crear-area').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO EDITAR AREA SE EJECUTA EL EVENTO BTN_LIMPIAR_2.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar_2', (e) => {
    $('#form-editar-area').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

})