$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  buscar_datos(); /** Inicializar la funcion buscar datos */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR EL NOMBRE DE LA SEDE.
   * @param {string} nombre = Obtiene el dato del nombre de la sede. Este dato lo envia el input=nombre del formulario crear sede.
   */
  $('#form-crear-sede').submit(e => {
    let nombre = $('#nombre').val();
    
    funcion = 'crear_sede';
    $.post('../../Controllers/control_sede.php', { nombre, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'La sede '+nombre+' se creo correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-sede').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          '¡No fue creado!',
          'La sede ' + nombre + ' ya existe.',
          'error'
        )
        $('#form-crear-sede').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA EDITAR EL NOMBRE DE LA SEDE  .
   * @param {String} id_sede = Obtiene el dato del id de la sede el cual se requiere modificar.
   * @param {string} nombre = Obtiene el dato del nombre de la sede el cual se requiere modificar.
   */
  $('#form-editar-sede').submit(e => {
    let id_sede = $('#id_sede').val();
    let nombre = $('#nombre_edit').val();
    
    funcion = 'editar_sede';
    $.post('../../Controllers/control_sede.php', { id_sede, nombre, funcion }, (response) => {
      if (response == 'update') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos de la sede '+nombre+' se actualizaron correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-sede').trigger('reset');
        buscar_datos();
      } else {
        Swal.fire(
          '¡No fue actualizado!',
          'Los datos de la sede ' + nombre + ' no fueron actualizados.',
          'error'
        )
        $('#form-editar-sede').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS NOMBRES DE LAS SEDES.
   * @param {String} consulta = Este parametro trae todos los nombres de las sedes registradas en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_sede';
    $.post('../../Controllers/control_sede.php', { consulta, funcion }, (response) => {
      const sedes = JSON.parse(response);
      let template = '';
      sedes.forEach(sede => {
        template += `
                    <tr idsede="${sede.id_sede}" nombresede="${sede.nombre}">
                      <td>${sede.id_sede}</td>
                      <td>${sede.nombre}</td>
                        <div class="text-right">`;
        if (sede.estatus == 'ACTIVO') {
          template += `
                              <td><h1 class="badge badge-info">${sede.estatus}</h1></td>
                              <td>
                                <button class="editar btn btn-primary" title="Editar los datos de la sede" type="button" data-toggle="modal" data-target="#editar_sede">
                                  <i class="fas fa-pencil-alt"></i>
                                </button>
                                <button class="inhabilitar btn btn-danger" title="Inhabilitar los datos de la sede">
                                  <i class="fas fa-times"></i>
                                </button>
                              </td>
                            `;
        } else {
          template += `
                              <td><h1 class="badge badge-danger">${sede.estatus}</h1></td>
                              <td>
                                <button class="habilitar btn btn-primary" title="Habilitar los datos de la sede">
                                  <i class="fas fa-check-square"></i>
                                </button>
                                <button class="eliminar btn btn-danger" title="Eliminar definitivamente los datos de la sede">
                                  <i class="fas fa-trash-alt"></i>
                                </button>
                              </td>
                            `;
        }
        template += `
                        </div>
                    </tr>
              `;
      })
      $('#sedes').html(template); /** Proyectar el listado de todos los nombres de los paises en la tabla. */
    });
  }
  // FIN FUNCIÓN BUSCAR DATOS

  /**
   * EVENTO BUSCAR, AL PRESIONAR DENTRO DEL BUSCADOR SE EJECUTA LA FUNCIÓN BUSCAR.
   * EL CUAL BUSCA POR UN DATO ESPECIFICO DE UNA SEDE.
  */
  $(document).on('keyup', '#buscar_sede', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });
  // FIN EVENTO BUSCAR

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DE LA SEDE SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE LOS DATOS DE LAS SEDES REGISTRADOS EN LA BD PARA MODIFICAR.
   */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idsede');
    const nombre = $(elemento).attr('nombresede');
    $('#id_sede').val(id);
    $('#nombre_edit').val(nombre);
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON INACTIVAR DATOS DE LA SEDE DE LA TABLA GESTIONAR SEDES SE EJECUTA EL EVENTO INHABILITAR.
   * EL CUAL INHABILITA LOS DATOS DE LA SEDE Y NO SE PODRA REALIZAR NINGUNA DE LAS OPCIONES COMO EDITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.inhabilitar', (e) => {
    funcion = "inhabilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idsede');
    const nombre = $(elemento).attr('nombresede');
    Swal.fire({
      title: '¿Desea inactivar la sede ' + nombre + '?',
      text: "¡Los datos de la sede seran inactivados, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_sede.php', { id, nombre, funcion }, (response) => {
          if (response == 'inactivado') {
            Swal.fire(
              '¡Inactivado!',
              'Los datos de la sede ' + nombre + ' fueron inactivados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue inactivado!',
              'Los datos de la sede ' + nombre + ' no fueron inactivados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ACTIVAR DATOS DE LA SEDE DE LA TABLA GESTIONAR SEDES SE EJECUTA EL EVENTO HABILITAR.
   * EL CUAL HABILITA LOS DATOS DE LA SEDE Y SE PODRA REALIZAR LAS OPCIONES DE EDITAR, INHABILITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.habilitar', (e) => {
    funcion = "habilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idsede');
    const nombre = $(elemento).attr('nombresede');
    Swal.fire({
      title: '¿Desea activar los datos de la sede ' + nombre + '?',
      text: "¡Los datos de la sede seran activados!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_sede.php', { id, nombre, funcion }, (response) => {
          if (response == 'activo') {
            Swal.fire(
              '¡Activado!',
              'Los datos de la sede ' + nombre + ' fueron activados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue activado!',
              'Los datos de la sede ' + nombre + ' no fueron activados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ELIMINAR LOS DATOS DE LA SEDE DE LA TABLA GESTIONAR SEDES SE EJECUTA EL EVENTO ELIMINAR.
   * EL CUAL BORRA LOS DATOS DE LA SEDE REGISTRADA EN LA BASE DE DATOS.
   */
  $(document).on('click', '.eliminar', (e) => {
    funcion = "eliminar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idsede');
    const nombre = $(elemento).attr('nombresede');

    Swal.fire({
      title: '¿Desea eliminar los datos de la sede ' + nombre + '?',
      text: "¡Los datos de la sede sera borrados de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_sede.php', { id, funcion }, (response) => {
          if (response == 'delete') {
            Swal.fire(
              '¡Borrado!',
              'Los datos de la sede ' + nombre + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue borrado!',
              'Los datos de la sede ' + nombre + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR SEDE SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
  */
  $(document).on('click', '#btn_limpiar_1', (e) => {
    $('#form-crear-sede').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO EDITAR SEDE SE EJECUTA EL EVENTO BTN_LIMPIAR_2.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar_2', (e) => {
    $('#form-editar-sede').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

})