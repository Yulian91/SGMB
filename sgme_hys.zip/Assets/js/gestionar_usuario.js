$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  buscar_datos(); /** Inicializar la funcion buscar datos */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

   /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
   async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let usuario = JSON.parse(response);
        if (usuario.length != 0) {
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR LOS DATOS DEL USUARIO.
   * @param {string} nombre = Obtiene el dato del nombre del usuario. Este dato lo envia el input=nombre del formulario crear usuario.
   * @param {string} apellido = Obtiene el dato del apellido del usuario. Este dato lo envia el input=apellido del formulario crear usuario.
   * @param {string} email = Obtiene el dato del correo del usuario. Este dato lo envia el input=email del formulario crear usuario.
   * @param {string} identificacion = Obtiene el dato del numero de identificación del usuario. Este dato lo envia el input=identificacion del formulario crear usuario.
   * @param {string} contacto = Obtiene el dato del numero de contacto del usuario. Este dato lo envia el input=contacto del formulario crear usuario.
   * @param {string} direccion = Obtiene el dato de la dirección del usuario. Este dato lo envia el input=direccion del formulario crear usuario.
   * @param {string} contrasena = Obtiene el dato de la contraseña del usuario. Este dato lo envia el input=contrasena del formulario crear usuario.
   * @param {string} tipo = Obtiene el dato del tipo de usuario. Este dato lo envia el input=tipo del formulario crear usuario.
   */
  $('#form-crear-usuario').submit(e => {
    let nombre = $('#nombre').val();
    let apellido = $('#apellido').val();
    let email = $('#email').val();
    let identificacion = $('#identificacion').val();
    let contacto = $('#contacto').val();
    let direccion = $('#direccion').val();
    let contrasena = $('#contrasena').val();
    let tipo = $('#tipo').val()

    funcion = 'crear_usuario';
    $.post('/sgme_hys/Controllers/control_usuario.php', { nombre, apellido, email, identificacion, contacto, direccion, contrasena, tipo, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El usuario ' + nombre + ' se creo correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-usuario').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          '¡No fue creado!',
          'El No de id ' + identificacion + ' del usuario ya existe',
          'error'
        )
        $('#form-crear-usuario').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA EDITAR LOS DATOS DEL USUARIO.
   * @param {string} id_usuario = Obtiene el dato del id del usuario el cual se requiere modificar.
   * @param {string} nombre = Obtiene el dato del nombre del usuario el cual se requiere modificar.
   * @param {string} apellido = Obtiene el dato del apellido del usuario el cual se requiere modificar.
   * @param {string} email = Obtiene el dato del correo del usuario el cual se requiere modificar.
   * @param {string} identificacion = Obtiene el dato del numero de identificación del usuario el cual se requiere modificar.
   * @param {string} contacto = Obtiene el dato del numero de contacto del usuario el cual se requiere modificar.
   * @param {string} direccion = Obtiene el dato de la dirección del usuario el cual se requiere modificar.
   * @param {string} contrasena = Obtiene el dato de la contraseña del usuario el cual se requiere modificar.
   * @param {string} tipo = Obtiene el dato del tipo de usuario el cual se requiere modificar.
   */
  $('#form-editar-usuario').submit(e => {
    let id_usuario = $('#id_usuario').val();
    let nombre = $('#nombre_usu').val();
    let apellidos = $('#apellido_usu').val();
    let email = $('#email_usu').val();
    let identificacion = $('#identificacion_usu').val();
    let contacto = $('#contacto_usu').val();
    let direccion = $('#direccion_usu').val();
    let contrasena = $('#contrasena_usu').val();
    let tipo = $('#tipo_usu').val();

    funcion = 'editar_usuario';
    $.post('/sgme_hys/Controllers/control_usuario.php', { id_usuario, nombre, apellidos, identificacion, email, contacto, direccion, contrasena, tipo, funcion }, (response) => {
      if (response == 'update_usu') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del usuario ' + nombre + ' se actualizaron correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-equipo').trigger('reset');
        buscar_datos();
      } else {
        Swal.fire(
          'No fue actualizado!',
          'El id ' + identificacion + ' del usuario ya existe.',
          'error'
        )
        $('#form-crear-cliente').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS DATOS DEL USUARIO
   * @param {String} consulta = Este parametro trae todos los datos del usuario registrado en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_usuarios';
    $.post('/sgme_hys/Controllers/control_usuario.php', { consulta, funcion }, (response) => {
      const usuarios = JSON.parse(response);
      let template = '';
      usuarios.forEach(usuario => {
        template += `
          <tr idusu="${usuario.id}" nombreusu="${usuario.nombre}" apellidousu="${usuario.apellidos}" emailusu="${usuario.email}" 
            identificacionusu="${usuario.identificacion}" contactousu="${usuario.contacto}" direccionusu="${usuario.direccion}" 
            contrasenausu="${usuario.contrasena}" tipousu="${usuario.tipo_usuario}">
            <td>${usuario.nombre}</td>
            <td>${usuario.apellidos}</td>
            <td>${usuario.email}</td>
            <td>${usuario.identificacion}</td>
            <td>${usuario.contacto}</td>
            <td>${usuario.direccion}</td>
            <td>${usuario.contrasena}</td>
            <td> <h1 class="badge badge-info">${usuario.tipo}</h1> </td>
              <div class="text-right">`;
        if (usuario.estatus == 'ACTIVO') {
          template += `
                    <td><h1 class="badge badge-info">${usuario.estatus}</h1></td>
                  `;
        } else {
          template += `
                    <td><h1 class="badge badge-danger">${usuario.estatus}</h1></td>
                  `;
        }
        template += `
              </div>
              <td>
                <div class="text-right">`;
        if (usuario.tipo_usuario != 1) {
          if (usuario.estatus == 'ACTIVO') {
            template += `
                      <button class="editar btn btn-primary" title="Editar los datos del usuario" type="button" data-toggle="modal" data-target="#editar_usuario">
                        <i class="fas fa-pencil-alt"></i>
                      </button> 
                      <button class="inhabilitar btn btn-danger" title="Inactivar los datos del usuario">
                        <i class="fas fa-times"></i>
                      </button>
                    `;
          } else if (usuario.estatus == 'INACTIVO') {
            template += `
                      <button class="habilitar btn btn-primary" title="Activar los datos del usuario">
                        <i class="fas fa-check-square"></i>
                      </button>
                      <button class="eliminar btn btn-danger" title="Eliminar los datos del usuario">
                        <i class="fas fa-trash-alt"></i>
                      </button>
                    `;
          }
        }
        template += `
                </div>
              </td>
          </tr>
        `;
      })
      $('#usuarios').html(template); /** Proyectar el listado de todos los datos del usuario en la tabla. */
    });
  }
  // FIN FUNCIÓN BUSCAR DATOS

  /**
   * EVENTO BUSCAR, AL PRESIONAR DENTRO DEL BUSCADOR SE EJECUTA LA FUNCIÓN BUSCAR.
   * EL CUAL BUSCA POR UN DATO ESPECIFICO DEL USUARIO.
  */
  $(document).on('keyup', '#buscar-usuarios', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });
  // FIN EVENTO BUSCAR

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DEL USUARIO SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE TODOS LOS DATOS DEL USUARIO REGISTRADOS EN LA BASE DE DATOS PARA MODIFICAR.
   */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement.parentElement;
    const id = $(elemento).attr('idusu');
    const nombre = $(elemento).attr('nombreusu');
    const apellidos = $(elemento).attr('apellidousu');
    const email = $(elemento).attr('emailusu');
    const identificacion = $(elemento).attr('identificacionusu');
    const contacto = $(elemento).attr('contactousu');
    const direccion = $(elemento).attr('direccionusu');
    const contrasena = $(elemento).attr('contrasenausu');
    const tipo = $(elemento).attr('tipousu');
    $('#id_usuario').val(id);
    $('#nombre_usu').val(nombre);
    $('#apellido_usu').val(apellidos);
    $('#email_usu').val(email);
    $('#identificacion_usu').val(identificacion);
    $('#contacto_usu').val(contacto);
    $('#direccion_usu').val(direccion);
    $('#contrasena_usu').val(contrasena);
    $('#tipo_usu').val(tipo);
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON INACTIVAR DATOS DEL USUARIO DE LA TABLA GESTIONAR USUARIO SE EJECUTA EL EVENTO INHABILITAR.
   * EL CUAL INHABILITA LOS DATOS DEL USUARIO Y NO SE PODRA REALIZAR NINGUNA DE LAS OPCIONES COMO EDITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.inhabilitar', (e) => {
    funcion = "inhabilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement.parentElement;
    const id = $(elemento).attr('idusu');
    const nombre = $(elemento).attr('nombreusu');
    const apellidos = $(elemento).attr('apellidousu');
    const email = $(elemento).attr('emailusu');
    const identificacion = $(elemento).attr('identificacionusu');
    const contacto = $(elemento).attr('contactousu');
    const direccion = $(elemento).attr('direccionusu');
    const contrasena = $(elemento).attr('contrasenausu');
    const tipo = $(elemento).attr('tipousu');
    Swal.fire({
      title: '¿Desea inactivar el usuario ' + nombre + ' ' + apellidos + '?',
      text: "El usuario sera inactivado, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_usuario.php', { id, funcion }, (response) => {
          if (response == 'inactivado') {
            Swal.fire(
              'Inactivado!',
              'El usuario ' + nombre + ' ' + apellidos + ' fue inactivado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue inactivado!',
              'El usuario ' + nombre + ' ' + apellidos + ' no fue inactivado.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ACTIVAR DATOS DEL USUARIO DE LA TABLA GESTIONAR USUARIOS SE EJECUTA EL EVENTO HABILITAR.
   * EL CUAL HABILITA LOS DATOS DEL USUARIO Y SE PODRA REALIZAR LAS OPCIONES DE EDITAR, INHABILITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.habilitar', (e) => {
    funcion = "habilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement.parentElement;
    const id = $(elemento).attr('idusu');
    const nombre = $(elemento).attr('nombreusu');
    const apellidos = $(elemento).attr('apellidousu');
    const email = $(elemento).attr('emailusu');
    const identificacion = $(elemento).attr('identificacionusu');
    const contacto = $(elemento).attr('contactousu');
    const direccion = $(elemento).attr('direccionusu');
    const contrasena = $(elemento).attr('contrasenausu');
    const tipo = $(elemento).attr('tipousu');
    Swal.fire({
      title: '¿Desea activar el usuario ' + nombre + ' ' + apellidos + '?',
      text: "Los datos del usuario seran activados!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_usuario.php', { id, funcion }, (response) => {
          if (response == 'activado') {
            Swal.fire(
              'Activado!',
              'El usuario ' + nombre + ' ' + apellidos + ' fue activado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue activado!',
              'El usuario ' + nombre + ' ' + apellidos + ' no fue activado.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK
  
  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ELIMINAR LOS DATOS DEL USUARIO DE LA TABLA GESTIONAR USUARIOS SE EJECUTA EL EVENTO ELIMINAR.
   * EL CUAL BORRA LOS DATOS DEL USUARIO REGISTRADOS EN LA BASE DE DATOS.
   */
  $(document).on('click', '.eliminar', (e) => {
    funcion = "eliminar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement.parentElement;
    const id = $(elemento).attr('idusu');
    const nombre = $(elemento).attr('nombreusu');
    const apellidos = $(elemento).attr('apellidousu');
    const email = $(elemento).attr('emailusu');
    const identificacion = $(elemento).attr('identificacionusu');
    const contacto = $(elemento).attr('contactousu');
    const direccion = $(elemento).attr('direccionusu');
    const contrasena = $(elemento).attr('contrasenausu');
    const tipo = $(elemento).attr('tipousu');
    Swal.fire({
      title: '¿Desea eliminar del usuario ' + nombre + ' ' + apellidos + '?',
      text: "¡Los datos del usuario seran borrados de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_usuario.php', { id, funcion }, (response) => {
          if (response == 'delete') {
            Swal.fire(
              '¡Borrado!',
              'Los datos del usuario ' + nombre + ' ' + apellidos + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue borrado!',
              'Los datos del usuario ' + nombre + ' ' + apellidos + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR USUARIO SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
  */
  $(document).on('click', '#btn_limpiar_1', (e) => {
    $('#form-crear-usuario').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO EDITAR USUARIO SE EJECUTA EL EVENTO BTN_LIMPIAR_2.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar_2', (e) => {
    $('#form-editar-usuario').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

})