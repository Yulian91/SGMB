$(document).ready(function () {
  var funcion = '';
  $('#aviso1').hide();
  $('#aviso').hide();

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA RECUPERAR LA CONTRASEÑA.
   * @param {string} identificacion = Obtiene el dato del id del equipo que se encuentra en el inventario. Este dato lo envia el input=inventario del formulario crear reporte.
   * @param {string} email = Obtiene el dato del tipo de servicio. Este dato lo envia el input=tipo_servicio del formulario crear reporte.
   * @param {funcion} mostrar_load = Obtiene el dato del tipo de servicio. Este dato lo envia el input=tipo_servicio del formulario crear reporte.
   */
  $('#form-recuperar-pass').submit(e => {
    let identificacion = $('#id_recuperar').val();
    let email = $('#email_recuperar').val();
    mostrar_load('Recuperar_password');

    if (email == '' || identificacion == '') {
      $('#aviso').show();
      $('#aviso').text('No deje vacios los campos');
      cerrar_load('');
    }
    else {
      $('#aviso').hide();
      let funcion = 'verificar_datos';
      $.post('../../Controllers/control_recuperar_pass.php', { identificacion, email, funcion }, (response) => {
        if (response == 'encontrado') {
          let funcion = 'recuperar_password';
          $('#aviso').hide();
          $.post('../../Controllers/control_recuperar_pass.php', { identificacion, email, funcion }, (response2) => {
            $('#aviso').hide();
            $('#aviso1').hide();
            if (response2 == 'enviado') {
              cerrar_load('enviado_exito');
              $('#aviso1').hide();
              $('#aviso1').text('Se restablecio la contraseña');
              $('#form-recuperar-pass').trigger('reset');
            }
            else {
              cerrar_load('error_envio');
              $('#aviso').hide();
              $('#aviso').text('No es posible restablecer la contraseña');
              $('#form-recuperar-pass').trigger('reset');
            }
          })
        }
        else {
          cerrar_load('error_usuario');
          $('#aviso').hide();
          $('#aviso1').hide();
          $('#aviso').hide();
          $('#aviso').text('los datos no son correctos');
        }
      })
    }
    e.preventDefault();
  });

  function mostrar_load(mensaje) {
    var texto = null;
    var mostrar = false;
    switch (mensaje) {
      case 'Recuperar_password':
        texto = 'Se esta enviando el correo, por favor espere...';
        mostrar = true;
        break;
    }
    if (mostrar) {
      Swal.fire({
        title: 'Enviando Correo...',
        text: texto,
        showConfirmButton: false
      })

    }

  }

  function cerrar_load(mensaje) {
    var tipo = null;
    var texto = null;
    var mostrar = false;
    switch (mensaje) {
      case 'enviado_exito':
        tipo = 'success';
        texto = 'El correo fue enviado correctamente';
        mostrar = true;
        break;

      case 'error_envio':
        tipo = 'error';
        texto = 'El correo no es posible enviar, por favor intenta de nuevo.';
        mostrar = true;
        break;

      case 'error_usuario':
        tipo = 'error';
        texto = 'El usuario no fue encontrado o es posible que no existe.';
        mostrar = true;
        break;

      default:
        Swal.close();
        break;
    }
    if (mostrar) {
      Swal.fire({
        position: 'center',
        icon: tipo,
        text: texto,
        showConfirmButton: false
      })

    }
  }

})