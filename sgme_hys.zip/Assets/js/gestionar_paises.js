$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  var edit = false; /** Declarar e iniciar la variable edit en falso */
  buscar_datos(); /** Inicializar la funcion buscar datos */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR EL NOMBRE DEL PAIS.
   * @param {string} nombre = Obtiene el dato del nombre del pais. Este dato lo envia el input=nombre_pais del formulario crear pais.
   */
  $('#form-crear-pais').submit(e => {
    let nombre = $('#nombre_pais').val();

    funcion = 'crear_pais';
    $.post('../../Controllers/control_pais.php', { nombre, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El pais '+nombre+' se creo correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-pais').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          'No fue creado!',
          'El pais '+nombre+' ya existe.',
          'error'
        )
        $('#form-crear-pais').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT
  
  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA EDITAR EL NOMBRE DEL PAIS.
   * @param {String} id_pais = Obtiene el dato del id del pais el cual se requiere modificar.
   * @param {string} nombre = Obtiene el dato del nombre del pais el cual se requiere modificar.
   */
  $('#form-editar-pais').submit(e => {
    let id_pais = $('#id_pais').val();
    let nombre = $('#nombre_pais_edit').val();

    funcion = 'editar_pais';
    $.post('../../Controllers/control_pais.php', { id_pais, nombre, funcion }, (response) => {
      if (response == 'update') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del pais '+nombre+' se actualizaron correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-pais').trigger('reset');
        buscar_datos();
      } else {
        Swal.fire(
          'No fue actualizado!',
          'El pais '+nombre+' ya existe.',
          'error'
        )
        $('#form-editar-pais').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT
  
  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS NOMBRES DE LOS PAIS.
   * @param {String} consulta = Este parametro trae todos los nombres de los paises registradas en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_paises';
    $.post('../../Controllers/control_pais.php', { consulta, funcion }, (response) => {
      const paises = JSON.parse(response);
      let template = '';
      paises.forEach(pais => {
        template += `
                    <tr idpais="${pais.id_pais}" nombrepais="${pais.nombre}" estado="${pais.estatus}">
                      <td>${pais.id_pais}</td>
                      <td>${pais.nombre}</td>
                        <div class="text-right">`;
        if (pais.estatus == 'ACTIVO') {
          template += `
                            <td><h1 class="badge badge-info">${pais.estatus}</h1></td>
                            <td>
                              <button class="editar btn btn-primary" title="Editar los datos del pais" type="button" data-toggle="modal" data-target="#editar_pais">
                                <i class="fas fa-pencil-alt"></i>
                              </button>
                              <button class="inhabilitar btn btn-danger" title="Inactivar los datos del pais">
                                <i class="fas fa-times"></i>
                              </button>
                            </td>
                            `;
        } else {
          template += `
                            <td><h1 class="badge badge-danger">${pais.estatus}</h1></td>
                            <td>
                              <button class="habilitar btn btn-primary" title="Activar los datos del pais">
                                <i class="fas fa-check-square"></i>
                              </button>
                              <button class="eliminar btn btn-danger" title="Eliminar definitivamete los datos del pais">
                                <i class="fas fa-trash-alt"></i>
                              </button>
                            </td>
                            `;
        }
        template += `
                        </div>
                    </tr>
              `;
      })
      $('#paises').html(template); /** Proyectar el listado de todos los nombres de los paises en la tabla. */
    });
  }
  // FIN FUNCIÓN BUSCAR DATOS

  /**
   * EVENTO BUSCAR, AL PRESIONAR DENTRO DEL BUSCADOR SE EJECUTA LA FUNCIÓN BUSCAR.
   * EL CUAL BUSCA POR UN DATO ESPECIFICO DE UN PAIS.
  */
  $(document).on('keyup', '#buscar_pais', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });
  // FIN EVENTO BUSCAR

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DEL PAIS SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE LOS DATOS DE LOS PAISES REGISTRADOS EN LA BD PARA MODIFICAR.
   */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idpais');
    const nombre = $(elemento).attr('nombrepais');
    $('#id_pais').val(id);
    $('#nombre_pais_edit').val(nombre);
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON INACTIVAR DATOS DEL PAIS DE LA TABLA GESTIONAR PAISES SE EJECUTA EL EVENTO INHABILITAR.
   * EL CUAL INHABILITA LOS DATOS DEL PAIS Y NO SE PODRA REALIZAR NINGUNA DE LAS OPCIONES COMO EDITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.inhabilitar', (e) => {
    funcion = "inhabilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idpais');
    const nombre = $(elemento).attr('nombrepais');
    Swal.fire({
      title: 'Desea inactivar los datos del pais?',
      text: "Los datos del pais seran inactivados, pero no se borran de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_pais.php', { id, nombre, funcion }, (response) => {
          edit == false;
          if (response == 'inactivado') {
            Swal.fire(
              'Inactivado!',
              'Los datos del pais ' + nombre + ' fueron inactivados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue inactivado!',
              'Los datos del pais ' + nombre + ' no fueron inactivados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ACTIVAR DATOS DEL PAIS DE LA TABLA GESTIONAR PAISES SE EJECUTA EL EVENTO HABILITAR.
   * EL CUAL HABILITA LOS DATOS DEL PAIS Y SE PODRA REALIZAR LAS OPCIONES DE EDITAR, INHABILITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.habilitar', (e) => {
    funcion = "habilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idpais');
    const nombre = $(elemento).attr('nombrepais');
    Swal.fire({
      title: 'Desea activar los datos del pais?',
      text: "Los datos del pais seran activados!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_pais.php', { id, nombre, funcion }, (response) => {
          edit == false;
          if (response == 'activo') {
            Swal.fire(
              'Activado!',
              'Los datos del pais ' + nombre + ' fueron activados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue activado!',
              'Los datos del pais ' + nombre + ' no fueron activados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ELIMINAR LOS DATOS DEL PAIS DE LA TABLA GESTIONAR PAISES SE EJECUTA EL EVENTO ELIMINAR.
   * EL CUAL BORRA LOS DATOS DEL PAIS REGISTRADO EN LA BASE DE DATOS.
   */
  $(document).on('click', '.eliminar', (e) => {
    funcion = "eliminar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idpais');
    const nombre = $(elemento).attr('nombrepais');
    Swal.fire({
      title: 'Desea eliminar los datos del pais?',
      text: "You won't be able to revert this!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_pais.php', { id, nombre, funcion }, (response) => {
          edit == false;
          if (response == 'borrado') {
            Swal.fire(
              'Borrado!',
              'Los datos del pais ' + nombre + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue borrado!',
              'Los datos del pais ' + nombre + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR PAIS SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
  */
  $(document).on('click', '#btn_limpiar_1', (e) => {
    $('#form-crear-pais').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO EDITAR PAIS SE EJECUTA EL EVENTO BTN_LIMPIAR_2.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar_2', (e) => {
    $('#form-editar-pais').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK
  
})