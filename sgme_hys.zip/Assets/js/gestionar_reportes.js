$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  buscar_datos(); /** Inicializar la funcion buscar datos */
  select_tecnico_usu(); /** Inicializar la función seleccionar el tecnico quien realizo el reporte */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let usuario = JSON.parse(response);
        if (usuario.length != 0) {
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA SELECCIONAR EL ID Y EL NOMBRE DEL TECNICO EL CUAL REALIZO EL REPORTE DE SERVICIO.
   * @param {String} response = Este parametro trae el id y el nombre del usuario registrado en la base de datos.
  */
  function select_tecnico_usu() {
    funcion = 'select_tecnico_usu';
    $.post('/sgme_hys/Controllers/control_usuario.php', { funcion }, (response) => {
      const usuarios = JSON.parse(response);
      let template = '';
      usuarios.forEach(usuario => {
        template += `
                <option value="${usuario.id}">${usuario.nombre} ${usuario.apellido}</option>
            `;
      })
      $('#tecnico').html(template);
    });
  }
  // FIN FUNCIÓN SELECCIONAR TECNICO

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR LOS DATOS DEL REPORTE DE SEVICIO.
   * @param {string} inventario = Obtiene el dato del id del equipo que se encuentra en el inventario. Este dato lo envia el input=inventario del formulario crear reporte.
   * @param {string} tipo_servicio = Obtiene el dato del tipo de servicio. Este dato lo envia el input=tipo_servicio del formulario crear reporte.
   * @param {string} otro_servicio = Obtiene el dato si es otro tipo de servicio. Este dato lo envia el input=otro_servicio del formulario crear reporte.
   * @param {string} tipo_asistencia = Obtiene el dato del tipo de asistencia tecnica. Este dato lo envia el input=tipo_asistencia del formulario crear reporte.
   * @param {string} fecha_inicio = Obtiene el dato de la fecha de inicio del mantenimiento. Este dato lo envia el input=fecha_inicio del formulario crear reporte.
   * @param {string} hora_inicio = Obtiene el dato de la hora de inicio del mantenimiento. Este dato lo envia el input=hora_inicio del formulario crear reporte.
   * @param {string} fecha_final = Obtiene el dato de la fecha de finalización del mantenimiento. Este dato lo envia el input=fecha_final del formulario crear reporte.
   * @param {string} hora_final = Obtiene el dato de la hora de finalización del mantenimiento. Este dato lo envia el input=hora_final del formulario crear reporte.
   * @param {string} protocolos = Obtiene el dato del los protocolos de mantenimiento. Este dato lo envia el input=protocolos del formulario crear reporte.
   * @param {string} motivo_servicio = Obtiene el dato del motivo del mantenimiento. Este dato lo envia el input=motivo_servicio del formulario crear reporte.
   * @param {string} estado_equipo = Obtiene el dato del estado del equipo al cual se le realizara el mantenimiento. Este dato lo envia el input=estado_equipo del formulario crear reporte.
   * @param {string} problemas_report = Obtiene el dato de los problemas reportados. Este dato lo envia el input=problemas_report del formulario crear reporte.
   * @param {string} otro_problema = Obtiene el dato del area de servicio donde quedara instalado el equipo. Este dato lo envia el input=otro_problema del formulario crear reporte.
   * @param {string} actividades = Obtiene el dato de las actividades que se realizaron en el mantenimiento. Este dato lo envia el input=actividades del formulario crear reporte.
   * @param {string} observaciones = Obtiene el dato de las observaciones generales del mantenimiento. Este dato lo envia el input=observaciones del formulario crear reporte.
   * @param {string} repto_utilizados = Obtiene el dato de los repuestos utilizados en el mantenimiento. Este dato lo envia el input=repto_utilizados del formulario crear reporte.
   * @param {string} descrip_utilizados = Obtiene el dato de la descripción de los repuestos utilizados. Este dato lo envia el input=descrip_utilizados del formulario crear reporte.
   * @param {string} repto_cotizar = Obtiene el dato de los repuestos a cotizar. Este dato lo envia el input=repto_cotizar del formulario crear reporte.
   * @param {string} descrip_cotizar = Obtiene el dato de la descripción de los repuestos a cotizar. Este dato lo envia el input=descrip_cotizar del formulario crear reporte.
   * @param {string} tecnico = Obtiene el dato del tecnico quien realizo el mantenimiento. Este dato lo envia el input=tecnico del formulario crear reporte.
   */
  $('#form-crear-reporte').submit(e => {
    let inventario = $('#inventario').val();
    let tipo_servicio = $('#tipo_matto').val();
    let otro_servicio = $('#otro_matto').val();
    let tipo_asistencia = $('#asistencia').val();
    let fecha_inicio = $('#fecha_inicio').val();
    let hora_inicio = $('#hora_inicio').val();
    let fecha_final = $('#fecha_final').val();
    let hora_final = $('#hora_final').val();
    let protocolos = $('#protocolos').val();
    let motivo_servicio = $('#motivo_servicio').val();
    let estado_equipo = $('#estado_equipo').val();
    let problemas_report = $('#problemas').val();
    let otro_problema = $('#otro_problema_report').val();
    let actividades = $('#actividades').val();
    let observaciones = $('#observaciones').val();
    let repto_utilizados = $('#cantidad_1').val();
    let descrip_utilizados = $('#descripcion_1').val();
    let repto_cotizar = $('#cantidad_2').val();
    let descrip_cotizar = $('#descripcion_2').val();
    let tecnico = $('#tecnico').val();

    funcion = 'crear_reporte';
    $.post('/sgme_hys/Controllers/control_reporte.php', { inventario, tipo_servicio, otro_servicio, tipo_asistencia, fecha_inicio, hora_inicio, fecha_final, hora_final, protocolos, problemas_report, otro_problema, estado_equipo, motivo_servicio, actividades, observaciones, repto_utilizados, descrip_utilizados, repto_cotizar, descrip_cotizar, tecnico, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El reporte del equipo ' + inventario + ' fue creado correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-reporte').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'No fue posible crear el reporte, intente nuevamente o pongase en contacto con el admin del sistema',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-reporte').trigger('reset');
        buscar_datos();
      }

    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS DATOS DE LOS REPORTES DE SERVICIO.
   * @param {String} consulta = Este parametro trae todos los datoss de los reportes registradas en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_reporte';
    $.post('/sgme_hys/Controllers/control_reporte.php', { consulta, funcion }, (response) => {
      const reportes = JSON.parse(response);
      let template = '';
      reportes.forEach(reporte => {
        template += `
          <tr id_reporte="${reporte.id_reporte}" id_inventario="${reporte.id_inventario}" nombre_equipo="${reporte.equipo}" no_activo="${reporte.no_activo}" marca="${reporte.marca}" modelo="${reporte.modelo}" serie="${reporte.serie}" sede="${reporte.sede}" area="${reporte.area}" fijo_movil="${reporte.fijo_movil}" cliente="${reporte.cliente}" nit_cliente="${reporte.nit_cliente}" tel_cliente="${reporte.tel_cliente}" tipo_contrato="${reporte.tipo_contrato}" no_contrato="${reporte.no_contrato}" direccion_cliente="${reporte.direccion_cliente}" tipo_serv="${reporte.tipo_servicio}"  tipo_asistencia="${reporte.tipo_asistencia}" f_inicio="${reporte.fecha_inicio}" f_final="${reporte.fecha_final}" 
            protocolos="${reporte.protocolos}" motivo_servicio="${reporte.motivo_servicio}" problemas="${reporte.problemas}" otro_problema="${reporte.otro_problema}" actividades="${reporte.actividades}" observaciones="${reporte.observaciones}" repto_utilizados="${reporte.repto_utilizados}" repto_cotizar="${reporte.repto_cotizar}" descrip_utilizados="${reporte.descrip_utilizados}" descrip_cotizar="${reporte.descrip_cotizar}" >
              <td>${reporte.id_reporte}</td>
              <td>${reporte.tipo_asistencia}</td>
              <td>${reporte.fecha_inicio}</td>
              <td>${reporte.fecha_final}</td>
              <td>${reporte.equipo}</td>
              <td>${reporte.serie}</td>
              <td>${reporte.sede}</td>
              <td>${reporte.area}</td>
              <td>${reporte.tipo_servicio}</td>
            <div class="text-right">`;
            if (reporte.id_tipo_sesion == 1) {
              if (reporte.estado == 'PENDIENTE') {
                template += `
                        <td><h1 class="badge badge-info">${reporte.estado}</h1></td>
                        <td>
                          <button class="firmar btn btn-primary" title="Firmar el reporte de servicio" type="button" data-toggle="modal" data-target="#firma_reporte">
                            <i class="fas fa-file-signature"></i>
                          </button>
                          <button class="editar btn btn-primary" title="Editar el reporte de servicio" type="button" data-toggle="modal" data-target="#crear_reporte">
                            <i class="fas fa-pencil-alt"></i>
                          </button>
                          <button class="cancelar btn btn-danger" title="Cancelar el reporte de servicio">
                            <i class="fas fa-times"></i>
                          </button>
                        </td>
                `;
              } else if (reporte.estado == 'FINALIZADO') {
                template += `
                        <td><h1 class="badge badge-danger">${reporte.estado}</h1></td>
                        <td>
                          <button id="generar_reporte" class="btn btn-info" title="Generar Reporte" >
                            <i class="fas fa-file-pdf"></i>
                          </button>
                        </td>
                `;
              } else if (reporte.estado == 'CANCELADO') {
                template += `
                        <td><h1 class="badge badge-danger">${reporte.estado}</h1></td>
                        
                `;
              }
            } else if (reporte.id_tipo_sesion == 2) {
              if (reporte.estado == 'PENDIENTE') {
                template += `
                        <td><h1 class="badge badge-info">${reporte.estado}</h1></td>
                        <td>
                          <button class="firmar btn btn-primary" title="Firmar el reporte de servicio" type="button" data-toggle="modal" data-target="#firma_reporte">
                            <i class="fas fa-file-signature"></i>
                          </button>
                          <button class="editar btn btn-primary" title="Editar el reporte de servicio" type="button" data-toggle="modal" data-target="#crear_reporte">
                            <i class="fas fa-pencil-alt"></i>
                          </button>
                          <button class="cancelar btn btn-danger" title="Cancelar el reporte de servicio">
                            <i class="fas fa-times"></i>
                          </button>
                        </td>
                `;
              } else if (reporte.estado == 'FINALIZADO') {
                template += `
                        <td><h1 class="badge badge-danger">${reporte.estado}</h1></td>
                        <td>
                          <button id="generar_reporte" class="btn btn-info" title="Generar Reporte" >
                            <i class="fas fa-file-pdf"></i>
                          </button>
                        </td>
                `;
              } else if (reporte.estado == 'CANCELADO') {
                template += `
                        <td><h1 class="badge badge-danger">${reporte.estado}</h1></td>
                        
                `;
              }
            } else if (reporte.id_tipo_sesion == 3) {
              if (reporte.estado == 'PENDIENTE') {
                template += `
                        <td><h1 class="badge badge-info">${reporte.estado}</h1></td>
                        <td>
                          <button class="firmar btn btn-primary" title="Firmar el reporte de servicio" type="button" data-toggle="modal" data-target="#firma_reporte">
                            <i class="fas fa-file-signature"></i>
                          </button>
                          <button class="editar btn btn-primary" title="Editar el reporte de servicio" type="button" data-toggle="modal" data-target="#crear_reporte">
                            <i class="fas fa-pencil-alt"></i>
                          </button>
                          <button class="cancelar btn btn-danger" title="Cancelar el reporte de servicio">
                            <i class="fas fa-times"></i>
                          </button>
                        </td>
                `;
              } else if (reporte.estado == 'FINALIZADO') {
                template += `
                        <td><h1 class="badge badge-danger">${reporte.estado}</h1></td>
                        <td>
                          <button id="generar_reporte" class="btn btn-info" title="Generar Reporte" >
                            <i class="fas fa-file-pdf"></i>
                          </button>
                        </td>
                `;
              } else if (reporte.estado == 'CANCELADO') {
                template += `
                        <td><h1 class="badge badge-danger">${reporte.estado}</h1></td>
                        
                `;
              }
            } else if (reporte.id_tipo_sesion == 4) {
              if (reporte.cliente == 1) {
                if (reporte.estado == 'PENDIENTE') {
                  template += `
                          <td><h1 class="badge badge-info">${reporte.estado}</h1></td>
                  `;
                } else if (reporte.estado == 'FINALIZADO' ) {
                  template += `
                          <td><h1 class="badge badge-danger">${reporte.estado}</h1></td>
                          <td>
                            <button id="generar_reporte" class="btn btn-info" title="Generar Reporte" >
                              <i class="fas fa-file-pdf"></i>
                            </button>
                          </td>
                  `;
                } else if (reporte.estado == 'CANCELADO') {
                  template += `
                          <td><h1 class="badge badge-danger">${reporte.estado}</h1></td>
                  `;
                }
              }
            }
        template += `
            </div>
          </tr>
        `;
      })
      $('#reportes').html(template); /** Proyectar el listado de todos los datos de los reportes en la tabla. */
    });
  }
  // FIN FUNCIÓN BUSCAR DATOS

  /**
   * EVENTO BUSCAR, AL PRESIONAR DENTRO DEL BUSCADOR SE EJECUTA LA FUNCIÓN BUSCAR.
   * EL CUAL BUSCA POR UN DATO ESPECIFICO DE UN REPORTE.
  */
  $(document).on('keyup', '#buscar_reporte', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });

  /**
   * EVENTO GENERAR REPORTE, AL PRESIONAR EL BOTON GENERAR REPORTE SE EJECUTA LA FUNCIÓN GENERAR REPORTE.
   * EL CUAL NOS DIRECCIONA AL PDF GENERADO.
  */
  $(document).on('click', '#generar_reporte', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    let id = $(elemento).attr('id_reporte');

    if (elemento != 0) {
      generar_pdf(id);
    }

  });

  /**
   * FUNCIÓN GENERAR EL REPORTE DE SERVICIO EN PDF.
   * @param {String} id = Este parametro envia el id del reporte para generar el reporte de servicio en PDF.
  */
  function generar_pdf(id) {
    $url = '/sgme_hys/reporte/reporte_servicio.php?id=' + id;
    window.open($url);

  }

  /**
   * EVENTO FIRMAR, AL PRESIONAR EL BOTON FIRMAR REPORTE SE EJECUTA LA FUNCIÓN FIRMAR REPORTE.
   * EL CUAL NOS DIRECCIONA AL FORMULARIO PARA FIRMAR EL REPORTE DE SERVICIO.
  */
  $(document).on('click', '.firmar', (e) => {
    funcion = 'firma_reporte';
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id_reporte = $(elemento).attr('id_reporte');
    const equipo_oprtvo = $('#equipo_oprtvo').val();
    const nombre_cliente = $('#nombre_cliente').val();
    const ident_cliente = $('#ident_cliente').val();
    $('#funcion').val(funcion);
    $('#no_reporte').val(id_reporte);
    $('#equipo_operativo').val(equipo_oprtvo);
    $('#nombre_cliente').val(nombre_cliente);
    $('#ident_cliente').val(ident_cliente);

  });
  // FIN EVENTO CLICK

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA ENVIAR LA FIRMA Y EVIDENCIAS FOTOGRAFICAS.
   * @param {string} FormData = Envia los datos del formulario firmar reporte a la base de datos.
   */
  $('#form-firma-reporte').submit(e => {
    let formData = new FormData($('#form-firma-reporte')[0]);
    $.ajax({
      url: '/sgme_hys/Controllers/control_det_reporte.php',
      type: 'POST',
      data: formData,
      cache: false,
      processData: false,
      contentType: false
    }).done(function (response) {
      const json = JSON.parse(response)
      if (json.alert == 'edit') {
        let id_reporte = parseInt(json.id);
        if (id_reporte > 0) {
          funcion = "estado_finalizado";
          $.post('/sgme_hys/Controllers/control_reporte.php', { id_reporte, funcion }, (response2) => {
            if (response2 == 'finalizado') {
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'El reporte Nro ' + id_reporte + ' fue firmado correctamente',
                showConfirmButton: false,
                timer: 1500
              })
              $('#form-firma-reporte').trigger('reset');
              delete_img_cli();
              delete_img_evidencia();
              buscar_datos();
            }
          });
        }
      }
      else {
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA EDITAR LOS DATOS DEL REPORTE DE SEVICIO.
   * @param {string} id = Obtiene el dato del id del reporte de servicio. Este dato lo envia el input=id_reporte del formulario crear reporte.
   * @param {string} inventario = Obtiene el dato del id del equipo que se encuentra en el inventario. Este dato lo envia el input=inventario del formulario crear reporte.
   * @param {string} tipo_servicio = Obtiene el dato del tipo de servicio. Este dato lo envia el input=tipo_servicio del formulario crear reporte.
   * @param {string} otro_servicio = Obtiene el dato si es otro tipo de servicio. Este dato lo envia el input=otro_servicio del formulario crear reporte.
   * @param {string} tipo_asistencia = Obtiene el dato del tipo de asistencia tecnica. Este dato lo envia el input=tipo_asistencia del formulario crear reporte.
   * @param {string} fecha_inicio = Obtiene el dato de la fecha de inicio del mantenimiento. Este dato lo envia el input=fecha_inicio del formulario crear reporte.
   * @param {string} hora_inicio = Obtiene el dato de la hora de inicio del mantenimiento. Este dato lo envia el input=hora_inicio del formulario crear reporte.
   * @param {string} fecha_final = Obtiene el dato de la fecha de finalización del mantenimiento. Este dato lo envia el input=fecha_final del formulario crear reporte.
   * @param {string} hora_final = Obtiene el dato de la hora de finalización del mantenimiento. Este dato lo envia el input=hora_final del formulario crear reporte.
   * @param {string} protocolos = Obtiene el dato del los protocolos de mantenimiento. Este dato lo envia el input=protocolos del formulario crear reporte.
   * @param {string} motivo_servicio = Obtiene el dato del motivo del mantenimiento. Este dato lo envia el input=motivo_servicio del formulario crear reporte.
   * @param {string} estado_equipo = Obtiene el dato del estado del equipo al cual se le realizara el mantenimiento. Este dato lo envia el input=estado_equipo del formulario crear reporte.
   * @param {string} problemas_report = Obtiene el dato de los problemas reportados. Este dato lo envia el input=problemas_report del formulario crear reporte.
   * @param {string} otro_problema = Obtiene el dato del area de servicio donde quedara instalado el equipo. Este dato lo envia el input=otro_problema del formulario crear reporte.
   * @param {string} actividades = Obtiene el dato de las actividades que se realizaron en el mantenimiento. Este dato lo envia el input=actividades del formulario crear reporte.
   * @param {string} observaciones = Obtiene el dato de las observaciones generales del mantenimiento. Este dato lo envia el input=observaciones del formulario crear reporte.
   * @param {string} repto_utilizados = Obtiene el dato de los repuestos utilizados en el mantenimiento. Este dato lo envia el input=repto_utilizados del formulario crear reporte.
   * @param {string} descrip_utilizados = Obtiene el dato de la descripción de los repuestos utilizados. Este dato lo envia el input=descrip_utilizados del formulario crear reporte.
   * @param {string} repto_cotizar = Obtiene el dato de los repuestos a cotizar. Este dato lo envia el input=repto_cotizar del formulario crear reporte.
   * @param {string} descrip_cotizar = Obtiene el dato de la descripción de los repuestos a cotizar. Este dato lo envia el input=descrip_cotizar del formulario crear reporte.
   * @param {string} tecnico = Obtiene el dato del tecnico quien realizo el mantenimiento. Este dato lo envia el input=tecnico del formulario crear reporte.
  */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id');
    const inventario = $(elemento).attr('id_inventario');
    const nombre_equipo = $(elemento).attr('nombre_equipo');
    const no_activo = $(elemento).attr('no_activo');
    const marca = $(elemento).attr('marca');
    const modelo = $(elemento).attr('modelo');
    const serie = $(elemento).attr('serie');
    const sede = $(elemento).attr('sede');
    const area = $(elemento).attr('area');
    const fijo_movil = $(elemento).attr('fijo_movil');
    const cliente = $(elemento).attr('cliente');
    const nit_cliente = $(elemento).attr('nit_cliente');
    const tel_cliente = $(elemento).attr('tel_cliente');
    const tipo_contrato = $(elemento).attr('tipo_contrato');
    const no_contrato = $(elemento).attr(' no_contrato');
    const direccion_cliente = $(elemento).attr('direccion_cliente');
    const tipo_serv = $(elemento).attr('tipo_serv');
    const tipo_asistencia = $(elemento).attr('tipo_asistencia');
    const f_inicio = $(elemento).attr('f_inicio');
    const f_final = $(elemento).attr('f_final');
    const protocolos = $(elemento).attr('protocolos');
    const motivo_servicio = $(elemento).attr('motivo_servicio');
    const problemas = $(elemento).attr('problemas');
    const otro_problema = $(elemento).attr('otro_problema');
    const actividades = $(elemento).attr('actividades');
    const observaciones = $(elemento).attr('observaciones');
    const repto_utilizados = $(elemento).attr('repto_utilizados');
    const repto_cotizar = $(elemento).attr('repto_cotizar');
    const descrip_utilizados = $(elemento).attr('descrip_utilizados');
    const descrip_cotizar = $(elemento).attr('descrip_cotizar');
    const tecnico = $(elemento).attr('tecnico'); 
    $('#id_reporte').val(id);
    $('#inventario').val(inventario);
    $('#evento').val();
    $('#equipo').val(nombre_equipo);
    $('#marca').val(marca);
    $('#modelo').val(modelo);
    $('#serie').val(serie);
    $('#tipo_matto').val();
    $('#otro_matto').val();
    $('#asistencia').val();
    $('#fecha_inicio').val();
    $('#hora_inicio').val();
    $('#fecha_final').val();
    $('#hora_final').val();
    $('#protocolos').val();
    $('#motivo_servicio').val();
    $('#estado_equipo').val();
    $('#problemas').val();
    $('#otro_problema_report').val();
    $('#actividades').val();
    $('#observaciones').val();
    $('#cantidad_1').val();
    $('#descripcion_1').val();
    $('#cantidad_2').val();
    $('#descripcion_2').val();
    $('#equipo_opt').val();
    $('#observ_equipo').val();
    $('#tecnico').val();
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR LOS DATOS DEL REPORTE DE LA TABLA GESTIONAR REPORTES SE EJECUTA EL EVENTO CANCELAR.
   * EL CUAL CANCELA LOS DATOS DEL REPORTE REGISTRADO EN LA BASE DE DATOS.
  */
  $(document).on('click', '.cancelar', (e) => {
    funcion = "eliminar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_reporte');

    Swal.fire({
      title: '¿Desea cancelar el reporte de servicio?',
      text: "Si cancela el reporte de servicio lo puede reactivar de nuevo!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('/sgme_hys/Controllers/control_reporte.php', { id, funcion }, (response) => {
          if (response == 'cancelado') {
            Swal.fire(
              'Cancelado!',
              'El reporte de servicio Nro ' + id + ' fue cancelado.',
              'success'
            )
            buscar_datos();
          } else {
            Swal.fire(
              'No fue cancelado!',
              'No fue posible cancelar el reporte de servicio.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR REPORTE SE EJECUTA EL EVENTO BTN_LIMPIAR.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
  */
  $(document).on('click', '#btn_limpiar', (e) => {
    $('#form-crear-reporte').trigger('reset');
    $('#form-firma-reporte').trigger('reset');
    delete_img_cli();
    delete_img_evidencia();
    buscar_datos();
  });

})
// FIN EVENTO CLICK

/**
  * FUNCIÓN PARA SELECCIONAR OTRO TIPO DE SERVICIO EN EL FORMULARIO CREAR REPORTE.
  * @param {String} id = Este parametro envia el id del otro tipo de servicio en la base de datos.
*/
function otro_servicio(id) {
  if (id == "7") {
    $("#otro_tipo_servicio").show();
  } else {
    $("#otro_tipo_servicio").hide();
  }
}
// FIN FUNCIÓN SELECCIONAR OTRO TIPO DE SERVICIO

/**
  * FUNCIÓN PARA SELECCIONAR OTRO PROBLEMA REPORTADO EN EL FORMULARIO CREAR REPORTE.
  * @param {String} id = Este parametro envia el id del otro problema reportado en la base de datos.
*/
function otro_problema(id) {
  if (id == "10") {
    $("#otro_problema_reportado").show();
  } else {
    $("#otro_problema_reportado").hide();

  }
}
// FIN FUNCIÓN SELECCIONAR OTRO PROBLEMA

/**
  * FUNCIÓN PARA LA PRE VISUALIZACIÓN DE LAS IMAGENES EN EL CAMPO EVIDENCIAS.
  * 
*/
function preview_img_evidencia(e) {
  const url = e.target.files[0];
  const urlTemp = URL.createObjectURL(url);
  document.getElementById("img-preview-evidencia").src = urlTemp;
}
// FIN FUNCIÓN PREVISUALIZAR IMG

/**
  * FUNCIÓN PARA ELIMINAR LA PRE VISUALIZACIÓN DE LAS IMAGENES EN EL CAMPO EVIDENCIAS.
  * 
*/
function delete_img_evidencia(e) {
  document.getElementById("img-preview-evidencia").src = '';
}
// FIN FUNCIÓN DELETE

/**
  * FUNCIÓN PARA LA PRE VISUALIZACIÓN DE LA IMAGEN FIRMA.
  * 
*/
function preview_firma_cl(e) {
  const url = e.target.files[0];
  const urlTemp = URL.createObjectURL(url);
  document.getElementById("img-preview-cli").src = urlTemp;
}
// FIN FUNCIÓN PRE VISUALIZACIÓN

/**
  * FUNCIÓN PARA ELIMINAR LA PRE VISUALIZACIÓN  DE LA IMAGEN FIRMAR
  * 
*/
function delete_img_cli(e) {
  document.getElementById("img-preview-cli").src = '';
}
// FIN FUNCIÓN DELETE