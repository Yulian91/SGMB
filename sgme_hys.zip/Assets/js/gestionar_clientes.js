$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  buscar_datos(); /** Inicializar la funcion buscar datos */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA CREAR LOS DATOS DEL CLIENTE.
   * @param {string} nombre = Obtiene el dato del nombre del cliente. Este dato lo envia el input=nombre del formulario crear cliente.
   * @param {string} nit = Obtiene el dato del nit del cliente. Este dato lo envia el input=nit_cliente del formulario crear cliente.
   * @param {string} telefono = Obtiene el dato del telefono del cliente. Este dato lo envia el input=telefono del formulario crear cliente.
   * @param {string} tipo_contrato = Obtiene el dato del tipo de contrato con el cliente. Este dato lo envia el input=tipo_contrato del formulario crear cliente.
   * @param {string} num_contrato<= Obtiene el dato del numero de contrato con el cliente. Este dato lo envia el input=num_contrato del formulario crear cliente.
   * @param {string} direccion = Obtiene el dato de la dirección del cliente. Este dato lo envia el input=direccion del formulario crear cliente.
   * @param {string} contacto = Obtiene el dato del contacto telefonico del cliente. Este dato lo envia el input=contacto del formulario crear cliente.
   * @param {string} email = Obtiene el dato del correo electronico del cliente. Este dato lo envia el input=email del formulario crear cliente.
   */
  $('#form-crear-cliente').submit(e => {
    let nombre = $('#nombre').val();
    let nit = $('#nit').val();
    let telefono = $('#telefono').val();
    let tipo_contrato = $('#tipo_contrato').val();
    let num_contrato = $('#num_contrato').val();
    let direccion = $('#direccion').val();
    let contacto = $('#name_contacto').val();
    let email = $('#email').val();

    funcion = 'crear_cliente';
    $.post('../../Controllers/control_cliente.php', { nombre, nit, telefono, tipo_contrato, num_contrato, direccion, contacto, email, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El cliente fue agregado correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-cliente').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          'No fue agregado!',
          'El ' + nit + ' del cliente ya existe.',
          'error'
        )
        $('#form-crear-cliente').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA EDITAR LOS DATOS DEL CLIENTE.
   * @param {string} id_cliente = Obtiene el dato del id del cliente el cual se requiere modificar.
   * @param {string} nombre = Obtiene el dato del nombre del cliente el cual se requiere modificar.
   * @param {string} nit = Obtiene el dato del nit del cliente el cual se requiere modificar.
   * @param {string} telefono = Obtiene el dato del telefono del cliente el cual se requiere modificar.
   * @param {string} tipo_contrato = Obtiene el dato del tipo de contrato con el cliente el cual se requiere modificar.
   * @param {string} num_contrato<= Obtiene el dato del numero de contrato con el cliente el cual se requiere modificar.
   * @param {string} direccion = Obtiene el dato de la dirección del cliente el cual se requiere modificar.
   * @param {string} contacto = Obtiene el dato del contacto telefonico del cliente el cual se requiere modificar.
   * @param {string} email = Obtiene el dato del correo electronico del cliente el cual se requiere modificar.
   */
  $('#form-editar-cliente').submit(e => {
    let id_cliente = $('#id_cliente').val();
    let nombre = $('#nombre_cli').val();
    let nit = $('#nit_cli').val();
    let telefono = $('#telefono_cli').val();
    let tipo_contrato = $('#tipo_contrato_cli').val();
    let num_contrato = $('#no_contrato_cli').val();
    let direccion = $('#direccion_cli').val();
    let contacto = $('#name_contacto_cli').val();
    let email = $('#email_cli').val();

    funcion = 'editar_cliente';
    $.post('../../Controllers/control_cliente.php', { id_cliente, nombre, nit, telefono, tipo_contrato, num_contrato, direccion, contacto, email, funcion }, (response) => {
      console.log(response);
      if (response == 'update') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del cliente ' + nombre + ' se actualizaron correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-cliente').trigger('reset');
        buscar_datos();
      } else {
        Swal.fire(
          'No fue actualizado!',
          'Los datos del cliente ' + nombre + ' no se actualizaron.',
          'error'
        )
        $('#form-crear-cliente').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * FUNCIÓN PARA BUSCAR Y OBTENER TODOS LOS DATOS DE LOS CLIENTES.
   * @param {String} consulta = Este parametro trae todos los datoss de los clientes registradas en la base de datos.
  */
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_cliente';
    $.post('../../Controllers/control_cliente.php', { consulta, funcion }, (response) => {
      const clientes = JSON.parse(response);
      let template = '';
      clientes.forEach(cliente => {
        template += `
            <tr idcliente="${cliente.id_cliente}" nombrecliente="${cliente.nombre_cliente}" nitcliente="${cliente.nit_cliente}" telefonocliente="${cliente.telefono_cliente}"
              tipocontrato="${cliente.tipo_contrato}" numcontrato="${cliente.num_contrato}" direccioncliente="${cliente.direccion_cliente}" contacto="${cliente.nombre_contacto}" 
              emailcliente="${cliente.email_cliente}">
              <td>${cliente.nombre_cliente}</td>
              <td>${cliente.nit_cliente}</td>
              <td>${cliente.telefono_cliente}</td>
              <td>${cliente.tipo_contrato}</td>
              <td>${cliente.num_contrato}</td>
              <td>${cliente.direccion_cliente}</td>
              <td>${cliente.email_cliente}</td>
              <td>${cliente.nombre_contacto}</td>
                <div class="text-right">`;
                  if (cliente.estatus == 'ACTIVO') {
                    template += `
                      <td><h1 class="badge badge-info">${cliente.estatus}</h1></td>
                      <td>
                        <button class="editar btn btn-primary" title="Editar los datos del cliente" type="button" data-toggle="modal" data-target="#editar_cliente">
                          <i class="fas fa-pencil-alt"></i>
                        </button>
                        <button class="inhabilitar btn btn-danger" title="Inactivar los datos del cliente">
                          <i class="fas fa-times"></i>
                        </button>
                      </td>
                    `;
                  } else {
                    template += `
                      <td><h1 class="badge badge-danger">${cliente.estatus}</h1></td>
                      <td>
                        <button class="habilitar btn btn-primary" title="Activar los datos del cliente">
                          <i class="fas fa-check-square"></i>
                        </button>
                        <button class="eliminar btn btn-danger" title="Eliminar definitivamente los datos del cliente">
                          <i class="fas fa-trash-alt"></i>
                        </button>
                      </td>
                    `;
                  }
                  template += `
                </div>
            </tr>
          `;
                })
      $('#clientes').html(template); /** Proyectar el listado de todos los datos de los clientes en la tabla. */
    });
  }
  // FIN FUNCIÓN BUSCAR DATOS

  /**
   * EVENTO BUSCAR, AL PRESIONAR DENTRO DEL BUSCADOR SE EJECUTA LA FUNCIÓN BUSCAR.
   * EL CUAL BUSCA POR UN DATO ESPECIFICO DE UN CLIENTE.
  */
  $(document).on('keyup', '#buscar_cliente', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });
  // FIN EVENTO BUSCAR

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DEL CLIENTE SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE LOS DATOS DEL CLIENTE REGISTRADOS EN LA BD PARA MODIFICAR.
   */
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idcliente');
    const nombre = $(elemento).attr('nombrecliente');
    const nit = $(elemento).attr('nitcliente');
    const telefono = $(elemento).attr('telefonocliente');
    const tipo_contrato = $(elemento).attr('tipocontrato');
    const num_contrato = $(elemento).attr('numcontrato');
    const direccion = $(elemento).attr('direccioncliente');
    const contacto = $(elemento).attr('contacto');
    const email = $(elemento).attr('emailcliente');
    $('#id_cliente').val(id);
    $('#nombre_cli').val(nombre);
    $('#nit_cli').val(nit);
    $('#telefono_cli').val(telefono);
    $('#tipo_contrato_cli').val(tipo_contrato);
    $('#no_contrato_cli').val(num_contrato);
    $('#direccion_cli').val(direccion);
    $('#name_contacto_cli').val(contacto);
    $('#email_cli').val(email);
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON INACTIVAR DATOS DEL CLIENTE DE LA TABLA GESTIONAR CLIENTES SE EJECUTA EL EVENTO INHABILITAR.
   * EL CUAL INHABILITA LOS DATOS DEL LA CLIENTE Y NO SE PODRA REALIZAR NINGUNA DE LAS OPCIONES COMO EDITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.inhabilitar', (e) => {
    funcion = "inhabilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idcliente');
    const nombre = $(elemento).attr('nombrecliente');
    const nit = $(elemento).attr('nitcliente');
    const telefono = $(elemento).attr('telefonocliente');
    const tipo_contrato = $(elemento).attr('tipocontrato');
    const num_contrato = $(elemento).attr('numcontrato');
    const direccion = $(elemento).attr('direccioncliente');
    const usuario = $(elemento).attr('usuario');
    const email = $(elemento).attr('emailcliente');

    Swal.fire({
      title: '¿Desea inactivar el cliente ' + nombre + '?',
      text: "El cliente sera inactivado, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_cliente.php', { id, funcion }, (response) => {
          if (response == 'inactivado') {
            Swal.fire(
              'Inactivado!',
              'El cliente ' + nombre + ' fue inactivado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue inactivado!',
              'El cliente ' + nombre + ' no fue inactivado.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK
  
   /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ACTIVAR DATOS DEL CLIENTE DE LA TABLA GESTIONAR CLIENTES SE EJECUTA EL EVENTO HABILITAR.
   * EL CUAL HABILITA LOS DATOS DEL CLIENTE Y SE PODRA REALIZAR LAS OPCIONES DE EDITAR, INHABILITAR, BORRAR, ENTRE OTRAS.
   */
  $(document).on('click', '.habilitar', (e) => {
    funcion = "habilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idcliente');
    const nombre = $(elemento).attr('nombrecliente');
    const nit = $(elemento).attr('nitcliente');
    const telefono = $(elemento).attr('telefonocliente');
    const tipo_contrato = $(elemento).attr('tipocontrato');
    const num_contrato = $(elemento).attr('numcontrato');
    const direccion = $(elemento).attr('direccioncliente');
    const usuario = $(elemento).attr('usuario');
    const email = $(elemento).attr('emailcliente');

    Swal.fire({
      title: '¿Desea activar el cliente ' + nombre + '?',
      text: "Los datos del cliente seran activados!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_cliente.php', { id, funcion }, (response) => {
          if (response == 'activo') {
            Swal.fire(
              'Activado!',
              'Los datos del cliente ' + nombre + ' fueron activados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue activado!',
              'Los datos del cliente ' + nombre + ' no fueron activados.',
              'error'
            )
          }
        });
      }
    })
  });
   // FIN EVENTO CLICK

   /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON ELIMINAR LOS DATOS DEL CLIENTE DE LA TABLA GESTIONAR CLIENTES SE EJECUTA EL EVENTO ELIMINAR.
   * EL CUAL BORRA LOS DATOS DEL CLIENTE REGISTRADO EN LA BASE DE DATOS.
   */
  $(document).on('click', '.eliminar', (e) => {
    funcion = "eliminar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idcliente');
    const nombre = $(elemento).attr('nombrecliente');
    const nit = $(elemento).attr('nitcliente');
    const telefono = $(elemento).attr('telefonocliente');
    const tipo_contrato = $(elemento).attr('tipocontrato');
    const num_contrato = $(elemento).attr('numcontrato');
    const direccion = $(elemento).attr('direccioncliente');
    const usuario = $(elemento).attr('usuario');
    const email = $(elemento).attr('emailcliente');

    Swal.fire({
      title: 'Desea eliminar el cliente ' + nombre + '?',
      text: "Los datos del cliente seran borrados de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_cliente.php', { id, funcion }, (response) => {
          if (response == 'delete') {
            Swal.fire(
              'Borrado!',
              'Los datos del cliente ' + nombre + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue borrado!',
              'Los datos del cliente ' + nombre + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN EVENTO CLICK

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO CREAR CIUDAD SE EJECUTA EL EVENTO BTN_LIMPIAR_1.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar_1', (e) => {
    $('#form-crear-cliente').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

   /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO EDITAR CIUDAD SE EJECUTA EL EVENTO BTN_LIMPIAR_2.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar_2', (e) => {
    $('#form-editar-cliente').trigger('reset');
    buscar_datos();
  });
  // FIN EVENTO CLICK

})