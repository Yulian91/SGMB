$(document).ready(function () {
  var funcion = ''; /** Declarar e inicializar la variable funcion */
  var id_usuario = $('#id_usuario').val(); /** Declarar e inicializar la variable id_usuario */
  buscar_usuario(id_usuario); /** Inicializar la función buscar datos con la variable */
  mostrarPassword1(); /** Inicializar la función mostrar contraseña */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA EL ESTADO DE LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let usuario = JSON.parse(response);
        if (usuario.length != 0) {
          close_loader()
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }
  // FIN FUNCIÓN VERIFICAR SESIÓN

  /**
   * FUNCIÓN PARA PROYECTAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Este parametro nos notificara si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Un momento por favor, Cargando datos.....";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }
  // FIN FUNCIÓN PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA CERRAR LA PANTALLA DE CARGA CUANDO TERMINA DE TRAEE LOS DATOS DESDE EL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }
  // FIN FUNCIÓN CERRAR PANTALLA DE CARGA

  /**
   * FUNCIÓN PARA MOSTRAR LOS DATOS PERSONALES DE ALGUN USUARIO ESPECIFICO.
   * @param {String} dato = Este parametro trae todos los datos del usuario registrado en la base de datos.
   * @param {String} funcion = Esta función es para realizar la busqueda de los datos del usuario especifico.
  */
  function buscar_usuario(dato) {
    funcion = 'buscar_usuario';
    $.post('/sgme_hys/Controllers/control_usuario.php', { dato, funcion }, (response) => {
      let nombre = '';
      let apellidos = '';
      let email = '';
      let identificacion = '';
      let tipo = '';
      let contacto = '';
      let direccion = '';
      const usuario = JSON.parse(response);
      nombre += `${usuario.nombre}`;
      apellidos += `${usuario.apellidos}`;
      email += `${usuario.email}`;
      identificacion += `${usuario.identificacion}`;
      tipo += `${usuario.tipo}`;
      contacto += `${usuario.contacto}`;
      direccion += `${usuario.direccion}`;
      $('#nombre').html(nombre);
      $('#apellidos').html(apellidos);
      $('#identificacion').html(identificacion);
      $('#tipo_usu').html(tipo);
      $('#email').html(email);
      $('#telefono').html(contacto);
      $('#direccion').html(direccion);
    })
  }
  // FIN EVENTO SUBMIT

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON EDITAR LOS DATOS DEL USUARIO SE EJECUTA EL EVENTO EDITAR.
   * EL CUAL TRAE LOS DATOS DEL USUARIO EN ESPECIFICO REGISTRADO EN LA BASE DE DATOS PARA MODIFICAR.
   */
  $(document).on('click', '.edit', (e) => {
    funcion = 'capturar_datos';
    $.post('/sgme_hys/Controllers/control_usuario.php', { funcion, id_usuario }, (response) => {
      const usuario = JSON.parse(response);
      $('#nombre_usu').val(usuario.nombre);
      $('#apellidos_usu').val(usuario.apellidos);
      $('#identificacion_usu').val(usuario.identificacion);
      $('#email_usu').val(usuario.email);
      $('#contacto_usu').val(usuario.contacto);
      $('#direccion_usu').val(usuario.direccion);

      /**
      * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA EDITAR LOS DATOS DE UN USUARIO EN ESPECIFICO.
      * @param {string} nombre = Obtiene el dato del nombre del usuario el cual se requiere modificar.
      * @param {string} apellidos = Obtiene el dato del apellido el cual se requiere modificar.
      * @param {string} identificacion = Obtiene el dato del numero de identificacón del usuario el cual se requiere modificar.
      * @param {string} email = Obtiene el dato del correo del usuario el cual se requiere modificar.
      * @param {string} contacto = Obtiene el dato del contacto del usuario el cual se requiere modificar.
      * @param {string} direccion = Obtiene el dato de la dirección del usuario el cual se requiere modificar. 
      */
      $('#form-usuario').submit(e => {
        let nombre = $('#nombre_usu').val();
        let apellidos = $('#apellidos_usu').val();
        let identificacion = $('#identificacion_usu').val();
        let email = $('#email_usu').val();
        let contacto = $('#contacto_usu').val();
        let direccion = $('#direccion_usu').val();
        funcion = 'editar_datos';
        $.post('/sgme_hys/Controllers/control_usuario.php', { funcion, id_usuario, nombre, apellidos, identificacion, email, contacto, direccion }, (response) => {
          if (response == 'update_datos') {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: 'Los datos del usuario ' + nombre + ' ' + apellidos + ' se actualizaron correctamente',
              showConfirmButton: false,
              timer: 1500
            })
            $('#form-usuario').trigger('reset');
            edit = false;
            buscar_usuario(id_usuario);
          }
        })
        e.preventDefault();
      });
    })
  });
  // FIN EVENTO CLICK Y SUBMIT

  /**
  * EVENTO SUBMIT, CONTIENE LA FUNCIÓN PARA EDITAR  LOS DATOS DEL EQUIPO.
  * @param {string} clave_anterior = Obtiene el dato de la contraseña anterior la cual se requiere modificar.
  * @param {string} nueva_clave = Obtiene el dato de la nueva contraseña.
  * @param {string} funcion = Función para cambiar la contraseña de un usuario especifico.
  */
  $('#form-clave').submit(e => {
    let clave_anterior = $('#clave_anterior').val();
    let nueva_clave = $('#nueva_clave').val();
    funcion = 'cambiar_clave';
    $.post('/sgme_hys/Controllers/control_usuario.php', { id_usuario, clave_anterior, nueva_clave, funcion }, (response) => {
      if (response == 'update') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Se cambio la contraseña correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-clave').trigger('reset');
      }
      if (response == 'noupdate') {
        Swal.fire(
          'La contraseña no se puede cambiar',
          'Intenta nuevamente',
          'error'
        )
        $('#form-clave').trigger('reset');
      }
    })
    e.preventDefault();
  });
  // FIN EVENTO SUBMIT

  /**
   * EVENTO CLICK, AL PRESIONAR EL BOTON CANCELAR DEL FORMULARIO EDITAR DATOS DEL USUARIO SE EJECUTA EL EVENTO BTN_LIMPIAR.
   * EL CUAL LIMPIARA LOS CAMPOS DEL FORMULARIO PARA DEJARLOS VACIOS.
   */
  $(document).on('click', '#btn_limpiar', (e) => {
    $('#form-clave').trigger('reset');
  });
  // FIN EVENTO CLICK

  /**
   * FUNCIÓN PARA MOSTRAR LA CONTRASEÑA DEL USUARIO.
   * @param {String} mostrar = Este parametro trae la clave anterior y la muestra.
  */
  function mostrarPassword1() {
    var mostrar = document.getElementById("clave_anterior");
    if (mostrar.type == "password") {
      mostrar.type = "text";
      $('.icon').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
    } else {
      mostrar.type = "password";
      $('.icon').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
    }
  }
  // FIN EVENTO FUNCIÓN PARA MOSTRAR PASSWORD.

})