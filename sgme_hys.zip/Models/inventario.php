<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php'; // Ruta para la conexión a la base de datos.

// Clase para realizar la conexión pdo
class Inventario
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  /* Función para crear los datos del equipo en el iventario en la base de datos */
  function Crear_Inventario($id_equipo, $frecuencia_mtto, $fijo_movil, $cliente, $pais, $ciudad, $sede, $area)
  {
    $sql = "SELECT id_inventario FROM inventario WHERE equipo=:equipo";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':equipo' => $id_equipo));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO inventario(equipo,frecuencia_matto,fijo_movil,cliente,pais,ciudad,sede,area) 
            VALUES (:equipo,:frecuencia,:fijo_movil,:cliente,:pais,:ciudad,:sede,:area);";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(
        ':equipo' => $id_equipo, ':frecuencia' => $frecuencia_mtto, ':fijo_movil' => $fijo_movil, ':cliente' => $cliente,
        ':pais' => $pais, ':ciudad' => $ciudad, ':sede' => $sede, ':area' => $area
      ));
      echo 'add';
    }
  }
  /* Fin función */

  /* Función para editar los datos del equipo en el iventario en la base de datos */
  function editar($id_editado, $equipo, $frecuencia_mtto, $fijo_movil, $cliente, $pais, $ciudad, $sede, $area)
  {
    $sql = "UPDATE inventario SET equipo=:equipo, frecuencia_matto=:frecuencia, fijo_movil=:fijo_movil, cliente=:cliente, 
        pais=:pais, ciudad=:ciudad, sede=:sede, area=:area WHERE id_inventario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(
      ':id' => $id_editado, ':equipo' => $equipo, ':frecuencia' => $frecuencia_mtto, ':fijo_movil' => $fijo_movil,
      ':cliente' => $cliente, ':pais' => $pais, ':ciudad' => $ciudad, ':sede' => $sede, ':area' => $area
    ));
    echo 'edit';
  }
  /* Fin función */

  /* Función para buscar los datos de los equipos del inventario en la base de datos */
  function buscar_inventario()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_inventario, fecha_add AS fecha_ingreso, equipo.nombre, equipo.no_activo, equipo.marca, equipo.modelo, equipo.serie, frecuencia_matto, fijo_movil, cliente.nombre_rz, pais.nombre_pais as ubi_pais, ciudad.nombre_ciudad as ubi_ciudad, sede.nombre_sede as ubi_sede, area.nombre_area as ubi_area, equipo, cliente, pais, ciudad, sede, area
            FROM inventario
            INNER JOIN cliente ON inventario.cliente=cliente.id_cliente
            INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
            INNER JOIN pais ON inventario.pais=pais.id_pais
            INNER JOIN ciudad ON inventario.ciudad=ciudad.id_ciudad
            INNER JOIN sede ON inventario.sede=sede.id_sede
            INNER JOIN area ON inventario.area=area.id_area AND fecha_add LIKE :consulta LIMIT 1000;";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_inventario, fecha_add AS fecha_ingreso, equipo.nombre, equipo.no_activo, equipo.marca, equipo.modelo, equipo.serie, frecuencia_matto, fijo_movil, cliente.nombre_rz, pais.nombre_pais as ubi_pais, ciudad.nombre_ciudad as ubi_ciudad, sede.nombre_sede as ubi_sede, area.nombre_area as ubi_area, equipo, cliente, pais, ciudad, sede, area
            FROM inventario
            INNER JOIN cliente ON inventario.cliente=cliente.id_cliente
            INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
            INNER JOIN pais ON inventario.pais=pais.id_pais
            INNER JOIN ciudad ON inventario.ciudad=ciudad.id_ciudad
            INNER JOIN sede ON inventario.sede=sede.id_sede
            INNER JOIN area ON inventario.area=area.id_area AND fecha_add NOT LIKE '' ORDER BY id_inventario LIMIT 1000;";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  /* Fin función */

  /* Función eliminar los datos del equipo en el inventario en la base de datos */
  function eliminar_inv($id_inv)
  {
    $sql = "DELETE FROM inventario WHERE id_inventario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_inv));
    if (!empty($query->execute(array(':id' => $id_inv)))) {
      echo 'delete';
    } else {
      echo 'no_delete';
    }
  }
  /* Fin función */

  /* Función para seleccionar los datos del equipo que se encuentran en el inventario */
  function select_inventario()
  {
    $sql = "SELECT id_inventario, equipo.nombre AS nombre_equipo, equipo.marca, equipo.serie
        FROM inventario
        INNER JOIN equipo ON inventario.equipo=equipo.id_equipo";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */

  /* Función para contar cuantos equipos se encuentran registrados en la base de datos */
  function total_equipos()
  {
    $sql = "SELECT COUNT(*) AS total_registro FROM inventario";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */
}

// Fin de la clase.
