<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php'; // Ruta para la conexión a la base de datos.

// Clase para realizar la conexión pdo
class Paises{
    var $objetos;
    public function __construct(){
        $db = new Conexion();
        $this->acceso = $db->pdo;
    }

    /* Función para crear los datos del pais en la base de datos */
    function crear_pais($nombre){
        $sql = "SELECT id_pais FROM pais WHERE nombre_pais=:nombre";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':nombre'=>$nombre));
        $this->objetos = $query->fetchall();
        if (!empty($this->objetos)) {
            echo 'noadd';
        }
        else {
            $sql = "INSERT INTO pais(nombre_pais) VALUES (:nombre);";
            $query = $this->acceso->prepare($sql);
            $query->execute(array(':nombre'=>$nombre));
            echo 'add';
        }
    }
    /* Fin función */

  /* Función para editar los datos del pais en la base de datos */
    function editar_pais($id_pais,$nombre){
        $sql = "UPDATE pais SET nombre_pais=:nombre WHERE id_pais=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id_pais,':nombre'=>$nombre));
        echo 'update';
    }
    /* Fin función */

    /* Función para buscar los datos del paises en la base de datos */
    function buscar_pais(){
        if(!empty($_POST['consulta'])){
            $consulta = $_POST['consulta'];
            $sql = "SELECT * FROM pais WHERE nombre_pais LIKE :consulta";
            $query = $this->acceso->prepare($sql);
            $query->execute(array(':consulta'=>"%$consulta%"));
            $this->objetos = $query->fetchall();
            return $this->objetos;
        }
        else{
            $sql = "SELECT * FROM pais WHERE nombre_pais NOT LIKE '' ORDER BY id_pais LIMIT 25";
            $query = $this->acceso->prepare($sql);
            $query->execute();
            $this->objetos = $query->fetchall();
            return $this->objetos;
        }
    }
    /* Fin función */

    /* Función para inhabilitar los datos del pais en la base de datos */
    function inhabilitar($id){
        $sql = "UPDATE pais SET estatus_pais = 'INHABILITADO' WHERE id_pais=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id));
        if (!empty($query->execute(array(':id'=>$id)))) {
            echo 'inactivado';
        }
        else {
            echo 'no_inactivado';
        }
    }
    /* Fin función */

    /* Función para habilitar los datos del pais en la base de datos */
    function habilitar($id){
        $sql = "UPDATE pais SET estatus_pais = 'ACTIVO' WHERE id_pais=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id));
        if (!empty($query->execute(array(':id'=>$id)))) {
            echo 'activo';
        }
        else {
            echo 'noactivo';
        }
    }
    /* Fin función */

    /* Función para eliminar los datos del pais en la base de datos */
    function eliminar_pais($id){
        $sql = "DELETE FROM pais WHERE id_pais=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id));
        if (!empty($query->execute(array(':id'=>$id)))) {
            echo 'borrado';
        }
        else {
            echo 'noborrado';
        }
    }
    /* Fin función */

    /* Función para seleccionar los datos de los paises que se encuentren activos en la base de datos */
    function select_pais(){
        $sql = "SELECT * FROM pais WHERE estatus_pais = 'ACTIVO' ORDER BY estatus_pais";
        $query = $this->acceso->prepare($sql);
        $query->execute();
        $this->objetos = $query->fetchall();
        return $this->objetos;
    }
    /* Fin función */
}

// Fin de la clase.
?>