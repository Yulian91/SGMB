<?php
// Ruta para la conexión a la base de datos.
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php';

// Clase para realizar la conexión pdo
class Solicitud
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  /* Función para crear los datos de la solicitud de servicio en la base de datos */
  function Crear_Solicitud($inventario,$tipo,$prioridad,$usuario,$motivo)
  {
    $sql = "SELECT id_solicitud FROM solicitud WHERE tipo_sol=:prioridad";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':prioridad' => $prioridad));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO solicitud(inventario,tipo_sol,prioridad_sol,usuario_cli,motivo_servicio) VALUES (:inventario,:tipo,:prioridad,:usuario,:motivo);";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':inventario' => $inventario, ':tipo' => $tipo, ':prioridad' => $prioridad, ':usuario' => $usuario, ':motivo' => $motivo));
      echo 'add';
    }
  }
  /* Fin función */

  /* Función para editar los datos de la solicitud de servicio en la base de datos */
  function Editar_Solicitud($id_solicitud,$inventario,$tipo,$prioridad,$usuario,$motivo)
  {
    $sql = "UPDATE solicitud SET inventario=:inventario, tipo_sol=:tipo, prioridad_sol=:prioridad, usuario_cli=:usuario, motivo_servicio=:motivo WHERE id_solicitud=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_solicitud, ':inventario' => $inventario, ':tipo' => $tipo, ':prioridad' => $prioridad, ':usuario' => $usuario, ':motivo' => $motivo));
    echo 'edit';
  }
  /* Fin función */

  /* Función para buscar los datos de la solicitudes de servicio en la base de datos */
  function buscador_solicitudes()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_solicitud, inventario, equipo.nombre AS nombre_equipo, equipo.marca AS marca_equipo, cliente.id_cliente ,cliente.nombre_rz AS nombre_cliente, fecha_hora, tipo_sol, prioridad_sol, usuario_cli, motivo_servicio, estatus_sol
      FROM solicitud
      INNER JOIN inventario ON solicitud.inventario=inventario.id_inventario
      INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
      INNER JOIN cliente ON inventario.cliente=cliente.id_cliente AND id_solicitud LIKE :consulta LIMIT 1000";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_solicitud, inventario, equipo.nombre AS nombre_equipo, equipo.marca AS marca_equipo, cliente.id_cliente ,cliente.nombre_rz AS nombre_cliente, fecha_hora, tipo_sol, prioridad_sol, usuario_cli, motivo_servicio, estatus_sol
      FROM solicitud
      INNER JOIN inventario ON solicitud.inventario=inventario.id_inventario
      INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
      INNER JOIN cliente ON inventario.cliente=cliente.id_cliente AND inventario NOT LIKE '' ORDER BY id_solicitud LIMIT 1000";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  /* Fin función */

  /* Función para buscar los datos de las solicitudes de servicio pendientes en la base de datos */
  function buscar_solicitudes_pend()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_solicitud, inventario, equipo.nombre AS nombre_equipo, equipo.marca AS marca_equipo, cliente.nombre_rz AS nombre_cliente, fecha_hora, tipo_sol, prioridad_sol, usuario_cli, motivo_servicio, estatus_sol
      FROM solicitud
      INNER JOIN inventario ON solicitud.inventario=inventario.id_inventario
      INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
      INNER JOIN cliente ON inventario.cliente=cliente.id_cliente WHERE estatus_sol = 'PENDIENTE'";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_solicitud, inventario, equipo.nombre AS nombre_equipo, equipo.marca AS marca_equipo, cliente.nombre_rz AS nombre_cliente, fecha_hora, tipo_sol, prioridad_sol, usuario_cli, motivo_servicio, estatus_sol
      FROM solicitud
      INNER JOIN inventario ON solicitud.inventario=inventario.id_inventario
      INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
      INNER JOIN cliente ON inventario.cliente=cliente.id_cliente WHERE estatus_sol = 'PENDIENTE'";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  /* Fin función */

  /* Función para cambiar el estado de la solicitud de servicio en la base de datos */
  function estado_proceso($id)
  {
    $sql = "UPDATE solicitud SET estatus_sol = 'PROCESO' WHERE id_solicitud=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'proceso';
    } else {
      echo 'no_proceso';
    }
  }
  /* Fin función */

  /* Función para reactivar la solicitud de servicio en la base de datos */
  function estado_reactivar($id)
  {
    $sql = "UPDATE solicitud SET estatus_sol = 'PENDIENTE' WHERE id_solicitud=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'reactivar';
    } else {
      echo 'no_reactivar';
    }
  }
  /* Fin función */

  /* Función para cancelar la solicitud de servicio en la base de datos */
  function estado_cancelar($id)
  {
    $sql = "UPDATE solicitud SET estatus_sol = 'CANCELADO' WHERE id_solicitud=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'cancelado';
    } else {
      echo 'no_cancelado';
    }
  }
  /* Fin función */

  /* Función para cerrar la solicitud de servicio en la base de datos */
  function estado_cerrado($id)
  {
    $sql = "UPDATE solicitud SET estatus_sol = 'FINALIZADO' WHERE id_solicitud=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'cerrado';
    } else {
      echo 'no_cerrado';
    }
  }
  /* Fin función */

  /* Función para eliminar la solicitud de servicio en la base de datos */
  function eliminar($id)
  {
    $sql = "DELETE FROM solicitud WHERE id_solicitud=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'delete';
    } else {
      echo 'nodelete';
    }
  }
  /* Fin función */

  /* Función para buscar por numero de solicitud de servicio en la base de datos */
  function num_solicitud()
  {
    $sql = "SELECT * FROM solicitud ORDER BY id_solicitud desc limit 1";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $row = mysqli_fetch_array($query);
    $lastid = $row['id_solicitud'];
    if ($lastid == "") {
      $num = "SOL-";
    } else {
      $num = substr($lastid, 3);
      $num = intval($num);
      $num = "SOL-" . ($num + 1);
    }
  }
  /* Fin función */

  /* Función para contar cuantos reportes de servicio se encuentran registrados en la base de datos */
  function total_solicitudes()
  {
    $sql = "SELECT COUNT(*) AS total_registro FROM solicitud";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */
}

// Fin de la clase.
