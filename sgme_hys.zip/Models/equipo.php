<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php'; // Ruta para la conexión a la base de datos.

// Clase para realizar la conexión pdo
class Equipo
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  /* Función para crear los datos del equipo en la base de datos */
  function Crear_Equipo($nombre_equipo, $n_activo, $marca, $modelo, $serie, $pro_terc, $estado, $garantia)
  {
    $sql = "SELECT id_equipo FROM equipo WHERE serie=:serie";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':serie' => $serie));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO equipo(nombre,no_activo,marca,modelo,serie,propio_tercero,estado,garantia) 
            VALUES (:nombre,:n_activo,:marca,:modelo,:serie,:pro_terc,:estado,:garantia)";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(
        ':nombre' => $nombre_equipo, ':n_activo' => $n_activo, ':marca' => $marca, ':modelo' => $modelo, ':serie' => $serie,
        ':pro_terc' => $pro_terc, ':estado' => $estado, ':garantia' => $garantia
      ));
      echo 'add';
    }
  }
  /* Fin función */

  /* Función para editar los datos del equipo en la base de datos */
  function editar($id_editado, $nombre_equipo, $n_activo, $marca, $modelo, $serie, $pro_terc, $estado, $garantia)
  {
    $sql = "UPDATE equipo SET nombre=:nombre, no_activo=:n_activo, marca=:marca, modelo=:modelo, serie=:serie,
        propio_tercero=:pro_terc, estado=:estado, garantia=:garantia WHERE id_equipo=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(
      ':id' => $id_editado, ':nombre' => $nombre_equipo, ':n_activo' => $n_activo, ':marca' => $marca, ':modelo' => $modelo,
      ':serie' => $serie, ':pro_terc' => $pro_terc, ':estado' => $estado, ':garantia' => $garantia
    ));
    echo 'update';
  }
  /* Fin función */

  /* Función para buscar los datos de los equipos en la base de datos */
  function buscador_equipos()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_equipo, nombre, no_activo, marca, modelo, serie, propio_tercero, estado, garantia, estatus_eq
            FROM equipo WHERE no_activo LIKE :consulta LIMIT 1000";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_equipo, nombre, no_activo, marca, modelo, serie, propio_tercero, estado, garantia, estatus_eq
            FROM equipo WHERE no_activo NOT LIKE '' ORDER BY id_equipo LIMIT 1000";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  /* Fin función */

  /* Función para actualizar el estado del equipo en la base de datos */
  function arrendar($id_equipo)
  {
    $sql = "UPDATE equipo SET estatus_eq = 'EN CONTRATO A/M' WHERE id_equipo=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_equipo));
    if (!empty($query->execute(array(':id' => $id_equipo)))) {
      echo 'arrendado';
    } else {
      echo 'no_arrendado';
    }
  }
  /* Fin función */

  /* Función para actualizar el estado  del equipo en la base de datos */
  function no_arrendar($id)
  {
    $sql = "UPDATE equipo SET estatus_eq = 'STOCK' WHERE id_equipo=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'stock';
    } else {
      echo 'no_stock';
    }
  }
  /* Fin función */

  /* Función eliminar los datos del equipo en la base de datos */
  function eliminar_eq($id)
  {
    $sql = "DELETE FROM equipo WHERE id_equipo=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'delete';
    } else {
      echo 'nodelete';
    }
  }
  /* Fin función */

  /* Función para seleccionar solo los equipos que se encuentren en estado STOCK en la base de datos */
  function select_equipo()
  {
    $sql = "SELECT * FROM equipo WHERE estatus_eq = 'STOCK' ORDER BY estatus_eq";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */
}

// Fin de la clase.
