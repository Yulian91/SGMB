<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php'; // Ruta para la conexión a la base de datos.

// Clase para realizar la conexión pdo
class Reporte
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  /* Función para crear los datos del reporte en la base de datos */
  function crear_reporte($inventario, $tipo_servicio, $otro_servicio, $tipo_asistencia, $fecha_inicio, $hora_inicio, $fecha_final, $hora_final, $protocolos, $problemas_report, $otro_problema, $motivo_servicio, $estado_equipo, $actividades, $observaciones, $repto_utilizados, $descrip_utilizados, $repto_cotizar, $descrip_cotizar, $tecnico)
  {
    $sql = "SELECT id_reporte FROM reporte WHERE id_reporte = :otro_servicio";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':otro_servicio' => $otro_servicio));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO reporte(inventario,tipo_servicio,otro_servicio,tipo_asistencia,fecha_inicio,hora_inicio,fecha_final,hora_final,protocolo_matto,motivo_servicio,estdo_inicial_equipo,problemas_report,otro_problema,actividad_realizada,observa_general,cant_repto_utilizados,cant_repto_cotizar,descrip_repto_utilizados,descrip_repto_cotizar,tecnico_usuario)
      VALUES (:inventario,:tipo_servicio,:otro_servicio,:tipo_asistencia,:f_inicio,:h_inicio,:f_final,:h_final,:protocolos,:motivo_servicio,:estado_equipo,:problemas,:otro_problema,:actividades,:observaciones,:repto_utilizados,:repto_cotizar,:descrip_utilizados,:descrip_cotizar,:tecnico)";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(
        ':inventario' => $inventario, ':tipo_servicio' => $tipo_servicio, ':otro_servicio' => $otro_servicio, ':tipo_asistencia' => $tipo_asistencia, ':f_inicio' => $fecha_inicio, ':h_inicio' => $hora_inicio, ':f_final' => $fecha_final, ':h_final' => $hora_final, ':protocolos' => $protocolos, ':problemas' => $problemas_report, ':otro_problema' => $otro_problema, 
        ':motivo_servicio' => $motivo_servicio,':estado_equipo' => $estado_equipo, ':actividades' => $actividades, ':observaciones' => $observaciones, ':repto_utilizados' => $repto_utilizados, ':descrip_utilizados' => $descrip_utilizados, ':repto_cotizar' => $repto_cotizar, ':descrip_cotizar' => $descrip_cotizar, ':tecnico' => $tecnico));
      echo 'add';
    }
  }
  /* Fin función */

  /* Función para buscar los datos de los reportes en la base de datos */
  function buscar_reportes()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_reporte, inventario, equipo.nombre AS nombre_equipo, equipo.no_activo, equipo.marca, equipo.modelo, equipo.serie, inventario.fijo_movil, 
      pais.nombre_pais, ciudad.nombre_ciudad, sede.nombre_sede, area.nombre_area, inventario.cliente, tipo_servicio.id_tipo_servicio, tipo_servicio.nombre_tipo_servicio AS tipo_servicio, 
      otro_servicio, tipo_asistencia.id_tipo_asistencia, tipo_asistencia.nombre_asistencia, fecha_inicio, hora_inicio, fecha_final, hora_final, protocolo_matto, 
      motivo_servicio, estdo_inicial_equipo, problema_reportado.id_problema_reportado, problema_reportado.nombre_problema_report, otro_problema, actividad_realizada, 
      observa_general, cant_repto_utilizados, cant_repto_cotizar, descrip_repto_utilizados, descrip_repto_cotizar, estatus AS estatus_reporte
      FROM reporte
      INNER JOIN inventario ON reporte.inventario=inventario.id_inventario
      INNER JOIN cliente ON reporte.inventario=cliente.id_cliente
      INNER JOIN tipo_servicio ON reporte.tipo_servicio=tipo_servicio.id_tipo_servicio
      INNER JOIN tipo_asistencia ON reporte.tipo_asistencia=tipo_asistencia.id_tipo_asistencia
      INNER JOIN problema_reportado ON reporte.problemas_report=problema_reportado.id_problema_reportado
      INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
      INNER JOIN pais ON inventario.pais=pais.id_pais
      INNER JOIN ciudad ON inventario.ciudad=ciudad.id_ciudad
      INNER JOIN sede ON inventario.sede=sede.id_sede
      INNER JOIN area ON inventario.area=area.id_area AND id_reporte LIKE :consulta";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_reporte, inventario, equipo.nombre AS nombre_equipo, equipo.no_activo, equipo.marca, equipo.modelo, equipo.serie, inventario.fijo_movil, 
      pais.nombre_pais, ciudad.nombre_ciudad, sede.nombre_sede, area.nombre_area, inventario.cliente, tipo_servicio.id_tipo_servicio, tipo_servicio.nombre_tipo_servicio AS tipo_servicio, 
      otro_servicio, tipo_asistencia.id_tipo_asistencia, tipo_asistencia.nombre_asistencia, fecha_inicio, hora_inicio, fecha_final, hora_final, protocolo_matto, 
      motivo_servicio, estdo_inicial_equipo, problema_reportado.id_problema_reportado, problema_reportado.nombre_problema_report, otro_problema, actividad_realizada, 
      observa_general, cant_repto_utilizados, cant_repto_cotizar, descrip_repto_utilizados, descrip_repto_cotizar, estatus AS estatus_reporte
      FROM reporte
      INNER JOIN inventario ON reporte.inventario=inventario.id_inventario
      INNER JOIN cliente ON reporte.inventario=cliente.id_cliente
      INNER JOIN tipo_servicio ON reporte.tipo_servicio=tipo_servicio.id_tipo_servicio
      INNER JOIN tipo_asistencia ON reporte.tipo_asistencia=tipo_asistencia.id_tipo_asistencia
      INNER JOIN problema_reportado ON reporte.problemas_report=problema_reportado.id_problema_reportado
      INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
      INNER JOIN pais ON inventario.pais=pais.id_pais
      INNER JOIN ciudad ON inventario.ciudad=ciudad.id_ciudad
      INNER JOIN sede ON inventario.sede=sede.id_sede
      INNER JOIN area ON inventario.area=area.id_area AND fecha_inicio NOT LIKE '' ORDER BY id_reporte LIMIT 1000";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  /* Fin función */

  /* Función para finalizar el reporte en la base de datos */
  function estado_finalizado($id_reporte)
  {
    $sql = "UPDATE reporte SET estatus = 'FINALIZADO' WHERE id_reporte=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_reporte));
    if (!empty($query->execute(array(':id' => $id_reporte)))) {
      echo 'finalizado';
    } else {
      echo 'no_finalizado';
    }
  }
  /* Fin función */

  /* Función eliminar los datos del reporte en la base de datos */
  function eliminar($id)
  {
    $sql = "UPDATE reporte SET estatus = 'CANCELADO' WHERE id_reporte=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'cancelado';
    } else {
      echo 'no_cancelado';
    }
  }
  /* Fin función */

  /* Función para capturar los datos de los reportes en la base de datos */
  function capturar_datos()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_reporte, inventario, equipo.nombre AS nombre_equipo, equipo.no_activo, equipo.marca, equipo.modelo, equipo.serie, inventario.fijo_movil, 
      pais.nombre_pais, ciudad.nombre_ciudad, sede.nombre_sede, area.nombre_area, inventario.cliente, tipo_servicio.id_tipo_servicio, tipo_servicio.nombre_tipo_servicio AS tipo_servicio, 
      otro_servicio, tipo_asistencia.id_tipo_asistencia, tipo_asistencia.nombre_asistencia, fecha_inicio, hora_inicio, fecha_final, hora_final, protocolo_matto, 
      motivo_servicio, est_inicial_equipo, problema_reportado.id_problema_reportado, problema_reportado.nombre_problema_report, otro_problema, actividades_realizadas, 
      observaciones, cant_repto_utilizados, cant_repto_cotizar, descrip_repto_utilizados, descrip_repto_cotizar, equipo_operativo, observa_equipo, estatus_reporte
      FROM reporte
      INNER JOIN inventario ON reporte.inventario=inventario.id_inventario
      INNER JOIN tipo_servicio ON reporte.tipo_servicio=tipo_servicio.id_tipo_servicio
      INNER JOIN tipo_asistencia ON reporte.tipo_asistencia=tipo_asistencia.id_tipo_asistencia
      INNER JOIN problema_reportado ON reporte.problemas_report=problema_reportado.id_problema_reportado
      INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
      INNER JOIN pais ON inventario.pais=pais.id_pais
      INNER JOIN ciudad ON inventario.ciudad=ciudad.id_ciudad
      INNER JOIN sede ON inventario.sede=sede.id_sede
      INNER JOIN area ON inventario.area=area.id_area AND id_reporte LIKE :consulta";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_reporte, inventario, equipo.nombre AS nombre_equipo, equipo.no_activo, equipo.marca, equipo.modelo, equipo.serie, inventario.fijo_movil, 
      pais.nombre_pais, ciudad.nombre_ciudad, sede.nombre_sede, area.nombre_area, inventario.cliente, tipo_servicio.id_tipo_servicio, tipo_servicio.nombre_tipo_servicio AS tipo_servicio, 
      otro_servicio, tipo_asistencia.id_tipo_asistencia, tipo_asistencia.nombre_asistencia, fecha_inicio, hora_inicio, fecha_final, hora_final, protocolo_matto, 
      motivo_servicio, est_inicial_equipo, problema_reportado.id_problema_reportado, problema_reportado.nombre_problema_report, otro_problema, actividades_realizadas, 
      observaciones, cant_repto_utilizados, cant_repto_cotizar, descrip_repto_utilizados, descrip_repto_cotizar, equipo_operativo, observa_equipo, estatus_reporte
      FROM reporte
      INNER JOIN inventario ON reporte.inventario=inventario.id_inventario
      INNER JOIN tipo_servicio ON reporte.tipo_servicio=tipo_servicio.id_tipo_servicio
      INNER JOIN tipo_asistencia ON reporte.tipo_asistencia=tipo_asistencia.id_tipo_asistencia
      INNER JOIN problema_reportado ON reporte.problemas_report=problema_reportado.id_problema_reportado
      INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
      INNER JOIN pais ON inventario.pais=pais.id_pais
      INNER JOIN ciudad ON inventario.ciudad=ciudad.id_ciudad
      INNER JOIN sede ON inventario.sede=sede.id_sede
      INNER JOIN area ON inventario.area=area.id_area AND fecha_inicio NOT LIKE '' ORDER BY id_reporte LIMIT 50";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  /* Fin función */
  
  /* Función para contar cuantos reportes de servicio se encuentran registrados en la base de datos */
  function total_reportes()
  {
    $sql = "SELECT COUNT(*) AS total_registro FROM reporte";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */
}
// Fin de la clase.