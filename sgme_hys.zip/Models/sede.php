<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php'; // Ruta para la conexión a la base de datos.

// Clase para realizar la conexión pdo
class Sede{
    var $objetos;
    public function __construct(){
        $db = new Conexion();
        $this->acceso = $db->pdo;
    }

    /* Función para crear los datos de la sede en la base de datos */
    function Crear_Sede($nombre){
        $sql = "SELECT id_sede FROM sede WHERE nombre_sede=:nombre";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':nombre'=>$nombre));
        $this->objetos = $query->fetchall();
        if (!empty($this->objetos)) {
            echo 'noadd';
        }
        else {
            $sql = "INSERT INTO sede(nombre_sede) VALUES (:nombre);";
            $query = $this->acceso->prepare($sql);
            $query->execute(array(':nombre'=>$nombre));
            echo 'add';
        }
    }
    /* Fin función */

  /* Función para editar los datos de la sede en la base de datos */
    function editar_sede($id_sede,$nombre){
        $sql = "UPDATE sede SET nombre_sede=:nombre WHERE id_sede=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id_sede,':nombre'=>$nombre));
        echo 'update';
    }
    /* Fin función */

    /* Función para buscar los datos de las sedes en la base de datos */
    function buscador_sedes(){
        if(!empty($_POST['consulta'])){
            $consulta = $_POST['consulta'];
            $sql = "SELECT * FROM sede WHERE nombre_sede LIKE :consulta";
            $query = $this->acceso->prepare($sql);
            $query->execute(array(':consulta'=>"%$consulta%"));
            $this->objetos = $query->fetchall();
            return $this->objetos;
        }
        else{
            $sql = "SELECT * FROM sede WHERE nombre_sede NOT LIKE '' ORDER BY id_sede LIMIT 25";
            $query = $this->acceso->prepare($sql);
            $query->execute();
            $this->objetos = $query->fetchall();
            return $this->objetos;
        }
    }
    /* Fin función */

    /* Función para inhabilitar los datos de la sede en la base de datos */
    function inhabilitar($id){
        $sql = "UPDATE sede SET estatus_sede = 'INACTIVADO' WHERE id_sede=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id));
        if (!empty($query->execute(array(':id'=>$id)))) {
            echo 'inactivado';
        }
        else {
            echo 'noinactivado';
        }
    }
    /* Fin función */

    /* Función para habilitar los datos de la sede en la base de datos */
    function habilitar($id){
        $sql = "UPDATE sede SET estatus_sede = 'ACTIVO' WHERE id_sede=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id));
        if (!empty($query->execute(array(':id'=>$id)))) {
            echo 'activo';
        }
        else {
            echo 'noactivo';
        }
    }
    /* Fin función */

    /* Función para eliminar los datos de la sede en la base de datos */
    function eliminar($id){
        $sql = "DELETE FROM sede WHERE id_sede=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id));
        if (!empty($query->execute(array(':id'=>$id)))) {
            echo 'delete';
        }
        else {
            echo 'nodelete';
        }
    }
    /* Fin función */

    /* Función para seleccionar los datos de las sedes que se encuentren activo en la base de datos */
    function select_sede(){
        $sql = "SELECT * FROM sede WHERE estatus_sede = 'ACTIVO' ORDER BY estatus_sede";
        $query = $this->acceso->prepare($sql);
        $query->execute();
        $this->objetos = $query->fetchall();
        return $this->objetos;
    }
    /* Fin función */
}

// Fin de la clase.
?>