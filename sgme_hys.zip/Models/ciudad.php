<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php'; // Ruta para la conexión a la base de datos.

// Clase para realizar la conexión pdo
class Ciudad
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  /* Función para crear los datos de la ciudad en la base de datos */
  function Crear_Ciudad($nombre)
  {
    $sql = "SELECT id_ciudad FROM ciudad WHERE nombre_ciudad=:nombre";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':nombre' => $nombre));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO ciudad(nombre_ciudad) VALUES (:nombre);";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':nombre' => $nombre));
      echo 'add';
    }
  }
  /* Fin función */

  /* Función para editar los datos de la ciudad en la base de datos */
  function editar_ciudad($id_ciudad, $nombre)
  {
    $sql = "UPDATE ciudad SET nombre_ciudad=:nombre WHERE id_ciudad=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_ciudad, ':nombre' => $nombre));
    echo 'update';
  }
  /* Fin función */

  /* Función para buscar los datos de la ciudad en la base de datos */
  function buscador_ciudades()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT * FROM ciudad WHERE nombre_ciudad LIKE :consulta";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT * FROM ciudad WHERE nombre_ciudad NOT LIKE '' ORDER BY id_ciudad LIMIT 50";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  /* Fin función */

  /* Función para inhabilitar los datos de la ciudad en la base de datos */
  function inhabilitar($id)
  {
    $sql = "UPDATE ciudad SET estatus_ciudad = 'INACTIVO' WHERE id_ciudad=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'inactivo';
    } else {
      echo 'noinactivo';
    }
  }
  /* Fin función */

  /* Función para habilitar los datos de la ciudad en la base de datos */
  function habilitar($id)
  {
    $sql = "UPDATE ciudad SET estatus_ciudad = 'ACTIVO' WHERE id_ciudad=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'activo';
    } else {
      echo 'noactivo';
    }
  }
  /* Fin función */

  /* Función eliminar los datos de la ciudad en la base de datos */
  function eliminar($id)
  {
    $sql = "DELETE FROM ciudad WHERE id_ciudad=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'delete';
    } else {
      echo 'nodelete';
    }
  }
  /* Fin función */

  /* Función para seleccionar los datos la ciudad que se encuentren activos en la base de datos */
  function select_ciudad()
  {
    $sql = "SELECT * FROM ciudad WHERE estatus_ciudad = 'ACTIVO' ORDER BY estatus_ciudad";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */
}
// Fin de la clase.
