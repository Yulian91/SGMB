<?php
// Ruta para la conexión a la base de datos. //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php'; 

// Clase para realizar la conexión pdo
class Usuario
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  /* Función para crear los datos del usuario en la base de datos */
  function Crear_Usuario($nombre, $apellido, $email, $identificacion, $contacto, $direccion, $contrasena, $tipo)
  {
    $sql = "SELECT id_usuario FROM usuario WHERE identificacion=:identificacion";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':identificacion' => $identificacion));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO usuario(nombre,apellidos,email,identificacion,telefono,direccion,contrasena,tipo_usu) VALUES (:nombre,:apellido,:email,:identificacion,:contacto,:direccion,:contrasena,:tipo);";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':nombre' => $nombre, ':apellido' => $apellido, ':email' => $email, ':identificacion' => $identificacion, ':contacto' => $contacto, ':direccion' => $direccion, ':contrasena' => $contrasena, ':tipo' => $tipo));
      echo 'add';
    }
  }
  /* Fin función */

  /* Función para verificar los datos del usuario en la base de datos */
  function Login($ident)
  {
    $sql = "SELECT u.id_usuario AS id, u.nombre AS nombre, u.apellidos AS apellido, u.email AS correo, u.identificacion AS ident, u.telefono AS telefono,
            u.direccion AS direccion, u.contrasena AS contrasena, u.tipo_usu AS id_tipo, t.nombre_tipo AS tipo_usuario
            FROM usuario u JOIN tipo_usuario t ON u.tipo_usu = t.id_tipo WHERE u.identificacion = :ident";
    $var = array(
      ':ident' => $ident
    );
    $query = $this->acceso->prepare($sql);
    $query->execute($var);
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */

  /* Función para buscar obtener los datos personales del usuario de la base de datos */
  function obtener_datos($id_usuario)
  {
    $sql = "SELECT * FROM usuario INNER JOIN tipo_usuario ON tipo_usu=id_tipo WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_usuario));
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */

  /* Función para editar los datos personales del usuario en la base de datos */
  function editar_datos($id_usuario, $nombre, $apellidos, $identificacion, $email, $contacto, $direccion)
  {
    $sql = "UPDATE usuario SET nombre=:nombre, apellidos=:apellidos, identificacion=:identificacion, email=:email, telefono=:contacto, direccion=:direccion WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_usuario, ':nombre' => $nombre, ':apellidos' => $apellidos, ':identificacion' => $identificacion, ':email' => $email, ':contacto' => $contacto, ':direccion' => $direccion));
    echo 'update_datos';
  }
  /* Fin función */

  /* Función editar los datos del los usuarios en la base de datos */
  function editar_usuario($id_usuario, $nombre, $apellidos, $identificacion, $email, $contacto, $direccion, $contrasena, $tipo)
  {
    $sql = "UPDATE usuario SET nombre=:nombre, apellidos=:apellidos, identificacion=:identificacion, email=:email, telefono=:contacto, direccion=:direccion, contrasena=:contrasena, tipo_usu=:tipo  WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_usuario, ':nombre' => $nombre, ':apellidos' => $apellidos, ':identificacion' => $identificacion, ':email' => $email, ':contacto' => $contacto, ':direccion' => $direccion, ':contrasena' => $contrasena, ':tipo' => $tipo));
    echo 'update_usu';
  }
  /* Fin función */

  /* Función para la contraseña del usuario en la base de datos */
  function cambio_clave($id_usuario, $clave_anterior, $nueva_clave)
  {
    $sql = "SELECT * FROM usuario WHERE id_usuario=:id AND contrasena=:clave_anterior";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_usuario, ':clave_anterior' => $clave_anterior));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      $sql = "UPDATE usuario SET contrasena=:nueva_clave WHERE id_usuario=:id";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':id' => $id_usuario, ':nueva_clave' => $nueva_clave));
      echo 'update';
    } else {
      echo 'noupdate';
    }
  }
  /* Fin función */

  /* Función para buscar los datos del los usuarios en la base de datos */
  function buscador_usuarios()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_usuario, nombre, apellidos, email, identificacion, telefono, direccion, contrasena, tipo_usu, tipo_usuario.nombre_tipo, estatus_usu
      FROM usuario 
      INNER JOIN tipo_usuario ON tipo_usu=id_tipo AND id_usuario LIKE :consulta LIMIT 50";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_usuario, nombre, apellidos, email, identificacion, telefono, direccion, contrasena, tipo_usu, tipo_usuario.nombre_tipo, estatus_usu
      FROM usuario 
      INNER JOIN tipo_usuario ON tipo_usu=id_tipo WHERE nombre NOT LIKE '' ORDER BY id_usuario LIMIT 50";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  /* Fin función */

  /* Función para inhabilitar los datos del usuario en la base de datos */
  function inhabilitar($id)
  {
    $sql = "UPDATE usuario SET estatus_usu = 'INACTIVO' WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'inactivado';
    } else {
      echo 'noinactivado';
    }
  }
  /* Fin función */

  /* Función para habilitar los datos del usuario en la base de datos */
  function habilitar($id)
  {
    $sql = "UPDATE usuario SET estatus_usu = 'ACTIVO' WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'activado';
    } else {
      echo 'noactivado';
    }
  }
  /* Fin función */

  /* Función para eliminar los datos del usuario en la base de datos */
  function eliminar($id)
  {
    $sql = "DELETE FROM usuario WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'delete';
    } else {
      echo 'nodelete';
    }
  }
  /* Fin función */

  /* Función para seleccionar los datos del usuario según el tipo de usuario en la base de datos */
  function select_usuario()
  {
    $sql = "SELECT * FROM usuario INNER JOIN tipo_usuario ON tipo_usu=id_tipo AND id_tipo=4";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */

  /* Función para seleccionar los datos del usuario tecnico según el tipo de usuario en la base de datos */
  function select_tecnico_usu()
  {
    $sql = "SELECT * FROM usuario INNER JOIN tipo_usuario ON tipo_usu=id_tipo AND id_tipo=1 ";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */

  /* Función para contar cuantos usuarios se encuentran registrados en la base de datos */
  function total_usuarios()
  {
    $sql = "SELECT COUNT(*) AS total_registro FROM usuario";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */

  /* Función para verificar los datos del usuario al momento de ingresar al sistema en la base de datos */
  function verificar_datos($identificacion, $email)
  {
    $sql = "SELECT * FROM usuario WHERE email=:email AND identificacion=:identificacion";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':email' => $email, ':identificacion' => $identificacion));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      if ($query->rowCount() == 1) {
        echo 'encontrado';
      } else {
        echo 'no_encontrado';
      }
    } else {
      echo 'no_encontrado';
    }
  }
  /* Fin función */

  /* Función para recuperar la contraseña del usuario en la base de datos */
  function remplazar($identificacion, $email, $codigo)
  {
    $sql = "UPDATE usuario SET password=:codigo WHERE email=:email AND identificacion=:identificacion";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':codigo' => $codigo, ':email' => $email, ':identificacion' => $identificacion));
    echo 'remplazado';
  }
  /* Fin función */
}

// Fin de la clase.
