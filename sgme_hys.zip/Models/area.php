<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php'; // Ruta para la conexión a la base de datos.

// Clase para realizar la conexión pdo
class Area{
    var $objetos;
    public function __construct(){
        $db = new Conexion();
        $this->acceso = $db->pdo;
    }

    /* Función para crear los datos del area en la base de datos */
    function Crear_Area($nombre){
        $sql = "SELECT id_area FROM area WHERE nombre_area=:nombre";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':nombre'=>$nombre));
        $this->objetos = $query->fetchall();
        if (!empty($this->objetos)) {
            echo 'noadd';
        }
        else {
            $sql = "INSERT INTO area(nombre_area) VALUES (:nombre);";
            $query = $this->acceso->prepare($sql);
            $query->execute(array(':nombre'=>$nombre));
            echo 'add';
        }
    }
    /* Fin función */

    /* Función para editar los datos del area en la base de datos */
    function editar_area($id_area,$nombre){
        $sql = "UPDATE area SET nombre_area=:nombre WHERE id_area=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id_area,':nombre'=>$nombre));
        echo 'update';
    }
    /* Fin función */

    /* Función para buscar los datos del area en la base de datos */
    function buscador_areas(){
        if(!empty($_POST['consulta'])){
            $consulta = $_POST['consulta'];
            $sql = "SELECT * FROM area WHERE nombre_area LIKE :consulta";
            $query = $this->acceso->prepare($sql);
            $query->execute(array(':consulta'=>"%$consulta%"));
            $this->objetos = $query->fetchall();
            return $this->objetos;
        }
        else{
            $sql = "SELECT * FROM area WHERE nombre_area NOT LIKE '' ORDER BY id_area LIMIT 50";
            $query = $this->acceso->prepare($sql);
            $query->execute();
            $this->objetos = $query->fetchall();
            return $this->objetos;
        }
    }
    /* Fin función */

    /* Función para inhabilitar los datos del area en la base de datos */
    function inhabilitar($id){
        $sql = "UPDATE area SET estatus_area = 'INACTIVADO' WHERE id_area=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id));
        if (!empty($query->execute(array(':id'=>$id)))) {
            echo 'inactivado';
        }
        else {
            echo 'noinactivado';
        }
    }
    /* Fin función */

    /* Función para habilitar los datos del area en la base de datos */
    function habilitar($id){
        $sql = "UPDATE area SET estatus_area = 'ACTIVO' WHERE id_area=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id));
        if (!empty($query->execute(array(':id'=>$id)))) {
            echo 'activo';
        }
        else {
            echo 'noactivo';
        }
    }
    /* Fin función */

    /* Función eliminar los datos del area en la base de datos */
    function eliminar($id){
        $sql = "DELETE FROM area WHERE id_area=:id";
        $query = $this->acceso->prepare($sql);
        $query->execute(array(':id'=>$id));
        if (!empty($query->execute(array(':id'=>$id)))) {
            echo 'delete';
        }
        else {
            echo 'nodelete';
        }
    }
    /* Fin función */

    /* Función para seleccionar los datos del area que se encuentren activos en la base de datos */
    function select_area(){
        $sql = "SELECT * FROM area WHERE estatus_area = 'ACTIVO' ORDER BY estatus_area";
        $query = $this->acceso->prepare($sql);
        $query->execute();
        $this->objetos = $query->fetchall();
        return $this->objetos;
    }
    /* Fin función */
}

// Fin de la clase.
?>