<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php'; // Ruta para la conexión a la base de datos.

// Clase para realizar la conexión pdo
class Cliente
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  /* Función para crear los datos del cliente en la base de datos */
  function Crear_Cliente($nombre, $nit, $telefono, $tipo_contrato, $num_contrato, $direccion, $contacto, $email)
  {
    $sql = "SELECT id_cliente FROM cliente WHERE nit_cliente=:nit";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':nit' => $nit));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO cliente(nombre_rz,nit_cliente,telefono_cliente,tipo_contrato,num_contrato,direccion_ciudad,nombre_contacto,email_cliente) 
            VALUES (:nombre,:nit,:telefono,:tipo_contrato,:num_contrato,:direccion,:contacto,:email)";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(
        ':nombre' => $nombre, ':nit' => $nit, ':telefono' => $telefono, ':tipo_contrato' => $tipo_contrato, ':num_contrato' => $num_contrato,
        ':direccion' => $direccion, ':contacto' => $contacto, ':email' => $email
      ));
      echo 'add';
    }
  }
  /* Fin función */

  /* Función para editar los datos del cliente en la base de datos */
  function editar_cliente($id_cliente, $nombre, $nit, $telefono, $tipo_contrato, $num_contrato, $direccion, $contacto, $email)
  {
    $sql = "UPDATE cliente SET nombre_rz=:nombre, nit_cliente=:nit, telefono_cliente=:telefono, tipo_contrato=:tipo_contrato, num_contrato=:num_contrato,
        direccion_ciudad=:direccion, nombre_contacto=:contacto, email_cliente=:email WHERE id_cliente=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_cliente, ':nombre' => $nombre, ':nit' => $nit, ':telefono' => $telefono, ':tipo_contrato' => $tipo_contrato, 
    ':num_contrato' => $num_contrato, ':direccion' => $direccion, ':contacto' => $contacto, ':email' => $email));
    echo 'update';
  }
  /* Fin función */

  /* Función para buscar los datos de los clientes en la base de datos */
  function buscador_clientes()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_cliente, fecha_reg, nombre_rz, nit_cliente, telefono_cliente, tipo_contrato, num_contrato, direccion_ciudad, email_cliente, nombre_contacto, estatus_cliente
            FROM cliente WHERE id_cliente LIKE :consulta";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_cliente, fecha_reg, nombre_rz, nit_cliente, telefono_cliente, tipo_contrato, num_contrato, direccion_ciudad, email_cliente, nombre_contacto, estatus_cliente
            FROM cliente WHERE nombre_rz NOT LIKE '' ORDER BY id_cliente LIMIT 50";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  /* Fin función */

  /* Función para inhabilitar los datos del cliente en la base de datos */
  function inhabilitar($id)
  {
    $sql = "UPDATE cliente SET estatus_cliente = 'INACTIVADO' WHERE id_cliente=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'inactivado';
    } else {
      echo 'noinactivado';
    }
  }
  /* Fin función */

  /* Función para habilitar los datos del cliente en la base de datos */
  function habilitar($id)
  {
    $sql = "UPDATE cliente SET estatus_cliente = 'ACTIVO' WHERE id_cliente=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'activo';
    } else {
      echo 'noactivo';
    }
  }
  /* Fin función */

  /* Función eliminar los datos del cliente en la base de datos */
  function eliminar($id)
  {
    $sql = "DELETE FROM cliente WHERE id_cliente=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'delete';
    } else {
      echo 'nodelete';
    }
  }
  /* Fin función */

  /* Función para seleccionar el cliente de la base de datos */
  function select_cliente()
  {
    $sql = "SELECT * FROM cliente WHERE estatus_cliente = 'ACTIVO' ORDER BY estatus_cliente";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */

  /* Función para seleccionar el contacto del cliente de la base de datos */
  function select_cliente_usu()
  {
    $sql = "SELECT id_cliente, contacto_usu, usuario.nombre, usuario.apellidos 
        FROM cliente
        INNER JOIN usuario ON cliente.contacto_usu=usuario.id_usuario";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */

  /* Función para contar cuantos clientes se encuentran registrados en la base de datos */
  function total_clientes()
  {
    $sql = "SELECT COUNT(*) AS total_registro FROM cliente";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  /* Fin función */

}
// Fin de la clase.
