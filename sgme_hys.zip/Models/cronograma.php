<?php
// CLASE PARA REALIZAR LA CONEXION PDO
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php';
class Cronograma
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  /* Función para crear los datos del evento en la base de datos */
  function crear_cronograma($inventario, $titulo, $fecha_inicio, $fecha_final, $descripcion)
  {
    $sql = "SELECT id FROM cronograma WHERE fecha_inicio=:f_final";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':f_final' => $fecha_inicio));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO cronograma(inventario,titulo,fecha_inicio,fecha_final,descripcion) 
            VALUES (:inventario,:titulo,:f_inicio,:f_final,:descripcion)";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':inventario' => $inventario, ':titulo' => $titulo, ':f_inicio' => $fecha_inicio, ':f_final' => $fecha_final, ':descripcion' => $descripcion));
      echo 'add';
    }
  }

  /* Función para editar los datos del evento en la base de datos */
  function editar_cronograma($id_cronograma, $inventario, $titulo, $fecha_inicio, $fecha_final, $descripcion)
  {
    $sql = "UPDATE cronograma SET inventario=:inventario, titulo=:titulo, fecha_inicio=:f_inicio,
        fecha_final=:f_final, descripcion=:descripcion WHERE id=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_cronograma, ':inventario' => $inventario, ':titulo' => $titulo, ':f_inicio' => $fecha_inicio, ':f_final' => $fecha_final, ':descripcion' => $descripcion));
    echo 'edit';
  }

  /* Función para buscar los datos del evento en la base de datos */
  function buscar_eventos()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id, inventario, equipo.nombre, equipo.marca, equipo.modelo, equipo.serie, sede.nombre_sede, area.nombre_area, titulo, fecha_inicio, fecha_final, color, descripcion, estatus, equipo
            FROM cronograma
            INNER JOIN inventario ON cronograma.inventario=inventario.id_inventario
            INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
            INNER JOIN sede ON inventario.sede=sede.id_sede
            INNER JOIN area ON inventario.area=area.id_area  WHERE id LIKE :consulta";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id, inventario, equipo.nombre, equipo.marca, equipo.modelo, equipo.serie, sede.nombre_sede, area.nombre_area, titulo, fecha_inicio, fecha_final, color, descripcion, estatus, equipo
            FROM cronograma
            INNER JOIN inventario ON cronograma.inventario=inventario.id_inventario
            INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
            INNER JOIN sede ON inventario.sede=sede.id_sede
            INNER JOIN area ON inventario.area=area.id_area WHERE inventario NOT LIKE '' ORDER BY id LIMIT 1000";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  // FIN

  /* Función para buscar los datos de los eventos pendientes en la base de datos */
  function buscar_eventos_pendiente()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id, inventario, equipo.nombre, equipo.marca, equipo.modelo, equipo.serie, sede.nombre_sede, area.nombre_area, titulo, fecha_inicio, fecha_final, color, descripcion, estatus, equipo
            FROM cronograma
            INNER JOIN inventario ON cronograma.inventario=inventario.id_inventario
            INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
            INNER JOIN sede ON inventario.sede=sede.id_sede
            INNER JOIN area ON inventario.area=area.id_area WHERE estatus = 'PENDIENTE'";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id, inventario, equipo.nombre, equipo.marca, equipo.modelo, equipo.serie, sede.nombre_sede, area.nombre_area, titulo, fecha_inicio, fecha_final, color, descripcion, estatus, equipo
            FROM cronograma
            INNER JOIN inventario ON cronograma.inventario=inventario.id_inventario
            INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
            INNER JOIN sede ON inventario.sede=sede.id_sede
            INNER JOIN area ON inventario.area=area.id_area WHERE estatus = 'PENDIENTE'";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  // FIN

  /* Función cambiar el estado de pendiente a proceso del evento en la base de datos */
  function estado_proceso($id)
  {
    $sql = "UPDATE cronograma SET estatus = 'PROCESO' WHERE id=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'proceso';
    } else {
      echo 'no_proceso';
    }
  }

  /* Función para reactivar los datos del evento en la base de datos */
  function estado_reactivar($id)
  {
    $sql = "UPDATE cronograma SET estatus = 'PENDIENTE' WHERE id=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'reactivar';
    } else {
      echo 'no_reactivar';
    }
  }

  /* Función para cancelar los datos del evento en la base de datos */
  function estado_cancelar($id)
  {
    $sql = "UPDATE cronograma SET estatus = 'CANCELADO' WHERE id=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'cancelado';
    } else {
      echo 'no_cancelado';
    }
  }

  /* Función para cerrar el evento en la base de datos */
  function estado_cerrado($id)
  {
    $sql = "UPDATE cronograma SET estatus = 'FINALIZADO' WHERE id=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'cerrado';
    } else {
      echo 'no_cerrado';
    }
  }

  /* Función para buscar los datos del evento en la base de datos */
  function eventos()
  {
    $sql = "SELECT id, titulo AS title, fecha_inicio AS start, fecha_final AS end, color FROM cronograma";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }

  /* Función eliminar los datos del evento en la base de datos */
  function eliminar($id)
  {
    $sql = "DELETE FROM cronograma WHERE id=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'delete';
    } else {
      echo 'nodelete';
    }
  }
  /* Fin función */
}
// Fin de la clase.
