<?php
// CLASE PARA REALIZAR LA CONEXION PDO
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Config/conexion.php';
class Det_Reporte
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  /* Función para enviar los datos de la firma del reporte a la base de datos */
  function firma_reporte($id_reporte, $nombre_cliente, $ident_cliente, $name_firma_cli, $equipo_oprtvo, $name_img_evidencia1, $name_img_evidencia2, $name_img_evidencia3)
  {
    $sql = "SELECT firma_cli FROM detalle_reporte WHERE id_detalle=:id_reporte";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id_reporte' => $id_reporte));
    $this->objetos = $query->fetchall();

    $sql = "INSERT INTO detalle_reporte(reporte, nombre_cli, identificacion_cli, firma_cli, equipo_oprtvo, evidencia_matto1, evidencia_matto2, evidencia_matto3) VALUES (:id_reporte, :nombre_cliente, :ident_cliente, :firma_cliente, :equipo_oprtvo, :evidencia_matto1, :evidencia_matto2, :evidencia_matto3)";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id_reporte' => $id_reporte, ':nombre_cliente' => $nombre_cliente, ':ident_cliente' => $ident_cliente, ':firma_cliente' => $name_firma_cli, ':equipo_oprtvo' => $equipo_oprtvo, ':evidencia_matto1' => $name_img_evidencia1, ':evidencia_matto2' => $name_img_evidencia2, ':evidencia_matto3' => $name_img_evidencia3));
    return $this->objetos;
  }
  /* Fin función */

}
// Fin de la clase.
