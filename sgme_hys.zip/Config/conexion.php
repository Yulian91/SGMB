<?php
// Clase para la conexión con la base de datos

class Conexion {
    private $servidor = "127.0.0.1:3306"; // 127.0.0.1:3306
    private $database = "u538024323_sgme_hys"; // u538024323_sgme_hys
    private $puerto = 3306; //3306
    private $charset = "utf8"; // UTF-8
    private $usuario = "u538024323_henry_m";  // u538024323_henry_m
    private $contrasena = "Henry87712709"; // Henry87712709
    private $atributos = [PDO::ATTR_CASE=>PDO::CASE_LOWER,PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_ORACLE_NULLS=>PDO::NULL_EMPTY_STRING,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_OBJ];
    public $pdo = null;
    function __construct(){
        $this->pdo=new PDO("mysql:dbname={$this->database};host={$this->servidor};puerto={$this->puerto};
        charset={$this->charset}",$this->usuario,$this->contrasena,$this->atributos);
    }

}

// Fin de la clase.
