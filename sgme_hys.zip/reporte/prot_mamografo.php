<?php
session_start();
if ($_SESSION['tipo_usu'] == 1 || $_SESSION['tipo_usu'] == 2) {
  include_once '../Views/layouts/header.php';
?>

  <title>SGME H&S - Protocolo Mamografo</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../Assets/css/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../Assets/css/adminlte.min.css">

  <?php
  if ($_REQUEST) {
    $equipo = $_REQUEST['id'];
  } else {
    echo '<-- NO HAY DATOS, NO ES POSIBLE CREAR EL REPORTE -->';
  }
  ?>

  <div class="container">
    <div class="wrapper">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <img src="../Assets/img/logo_H&S.jpg" width="200" height="50">
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <h2>Protocolo Mamografo</h2>
          </li>
        </ul>
      </nav>
      <br>
      <form id="form-crear-reporte">
        <div class="card card-info">
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <strong><?php echo $equipo ?> - </strong>
              </div>
            </div>
          </div>
        </div>
        <div class="card border-warning">
          <div class="card-body">
            <div class="col-md-12">
              <div class="panel-heading">
                <h5 class="panel-title text-center"><strong>INSPECCIÓN VISUAL</strong></h5>
              </div>
              <table class="table">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Items a Evaluar</th>
                    <th>B</th>
                    <th>M</th>
                    <th>N/A</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td>Verificar el estado del panel de control, ruedas, tapas, carcasas, tornillería y pintura en general.</td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_1" value="1">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_2" value="2">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_3" value="3">
                    </td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td>Verificar las etiquetas y marcas del equipo</td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_4" value="4">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_5" value="5">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_6" value="6">
                    </td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>Verificar el estado de aislamiento de los cables de poder, clavija y cable de interfaz</td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_7" value="7">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_8" value="8">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_9" value="9">
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="card border-warning">
          <div class="card-body">
            <div class="col-md-12">
              <div class="panel-heading">
                <h5 class="panel-title text-center"><strong>INSPECCIÓN MECANICA</strong></h5>
              </div>
              <table class="table">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Items a Evaluar</th>
                    <th>B</th>
                    <th>M</th>
                    <th>N/A</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>4</td>
                    <td>Verificar y ajustar los frenos de rodamientos, soporte de tubo, tensor de contrapeso y soporte del colimador</td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_10" value="10">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_11" value="11">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_12" value="12">
                    </td>
                  </tr>
                  <tr>
                    <td>5</td>
                    <td>Rociar las guías y los rodamientos del soporte del tubo con un lubricante ligero para aerosoles</td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_13" value="13">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_14" value="14">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_15" value="15">
                    </td>
                  </tr>
                  <tr>
                    <td>6</td>
                    <td>Realizar la limpieza de los rodamientos, dejando una película muy pequeña en las guías.</td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_16" value="16">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_17" value="17">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_18" value="18">
                    </td>
                  </tr>
                  <tr>
                    <td>7</td>
                    <td>Verificar y ajustar las manijas de bloqueo y asegurarse que no estén sueltas y que cierren de forma manual.</td>
                    <td>
                      <input type="checkbox" name="check_item_4" id="check_19" value="19">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_4" id="check_20" value="20">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_4" id="check_21" value="21">
                    </td>
                  </tr>
                  <tr>
                    <td>8</td>
                    <td>Verificar las posiciones del pedal</td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_22" value="22">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_23" value="23">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_24" value="24">
                    </td>
                  </tr>
                  <tr>
                    <td>9</td>
                    <td>Verificar funcionamiento de ruedas traseras y delanteras.</td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_25" value="25">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_26" value="26">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_27" value="27">
                    </td>
                  </tr>
                  <tr>
                    <td>10</td>
                    <td>Verificar el campo de luz con el campo de radiación</td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_28" value="28">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_29" value="29">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_30" value="30">
                    </td>
                  </tr>
                  <tr>
                    <td>11</td>
                    <td>Comprobar que el localizador del haz de luz del colimador está operado tanto con el panel de control como en el colimador.</td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_31" value="31">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_32" value="32">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_33" value="33">
                    </td>
                  </tr>
                  <tr>
                    <td>12</td>
                    <td>Compruebe si el diafragma de doble ranura se puede girar ± 45 °.</td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_34" value="34">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_35" value="35">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_36" value="36">
                    </td>
                  </tr>
                  <tr>
                    <td>13</td>
                    <td>Verificar que el ajuste de formato (cuchillas) sea fácil y suave girando el colimador con perillas de ajuste.</td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_37" value="37">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_38" value="38">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_39" value="39">
                    </td>
                  </tr>
                  <tr>
                    <td>14</td>
                    <td>Comprobación de los elementos de control en el colimador.</td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_40" value="40">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_41" value="41">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_5" id="check_42" value="42">
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="card border-warning">
          <div class="card-body">
            <div class="col-md-12">
              <div class="panel-heading">
                <h5 class="panel-title text-center"><strong>INSPECCIÓN ELÉCTRICA</strong></h5>
              </div>
              <table class="table">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Items a Evaluar</th>
                    <th>B</th>
                    <th>M</th>
                    <th>N/A</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>15</td>
                    <td>Examinar cuidadosamente el cable de poder, la clavija, los conectores de las tarjetas electrónicas, fuentes de poder, pulsadores de la tarjeta de control y del hand swich.</td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_43" value="43">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_44" value="44">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_45" value="45">
                    </td>
                  </tr>
                  <tr>
                    <td>16</td>
                    <td>Verificar la línea de voltaje de alimentación</td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_46" value="46">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_47" value="47">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_48" value="48">
                    </td>
                  </tr>
                  <tr>
                    <td>17</td>
                    <td>Verificar que la lámpara de localización del haz de luz se encienda y temporice su apagado según requerimiento del tecnólogo en imágenes diagnósticas.</td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_49" value="49">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_50" value="50">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_51" value="51">
                    </td>
                  </tr>
                  <tr>
                    <td>18</td>
                    <td>Realizar la limpieza de los portafusibles con un aerosol para limpieza de dispositivos electrónicos.</td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_52" value="52">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_53" value="53">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_54" value="54">
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="card border-warning">
          <div class="card-body">
            <div class="col-md-12">
              <div class="panel-heading">
                <h5 class="panel-title text-center"><strong>MEDICION DE PARAMETROS</strong></h5>
              </div>
              <table class="table">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Items a Evaluar</th>
                    <th>B</th>
                    <th>M</th>
                    <th>N/A</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>19</td>
                    <td>Medición de kv</td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_55" value="55">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_56" value="56">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_1" id="check_57" value="57">
                    </td>
                  </tr>
                  <tr>
                    <td>20</td>
                    <td>Medición de mA</td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_58" value="58">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_59" value="59">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_2" id="check_60" value="60">
                    </td>
                  </tr>
                  <tr>
                    <td>21</td>
                    <td>Medición de mAs</td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_61" value="61">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_62" value="62">
                    </td>
                    <td>
                      <input type="checkbox" name="check_item_3" id="check_63" value="63">
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button>
          <button type="button" id="btn_limpiar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button>
        </div>
      </form>
    </div>
  </div>

  <!-- jQuery -->
  <script src="../Assets/js/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="../Assets/js/jquery-ui.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="../Assets/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../Assets/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../Assets/js/demo.js"></script>
  <!-- Firma Digital SignaturePad -->
  <script src="https://cdn.jsdelivr.net/npm/signature_pad@4.0.0/dist/signature_pad.umd.min.js"></script>

<?php

} else {
  header('Location: ../index.php');
}
?>