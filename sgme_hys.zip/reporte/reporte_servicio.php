<?php
session_start(); // Codigo para activar la sesión en curso //

/* Conexión con la base de datos */
$conexion = mysqli_connect("127.0.0.1:3306", "u538024323_henry_m", "Henry87712709", "u538024323_sgme_hys");
require_once 'plantilla_reporte.php';

/* Condicional para saber si la url viene vacia o con algún dato */
if (empty($_REQUEST['id'])) {
    echo "NO ES POSIBLE GENERAR EL REPORTE.";
} else {
    $no_reporte = $_REQUEST['id'];
    //$firma = $_REQUEST['firma'];

    $query = mysqli_query($conexion, "SELECT id_detalle, reporte.id_reporte AS id_reporte, equipo.nombre AS nombre_equipo, equipo.no_activo, equipo.marca, equipo.modelo, equipo.serie, sede.nombre_sede, area.nombre_area, cliente.nombre_rz, cliente.nit_cliente, 
    cliente.telefono_cliente, cliente.direccion_ciudad AS direccion_cliente, cliente.tipo_contrato, cliente.num_contrato, inventario.fijo_movil, reporte.tipo_servicio AS id_tipo_servicio, tipo_servicio.nombre_tipo_servicio AS tipo_servicio, reporte.otro_servicio, 
    tipo_asistencia.nombre_asistencia, DATE_FORMAT(reporte.fecha_inicio, '%d-%m-%Y') AS fecha_inicio, reporte.hora_inicio, DATE_FORMAT(reporte.fecha_final, '%d-%m-%Y') AS fecha_final, reporte.hora_final, reporte.protocolo_matto, reporte.motivo_servicio, 
    reporte.estdo_inicial_equipo, reporte.problemas_report AS id_problema_reportado, problema_reportado.nombre_problema_report, reporte.otro_problema, reporte.actividad_realizada, reporte.observa_general, reporte.cant_repto_utilizados, reporte.cant_repto_cotizar, 
    reporte.descrip_repto_utilizados, reporte.descrip_repto_cotizar, reporte.estatus AS estado_reporte, tecnico_usuario AS id_usuario, usuario.nombre AS nombre_tecnico, usuario.apellidos AS apellido_tecnico, 
    usuario.identificacion AS ident_tecnico, nombre_cli, identificacion_cli, firma_cli, equipo_oprtvo, evidencia_matto1, evidencia_matto2, evidencia_matto3, reporte.tecnico_usuario
    FROM detalle_reporte
    INNER JOIN reporte ON detalle_reporte.reporte=reporte.id_reporte
    INNER JOIN usuario ON reporte.tecnico_usuario=usuario.id_usuario
    INNER JOIN inventario ON reporte.inventario=inventario.id_inventario
    INNER JOIN tipo_servicio ON reporte.tipo_servicio=tipo_servicio.id_tipo_servicio
    INNER JOIN tipo_asistencia ON reporte.tipo_asistencia=tipo_asistencia.id_tipo_asistencia
    INNER JOIN problema_reportado ON reporte.problemas_report=problema_reportado.id_problema_reportado
    INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
    INNER JOIN cliente ON inventario.cliente=cliente.id_cliente
    INNER JOIN sede ON inventario.sede=sede.id_sede
    INNER JOIN area ON inventario.area=area.id_area WHERE id_reporte = $no_reporte");

    /* Si la url viene con algún dato que se mayor a 0 se genera el PDF*/
    $result = mysqli_num_rows($query);
    if ($result > 0) {
        $reporte = mysqli_fetch_assoc($query);
        $no_reporte = $reporte['id_reporte'];
    }

    $query_productos = mysqli_query($conexion, "SELECT id_detalle, reporte.id_reporte AS id_reporte, equipo.nombre AS nombre_equipo, equipo.no_activo, equipo.marca, equipo.modelo, equipo.serie, sede.nombre_sede, area.nombre_area, cliente.nombre_rz, cliente.nit_cliente, 
    cliente.telefono_cliente, cliente.direccion_ciudad AS direccion_cliente, cliente.tipo_contrato, cliente.num_contrato, inventario.fijo_movil, reporte.tipo_servicio AS id_tipo_servicio, tipo_servicio.nombre_tipo_servicio AS tipo_servicio, reporte.otro_servicio, 
    tipo_asistencia.nombre_asistencia, DATE_FORMAT(reporte.fecha_inicio, '%d-%m-%Y') AS fecha_inicio, reporte.hora_inicio, DATE_FORMAT(reporte.fecha_final, '%d-%m-%Y') AS fecha_final, reporte.hora_final, reporte.protocolo_matto, reporte.motivo_servicio, 
    reporte.estdo_inicial_equipo, reporte.problemas_report AS id_problema_reportado, problema_reportado.nombre_problema_report, reporte.otro_problema, reporte.actividad_realizada, reporte.observa_general, reporte.cant_repto_utilizados, reporte.cant_repto_cotizar, 
    reporte.descrip_repto_utilizados, reporte.descrip_repto_cotizar, reporte.estatus AS estado_reporte, tecnico_usuario AS id_usuario, usuario.nombre AS nombre_tecnico, usuario.apellidos AS apellido_tecnico, 
    usuario.identificacion AS ident_tecnico, nombre_cli, identificacion_cli, firma_cli, equipo_oprtvo, evidencia_matto1, evidencia_matto2, evidencia_matto3, reporte.tecnico_usuario
    FROM detalle_reporte
    INNER JOIN reporte ON detalle_reporte.reporte=reporte.id_reporte
    INNER JOIN usuario ON reporte.tecnico_usuario=usuario.id_usuario
    INNER JOIN inventario ON reporte.inventario=inventario.id_inventario
    INNER JOIN tipo_servicio ON reporte.tipo_servicio=tipo_servicio.id_tipo_servicio
    INNER JOIN tipo_asistencia ON reporte.tipo_asistencia=tipo_asistencia.id_tipo_asistencia
    INNER JOIN problema_reportado ON reporte.problemas_report=problema_reportado.id_problema_reportado
    INNER JOIN equipo ON inventario.equipo=equipo.id_equipo
    INNER JOIN cliente ON inventario.cliente=cliente.id_cliente
    INNER JOIN sede ON inventario.sede=sede.id_sede
    INNER JOIN area ON inventario.area=area.id_area WHERE id_reporte = $no_reporte");

    $result_detalle = mysqli_num_rows($query_productos);

    $pdf = new PDF('P', 'mm', 'letter', true);
    $pdf->AliasNbPages();
    $pdf->SetMargins(10, 10, 10);
    $pdf->AddPage();
    $pdf->SetFont('Arial', '', 12);

    // Creación del objeto de la clase heredada

    // REPORTE DE SERVICIO

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(40, 10, ('Nro.   ') . $reporte['id_reporte'], 'B', 0, 'L');

    $pdf->Cell(80);
    $pdf->Cell(75, 10, ('Tipo de Asistencia:    ') . $reporte['nombre_asistencia'], 'B', 1);

    // Salto de linea
    $pdf->Ln(6);

    // INFORMACIÓN DETALLADA DEL CLIENTE

    $pdf->SetFont("Arial", "B", 12);
    $pdf->SetFillColor(225, 225, 225);
    $pdf->Cell(195, 8, 'Detalle del Cliente', 1, 1, 'L', 1);
    // Salto de linea
    $pdf->Ln(5);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Cliente:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['nombre_rz']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, ('Nit:'));

    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['nit_cliente']);
    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Telefono:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['telefono_cliente']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'Dirección:');

    $pdf->SetFont("Arial", "", 10);
    $pdf->MultiCell(0, 5, $reporte['direccion_cliente']);
    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Tipo de Contrato:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['tipo_contrato']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'No. Contrato:');

    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['num_contrato']);
    // Salto de linea
    $pdf->Ln(10);

    // INFORMACIÓN DETALLADA DEL EQUIPO

    $pdf->SetFont("Arial", "B", 12);
    $pdf->SetFillColor(225, 225, 225);
    $pdf->Cell(195, 8, 'Detalle del Equipo', 1, 1, 'L', 1);
    // Salto de linea
    $pdf->Ln(5);

    $pdf->Cell(20, 5, 'Equipo:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['nombre_equipo']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, ('No. Activo'));

    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['no_activo']);
    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Marca:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['marca']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'Modelo:');

    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['modelo']);
    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'No. Serie:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['serie']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'Fijo / Movil:');

    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['fijo_movil']);
    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Sede:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['nombre_sede']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'Area:');

    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['nombre_area']);
    // Salto de linea
    $pdf->Ln(8);

    // INFORMACION DETALLADA DEL SERVICIO

    $pdf->SetFont("Arial", "B", 12);
    $pdf->SetFillColor(225, 225, 225);
    $pdf->Cell(195, 8, 'Detalle del Servicio', 1, 1, 'L', 1);
    // Salto de linea
    $pdf->Ln(5);

    $pdf->Cell(20, 5, 'Tipo de Servicio:');

    $pdf->Cell(40);
    $pdf->SetFont("Arial", "", 10);

    // Si el usuario elige la opción 7 la cual es otro servicio, se vera reflejado en el PDF del reporte.
    if ($reporte['id_tipo_servicio'] == '7') {
        $pdf->Cell(20, 5, $reporte['otro_servicio']);
    } else {
        $pdf->Cell(20, 5, $reporte['tipo_servicio']);
    }

    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Problemas Reportados:');

    $pdf->Cell(40);
    $pdf->SetFont("Arial", "", 10);

    // Si el usuario elige la opción 10 la cual es otro problema reportado, se vera reflejado en el PDF del reporte.
    if ($reporte['id_problema_reportado'] == '10') {
        $pdf->Cell(20, 5, $reporte['otro_problema']);
    } else {
        $pdf->Cell(20, 5, $reporte['nombre_problema_report']);
    }

    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Motivo de Servicio:');

    $pdf->Cell(40);
    $pdf->SetFont("Arial", "", 10);
    $pdf->MultiCell(0, 5, $reporte['motivo_servicio']);

    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Estado Inicial del Equipo:');

    $pdf->Cell(40);
    $pdf->SetFont("Arial", "", 10);
    $pdf->MultiCell(0, 5, $reporte['estdo_inicial_equipo']);
    
    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Actividades Realizadas:');

    $pdf->Cell(40);
    $pdf->SetFont("Arial", "", 10);
    $pdf->MultiCell(0, 5, $reporte['actividad_realizada']);

    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Observaciones:');

    $pdf->Cell(40);
    $pdf->SetFont("Arial", "", 10);
    $pdf->MultiCell(0, 5, $reporte['observa_general']);

    // Salto de linea
    $pdf->Ln(6);

    // INFORMACIÓN DETALLADA DE FECHAS Y HORAS DEL SERVICIO

    $pdf->SetFont("Arial", "B", 12);
    $pdf->SetFillColor(225, 225, 225);
    $pdf->Cell(195, 8, 'Fecha del Evento', 1, 1, 'L', 1);
    $pdf->Ln(5);

    $pdf->Cell(20, 5, 'Inicio:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5,$reporte['fecha_inicio']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, ('Hora:'));

    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['hora_inicio']);

    // Salto de linea
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Finalización:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['fecha_final']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'Hora:');

    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['hora_final']);

    // Salto de linea
    $pdf->Ln(8);

    // INFORMACION DETALLADA DE REPUESTOS Y ACCESORIOS UTILIZADOS

    $pdf->SetFont("Arial", "B", 12);
    $pdf->SetFillColor(225, 225, 225);
    $pdf->Cell(195, 8, 'Repuestos y/o Accesorios Utilizados', 1, 1, 'L', 1);
    // Salto de linea
    $pdf->Ln(5);

    $pdf->Cell(20, 5, 'Cantidad:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5,$reporte['cant_repto_utilizados']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'Descripción:');

    $pdf->SetFont("Arial", "", 10);
    $pdf->MultiCell(0, 5, $reporte['descrip_repto_utilizados']);

    // Salto de linea
    $pdf->Ln(8);

    // INFORMACION DETALLADA DE REPUESTOS Y ACCESORIOS A COTIZAR

    $pdf->SetFont("Arial", "B", 12);
    $pdf->SetFillColor(225, 225, 225);
    $pdf->Cell(195, 8, 'Repuestos y/o Accesorios a Cotizar', 1, 1, 'L', 1);
    
    // Salto de linea
    $pdf->Ln(5);

    $pdf->Cell(20, 5, 'Cantidad:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5,$reporte['cant_repto_cotizar']);

    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'Descripción:');

    $pdf->SetFont("Arial", "", 10);
    $pdf->MultiCell(0, 5, $reporte['descrip_repto_cotizar']);

    // Salto de linea
    $pdf->Ln(8);

    // INFORMACION DETALLADA SI EL EQUIPO QUEDO OPERATIVO

    $pdf->SetFont("Arial", "B", 12);
    $pdf->SetFillColor(225, 225, 225);
    $pdf->Cell(195, 8, '¿ El equipo queda operativo ?', 1, 1, 'L', 1);

    // Salto de linea
    $pdf->Ln(5);

    $pdf->Cell(20, 5, 'Si / No:');

    $pdf->Cell(20);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['equipo_oprtvo']);

    // INFORMACION DETALLADA DEL TECNICO Y CLIENTE QUIEN RECIBE EL REPORTE

    // Titulo de las evidencias fotograficas del mantenimiento
    $pdf->Cell(55);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'Evidencias:');

    // Salto de linea
    $pdf->Ln(15);

    // Variables de las evidencias fotograficas
    $img_evidencia1 =  '/sgme_hys/Assets/img/evidencias/' . $reporte['evidencia_matto1'];
    $img_evidencia2 =  '/sgme_hys/Assets/img/evidencias/' . $reporte['evidencia_matto2'];
    $img_evidencia3 =  '/sgme_hys/Assets/img/evidencias/' . $reporte['evidencia_matto3'];
    $img_evidencia_no =  '/sgme_hys/Assets/img/evidencias/NA.png';

    // Condicional para las evidencias fotograficas
    $pdf->SetFont("Arial", "", 10);
    if ($reporte['evidencia_matto1'] == $img_evidencia_no || $reporte['evidencia_matto2'] == $img_evidencia_no || $reporte['evidencia_matto3'] == $img_evidencia_no) {
        $pdf->Cell(35, 8, $pdf->Image($img_evidencia_no, $pdf->GetX(), $pdf->GetY(),60));
    } else {
        $pdf->Cell(10);
        $pdf->Cell(35, 20, $pdf->Image($img_evidencia1, $pdf->GetX(), $pdf->GetY(),55, 50));
        $pdf->Cell(25);
        $pdf->Cell(35, 20, $pdf->Image($img_evidencia2, $pdf->GetX(), $pdf->GetY(),55, 50));
        $pdf->Cell(25);
        $pdf->Cell(35, 20, $pdf->Image($img_evidencia3, $pdf->GetX(), $pdf->GetY(),55, 50));
    }

    // Salto de linea
    $pdf->Ln(60);

    // INFORMACION DETALLADA DEL TECNICO QUIEN FIRMA EL REPORTE

    // Titulos de los cuadrados
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(95, 10, 'Firma del Técnico', 1, 0, 'C');
    $pdf->Cell(100, 10, 'Firma quien Recibe', 1, 1, 'C');

    // Estructura de los cuadrados
    $pdf->Cell(95, 80, '', 1, 0);
    $pdf->Cell(100, 80, '', 1, 0);

    // Salto de linea
    $pdf->Ln(8);

    // Variables de las firmas
    $firma_henry= "/sgme_hys/Assets/img/firmas/firma_henry.png";
    $firma_cliente =  '/sgme_hys/Assets/img/firmas/' . $reporte['firma_cli'];

    // Firma del técnico que se trae de la base de datos
    $pdf->SetFont("Arial", "", 10);
    if ($reporte['tecnico_usuario'] == '1') {
        $pdf->Cell(20, 8, $pdf->Image($firma_henry, $pdf->GetX(), $pdf->GetY(),60));
    }
    
    // Firma del cliente que se trae de la base de datos
    $pdf->Cell(95);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(35, 8, $pdf->Image($firma_cliente, $pdf->GetX(), $pdf->GetY(),60));

    // Titulo del nombre del tecnico
    $pdf->Ln(15);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5,'Nombre del Técnico:');

    // Titulo del nombre del cliente
    $pdf->Cell(95);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(35, 5, 'Nombre quien Recibe:');

    // Salto de linea
    $pdf->Ln(7);

    // Nombre y apellido del técnico que se trae de la base de datos
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 6, $reporte['nombre_tecnico'].$reporte['apellido_tecnico']);
    
    // Nombre y apellido del cliente que se trae de la base de datos
    $pdf->Cell(95);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(35, 6, $reporte['nombre_cli']);

    // Salto de linea
    $pdf->Ln(7);
    
    // Titulo de la identificacion del técnico.
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Identificación:');

    // Titulo de la identificacion del cliente.
    $pdf->Cell(95);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(20, 5, 'Identificación:');

    // Salto de linea
    $pdf->Ln(7);

    // Iidentificacion del técnico que se trae de la base de datos
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['ident_tecnico']);

    // Iidentificacion del cliente que se trae de la base de datos
    $pdf->Cell(95);
    $pdf->SetFont("Arial", "", 10);
    $pdf->Cell(20, 5, $reporte['identificacion_cli']);

    // Generar el reporte de servicio en PDF
    $pdf->Output('Reporte de Servicio.pdf','I');
}
