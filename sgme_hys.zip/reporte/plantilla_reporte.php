<?php

include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/pdf/fpdf.php'; // Ruta de conexión con la libreria FPDF.

class PDF extends FPDF
{
  // Cabecera de página
  function Header()
  {

    //$this->Line(10, 29, 205, 29);

    // Logo
    $this->Image('../Assets/Util/img/Logo_2.png', 30, 10, 20);
    $this->Cell(65, 20, '', 1, 0);

    // Título
    //$this->Cell(1);
    //$this->Cell(5);
    $this->SetFont('Arial', 'B', 15);
    $this->Cell(67, 20, ('REPORTE DE SERVICIO'), 1, 0, 'C');

    // Fecha
    //$this->Cell(10);
    $this->SetFont("Arial", "B", 11);
    $this->Cell(0, 20, ('Fecha Emisión: 07/02/2022'), 1, 0, 'C');
    $this->Ln(2);
    //$this->Cell(10, 20, 'Versión: 3.1', 'LRBT', 1, 'C');
    //$this->Ln(0);

    // Versión reporte
    $this->Cell(138);
    $this->Cell(15, 30, ('Versión: 3.1'), 0, 0, 'L');
    $this->Ln(10);

    // Reporte Digital
    $this->Cell(86);
    $this->SetFont('Arial', '', 9);
    $this->Cell(25, 10, ('Reporte Digital'), 0, 'C');

    // Salto de línea
    $this->Ln(12);
  }

  // Pie de página
  function Footer()
  {
    // Posición: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial', 'I', 8);
    // 
    $this->Cell(0, 10, 'CARRERA 28 # 41-24 SUR CEL. 3103816871', 0, 0, 'C');
    $this->Ln(4);
    $this->Cell(0, 10, 'https://hysequipos.com/', 0, 0, 'C');
    $this->Ln(4);
    $this->Cell(0, 10, 'Bogotá, D.C - Colombia', 0, 0, 'C');
    // Número de página
    $this->Cell(0, 10, 'Pagina ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
  }
}
