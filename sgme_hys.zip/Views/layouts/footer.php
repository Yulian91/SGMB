<!-- CONTENIDO DEL PIE DE PAGINA -->
<footer class="main-footer text-sm">
  <div class="float-right d-none d-sm-block">
    <b>Version</b> 2.0
  </div>
  <strong>&copy; 2023 - 2024 <a href="http://hmtecbiomedica.com/">SGME H&S</a> | </strong> Todos los derechos reservados.
</footer>
<!--/.FIN DEL CONTENIDO PIE DE PAGINA -->

</div>

<!-- Estas son las rutas de los archivos JaveScript -->
<!-- jQuery -->
<script src="/sgme_hys/Assets/Util/js/jquery.min.js"></script>
<!-- Bootstrap 4.6 -->
<script src="/sgme_hys/Assets/Util/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/sgme_hys/Assets/Util/js/adminlte.min.js"></script>
<!-- DataTables -->
<script src="/sgme_hys/Assets/Util/js/datatables.min.js"></script>
<!-- sweetalert2 -->
<script src="/sgme_hys/Assets/Util/js/sweetalert2.min.js"></script>
<!-- select2 -->
<script src="/sgme_hys/Assets/Util/js/select2.min.js"></script>
<!-- Full Calendar  -->
<script src="/sgme_hys/Assets/Util/js/moment.min.js"></script>
<script src="/sgme_hys/Assets/Util/js/main.js"></script>
<script src="/sgme_hys/Assets/Util/js/es.js"></script>

</body>
<!--/.CONTENIDO DEL MENU PRINCIPAL LATERAL Y BARRA DE NAVEGACIÓN SUPERIOR -->

</html>
<!--/.FIN CONTENIDO DE LA PAGINA HTML -->