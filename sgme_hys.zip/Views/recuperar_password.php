<!-- CONTENIDO DE LA PAGINA HTML -->
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Recuperar Contraseña</title>

  <!-- Font Awesome -->
  <link rel="stylesheet" href="/sgme_hys/Assets/Util/css/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="/sgme_hys/Assets/Util/css/adminlte.min.css">
  <!-- sweetalert2 -->
  <link rel="stylesheet" href="/sgme_hys/Assets/Util/css/sweetalert2.css">

</head>

<body class="hold-transition login-page">
  <div class="login-box">
    <div class="login-logo">
      <!-- <img src="../Assets/img/tools.png" alt=""> -->
      <a href="../index.php"><b>SGME H&S</b></a>
    </div>
    <!-- /.login-logo -->
    <div class="card">
      <div class="card-body login-card-body">
        <p class="login-box-msg">¿Olvidaste tu contraseña? Aquí puede recuperar fácilmente una nueva contraseña.</p>
        <span id="aviso1" class="text-success text-bold">Texto</span>
        <span id="aviso" class="text-danger text-bold">Texto</span>
        <!-- Formulario para ingresar los datos -->
        <form id="form-recuperar-pass"><!-- id = Es el identificador del formulario de login -->
          <div class="input-group mb-3">
            <input type="text" class="form-control" id="id_recuperar" placeholder="Identificación" ><!-- Este input envia el numero de identificación del usuario al archivo recuperar_password.js -->
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-address-card"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="text" class="form-control" id="email_recuperar" placeholder="Email"><!-- Este input envia el correo del usuario al archivo recuperar_password.js -->
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-envelope"></span>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12">
              <button type="submit" class="btn btn-primary btn-block">Enviar</button><!-- Este es el boton para enviar los datos -->
            </div>
            <!-- /.col -->
          </div>
        </form>

        <p class="login-box-msg mt-3">Se enviara un codigo al correo electrónico registrado.</p>
        <p class="mt-3 mb-1">
          <a href="../index.php">Inicio - SGME H&S</a>
        </p>
      </div>
      <!-- /.login-card-body -->
    </div>
  </div>
  <!-- /.login-box -->

  <!-- jQuery -->
  <script src="/sgme_hys/Assets/Util/js/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="/sgme_hys/Assets/Util/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="/sgme_hys/Assets/Util/js/adminlte.min.js"></script>
  <!-- sweetalert2 -->
  <script src="/sgme_hys/Assets/Util/js/sweetalert2.js"></script>

</body>

</html>
<!-- FIN CONTENIDO DE LA PAGINA HTML -->

<script src="../Assets/js/recuperar_password.js"></script><!-- Esta es la conexión del archivo recuperar_password.php con el archivo recuperar_password.js -->