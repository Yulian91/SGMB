<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php';
?>
<!-- Titulo de la pagina modulo gestionar clientes -->
<title>SGME H&S - Modulo Clientes</title>

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL CLIENTE EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_cliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear cliente -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Crear cliente</h3><!-- Titulo del modal crear datos del cliente -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de cliente -->
          <form id="form-crear-cliente" class="row">
            <!-- id = Es el identificador del formulario crear cliente -->
            <div class="col-md-6">
              <label for="nombre_cliente" class="form-label">Cliente / Empresa</label>
              <!-- Caja de texto para ingresar nombre del cliente -->
              <input type="text" class="form-control" id="nombre" placeholder="Ingrese el nombre del cliente" required>
            </div>
            <div class="col-md-6">
              <label for="nit_cliente" class="form-label">Nit / Id</label>
              <!-- Caja de texto para ingresar nit o id del cliente -->
              <input type="text" class="form-control" id="nit" placeholder="Ingrese el nit" required>
            </div>
            <div class="col-md-6">
              <label for="telefono_cliente" class="form-label">Telefono cliente</label>
              <!-- Caja de texto para ingresar telefono del cliente -->
              <input type="text" class="form-control" id="telefono" placeholder="Ingrese el telefono del contacto" required>
            </div>
            <div class="col-md-6">
              <label for="tipo_contrato" class="form-label">Tipo de contrato</label>
              <!-- Caja de texto para ingresar tipo de contrato del cliente -->
              <input type="text" class="form-control" id="tipo_contrato" placeholder="Ingrese el tipo de contrato" required>
            </div>
            <div class="col-md-6">
              <label for="num_contrato" class="form-label">No. de contrato</label>
              <!-- Caja de texto para ingresar numero de contrato del cliente -->
              <input type="text" class="form-control" id="num_contrato" placeholder="Ingrese el Nº de contrato" required>
            </div>
            <div class="col-md-6">
              <label for="direccion_cliente" class="form-label">Dirección / Ciudad</label>
              <!-- Caja de texto para ingresar la dirección del cliente -->
              <input type="text" class="form-control" id="direccion" placeholder="Ingrese la dirección de residencia" required>
            </div>
            <div class="col-md-6">
              <label for="usuario" class="form-label">Nombre del contacto</label>
              <!-- Caja de texto para ingresar nombre del contacto del cliente -->
              <input type="text" class="form-control" id="name_contacto" placeholder="Ingrese el nombre del contacto" required>
            </div>
            <div class="col-md-6">
              <label for="email_cliente" class="form-label">Correo electronico</label>
              <!-- Caja de texto para ingresar correo electroníco del cliente -->
              <input type="text" class="form-control" id="email" placeholder="Ingrese el correo electronico" required>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del cliente -->
          <button type="button" id="btn_limpiar_1" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del cliente -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DEL CLIENTE -->
<div class="modal fade" id="editar_cliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear cliente -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Editar cliente</h3><!-- Titulo del modal crear datos del cliente -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos del cliente -->
          <form id="form-editar-cliente" class="row">
            <!-- id = Es el identificador del formulario editar cliente -->
            <div class="col-md-6">
              <input type="hidden" id="id_cliente">
              <label for="nombre_cliente" class="form-label">Cliente / Empresa</label>
              <!-- Caja de texto para ingresar el nuevo nombre del cliente -->
              <input type="text" class="form-control" id="nombre_cli" placeholder="Ingrese el nombre del cliente" required>
            </div>
            <div class="col-md-6">
              <label for="nit_cliente" class="form-label">Nit / Id</label>
              <!-- Caja de texto para ingresar el nuevo nit o id del cliente -->
              <input type="text" class="form-control" id="nit_cli" placeholder="Ingrese el nit" required>
            </div>
            <div class="col-md-6">
              <label for="telefono_cliente" class="form-label">Telefono cliente</label>
              <!-- Caja de texto para ingresar el nuevo telefono del cliente -->
              <input type="text" class="form-control" id="telefono_cli" placeholder="Ingrese el telefono del contacto" required>
            </div>
            <div class="col-md-6">
              <label for="tipo_contrato" class="form-label">Tipo de contrato</label>
              <!-- Caja de texto para ingresar el nuevo el tipo de contrato del cliente -->
              <input type="text" class="form-control" id="tipo_contrato_cli" placeholder="Ingrese el tipo de contrato" required>
            </div>
            <div class="col-md-6">
              <label for="num_contrato" class="form-label">No. de contrato</label>
              <!-- Caja de texto para ingresar el nuevo numero de contrato del cliente -->
              <input type="text" class="form-control" id="no_contrato_cli" placeholder="Ingrese el Nº de contrato" required>
            </div>
            <div class="col-md-6">
              <label for="direccion_cliente" class="form-label">Dirección / Ciudad</label>
              <!-- Caja de texto para ingresar la nueva dirección del cliente -->
              <input type="text" class="form-control" id="direccion_cli" placeholder="Ingrese la dirección de residencia" required>
            </div>
            <div class="col-md-6">
              <label for="usuario" class="form-label">Nombre del contacto</label>
              <!-- Caja de texto para ingresar el nuevo nombre del contacto del cliente -->
              <input type="text" class="form-control" id="name_contacto_cli" placeholder="Ingrese el nombre del contacto" required>
            </div>
            <div class="col-md-6">
              <label for="email_cliente" class="form-label">Correo electronico</label>
              <!-- Caja de texto para ingresar el nuevo correo electronico del cliente -->
              <input type="text" class="form-control" id="email_cli" placeholder="Ingrese el correo electronico" required>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del cliente -->
          <button type="button" id="btn_limpiar_2" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del cliente -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- CONTENIDO DEL MODULO GESTIONAR CLIENTES -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestionar Clientes</h1><!-- Titulo del Modulo gestionar clientes -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Gestionar clientes</li><!-- Este item nos indica que nos encontramos en el modulo gestionar clientes -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR CLIENTES -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar clientes</h3><!-- Titulo del buscador -->
          <div class="input-group">
            <input type="text" id="buscar_cliente" class="form-control float-left" placeholder="Ingresar el nombre y/o razon social del cliente"><!-- Este campo es para buscar el nombre de un cliente en especifico -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            <button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_cliente">Crear cliente</button><!-- Este boton es para crear una nueva area. Al dar clic se abrira el modal crear cliente -->
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de los clientes registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info">
              <!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr>
                <!-- Cabecera que contiene los titulos de la tabla -->
                <th>Cliente / Empresa</th>
                <th>Nit / Id</th>
                <th>Telefono</th>
                <th>Tipo Contrato</th>
                <th># Contrato</th>
                <th>Dirección / Ciudad</th>
                <th>@Email</th>
                <th>Nombre Contacto</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <!-- id = Es el identificador de la tabla clientes -->
            <tbody class="table-active" id="clientes">
            </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer">
        </div>
      </div>
    </div>
    <!-- /.FIN CONTENIDO DE LA TABLA -->
  </section>
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR CLIENTES -->
<?php
// Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php';
?>
<!--/.Esta es la conexión del archivo clientes.php con el archivo gestionar_clientes.js -->
<script src="/sgme_hys/Assets/js/gestionar_clientes.js"></script>