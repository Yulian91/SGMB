<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php'; 
?>

<!-- Titulo del modulo gestionar usuario -->
<title>SGME H&S - Modulo Usuarios</title>

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL USUARIO EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_usuario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear usuario -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Crear usuario</h3><!-- Titulo del modal crear datos del usuario -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos del usuario -->
          <form id="form-crear-usuario" class="row g-3">
            <!-- id = Es el identificador del formulario crear usuario -->
            <div class="col-md-6">
              <label for="nombre" class="form-label">Nombre</label>
              <!-- Caja de texto para ingresar el nombre del usuario -->
              <input type="text" class="form-control" id="nombre" placeholder="Ingrese el nombre del usuario" required>
            </div>
            <div class="col-md-6">
              <label for="apellido" class="form-label">Apellidos</label>
              <!-- Caja de texto para ingresar los apellidos del usuario -->
              <input type="text" class="form-control" id="apellido" placeholder="Ingrese los apellidos del usuario" required>
            </div> 
            <div class="col-md-6">
              <label for="email" class="form-label">Correo Electrónico</label>
              <!-- Caja de texto para ingresar el correo electronico del usuario -->
              <input type="text" class="form-control" id="email" placeholder="Ingrese el correo electronico" required>
            </div>
            <div class="col-md-6">
              <label for="identificacion" class="form-label">Identificación</label>
              <!-- Caja de texto para ingresar el numero de identificación del usuario -->
              <input type="number" class="form-control" id="identificacion" placeholder="Ingrese el No identificación" required>
            </div>
            <div class="col-md-6">
              <label for="contacto" class="form-label">Contacto Telefonico</label>
              <!-- Caja de texto para ingresar el numero del celular y/o telefono del usuario -->
              <input type="number" class="form-control" id="contacto" placeholder="Ingrese el No celular y/o telefono" required>
            </div>
            <div class="col-md-6">
              <label for="direccion" class="form-label">Dirección</label>
              <!-- Caja de texto para ingresar dirección de residencia del usuario -->
              <input type="text" class="form-control" id="direccion" placeholder="Ingrese la dirección de residencia" required>
            </div>
            <div class="col-md-6">
              <label for="contrasena" class="form-label">Contraseña</label>
              <!-- Caja de texto para ingresar la contraseña del usuario -->
              <input type="text" class="form-control" id="contrasena" placeholder="Ingrese la contraseña" required>
            </div>
            <div class="col-md-6">
              <label for="tipo" class="form-label">Tipo Usuario</label>
              <!-- seleccionar el tipo de usuario -->
              <select id="tipo" class="form-control" aria-label="Default select example" style="width: 100%;">
                <option selected>Seleccione el tipo de usuario</option>
                <option value="2">Administrador</option>
                <option value="3">Tecnico</option>
                <option value="4">Cliente</option>
              </select>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del usuario -->
          <button type="button" id="btn_limpiar_1" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del usuario -->
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DEL USUARIO -->
<div class="modal fade" id="editar_usuario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<!-- id = Es la identificación del modal editar usuario -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Editar usuario</h3><!-- Titulo del modal editar datos del usuario -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de la ciudad -->
          <form id="form-editar-usuario" class="row g-3">
            <!-- id = Es el identificador del formulario editar usuario -->
            <div class="col-md-6">
              <input type="hidden" id="id_usuario">
              <label for="nombre" class="form-label">Nombre</label>
              <!-- Caja de texto para ingresar el nuevo nombre del usuario -->
              <input type="text" class="form-control" id="nombre_usu" placeholder="Ingrese el nombre" required>
            </div>
            <div class="col-md-6">
              <label for="apellido" class="form-label">Apellidos</label>
              <!-- Caja de texto para ingresar el nuevo apellido del usuario -->
              <input type="text" class="form-control" id="apellido_usu" placeholder="Ingrese los apellidos" required>
            </div>
            <div class="col-md-6">
              <label for="email" class="form-label">Correo Electrónico</label>
              <!-- Caja de texto para ingresar el nuevo correo electronico del usuario -->
              <input type="text" class="form-control" id="email_usu" placeholder="Ingrese el correo electronico" required>
            </div>
            <div class="col-md-6">
              <label for="identificacion" class="form-label">Identificación</label>
              <!-- Caja de texto para ingresar el nuevo numero de identificación del usuario -->
              <input type="number" class="form-control" id="identificacion_usu" placeholder="Ingrese el No identificación" required><
            </div>
            <div class="col-md-6">
              <label for="contacto" class="form-label">Contacto Telefonico</label>
              <!-- Caja de texto para ingresar el nuevo contacto telefonico del usuario -->
              <input type="number" class="form-control" id="contacto_usu" placeholder="Ingrese el No celular y/o telefono" required>
            </div>
            <div class="col-md-6">
              <label for="direccion" class="form-label">Dirección</label>
              <!-- Caja de texto para ingresar la nueva dirección del usuario -->
              <input type="text" class="form-control" id="direccion_usu" placeholder="Ingrese la dirección de residencia" required>
            </div>
            <div class="col-md-6">
              <label for="contrasena" class="form-label">Contraseña</label>
              <!-- Caja de texto para ingresar la nueva contraseña del usuario -->
              <input type="text" class="form-control" id="contrasena_usu" placeholder="Ingrese la contraseña" required>
            </div>
            <div class="col-md-6">
              <label for="tipo" class="form-label">Tipo Usuario</label>
              <!-- seleccionar el nuevo tipo de usuario -->
              <select id="tipo_usu" class="form-control" aria-label="Default select example" style="width: 100%;">
                <option selected>Seleccione el tipo de usuario</option>
                <option value="2">Administrador</option>
                <option value="3">Tecnico</option>
                <option value="4">Cliente</option>
              </select>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del usuario -->
          <button type="button" id="btn_limpiar_2" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del usuario -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- CONTENIDO DEL MODULO GESTIONAR USUARIOS -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestionar Usuarios</h1><!-- Titulo del Modulo gestionar usuarios -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Gestionar usuarios</li><!-- Este item nos indica que nos encontramos en el modulo gestionar usuarios -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR USUARIOS  -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar usuarios</h3><!-- Titulo del buscador -->
          <div class="input-group">
            <input type="text" id="buscar-usuarios" class="form-control float-left" placeholder="Ingresar el nombre del usuario"><!-- Este campo es para buscar el nombre de un usuario en especifico -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            <button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_usuario">Crear usuarios</button><!-- Este boton es para crear un usuario. Al dar clic se abrira el modal crear usuario -->
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de los usuarios registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info">
              <!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr>
                <!-- Estos son los titulos de la tabla -->
                <th>Nombre(s)</th>
                <th>Apellido(s)</th>
                <th>@Email</th>
                <th>Identificación</th>
                <th>Telefono</th>
                <th>Dirección</th>
                <th>Contraseña</th>
                <th>Tipo Usuario</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <!-- id = Es el identificador de la tabla usuarios -->
            <tbody class="table-active" id="usuarios">
            </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer">
          <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-end">
              <li class="page-item">
                <a class="page-link" href="#" aria-label="Previous">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
              <li class="page-item active"><a class="page-link" href="#">1</a></li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
              <li class="page-item">
                <a class="page-link" href="#" aria-label="Next">
                  <span aria-hidden="true">&raquo;</span>
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR USUARIOS -->
<?php
 // Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php';
?>
<!--/.Esta es la conexión del archivo areas.php con el archivo gestionar_ciudades.js -->
<script src="/sgme_hys/Assets/js/gestionar_usuario.js"></script>
