<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php'; 
?>
<!-- Titulo de la pagina modulo de reportes -->
<title>SGME H&S - Modulo Reportes</title>

<!-- Condicional para verificar si la url trae algún dato o viene vacia -->
<?php

if (empty($_REQUEST['id'])) {
  $equipo = '';
  $marca = '';
  $modelo = 'ERROR! NO ES POSIBLE CREAR EL REPORTE DE SERVICIO';
  $serie = '';
  $sede = '';
  $area = '';
  $evento = '';
} else {
  $inventario = $_REQUEST['id'];
  $equipo = $_REQUEST['equipo'];
  $marca = $_REQUEST['marca'];
  $modelo = $_REQUEST['modelo'];
  $serie = $_REQUEST['serie'];
  $sede = $_REQUEST['sede'];
  $area = $_REQUEST['area'];
  $evento = $_REQUEST['evento'];
}

?>
<!-- Fin del condicional -->

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL REPORTE EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_reporte" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear reporte -->
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Crear reporte de servicio</h3><!-- Titulo del modal crear datos del reporte -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos del reporte -->
          <form id="form-crear-reporte" enctype="multipart/form-data">
            <!-- id = Es el identificador del formulario crear reporte -->
            <div class="card">
              <div class="card-body">
                <div class="row">
                  <!-- Muestra los datos del equipo que se encuentra en el inventario el cual se realizara el reporte -->
                  <input type="text" class="form-control" id="inventario" value="<?php echo $inventario ?>" readonly>
                  <div class="col-md-12">
                    <strong><?php echo $evento ?> |</strong>
                    <strong><?php echo $equipo ?> |</strong>
                    <strong><?php echo $marca ?> |</strong>
                    <strong><?php echo $modelo ?> |</strong>
                    <strong><?php echo $serie ?> |</strong>
                    <strong><?php echo $sede ?> |</strong>
                    <strong><?php echo $area ?> |</strong>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-3">
                <label for="fecha_inicio" class="form-label">F. Inicio</label>
                <!-- Caja de texto para ingresar fecha inicial del mantenimiento -->
                <input type="date" class="form-control" id="fecha_inicio" required>
              </div>
              <div class="col-md-3">
                <label for="hora_inicio" class="form-label">Hora</label>
                <!-- Caja de texto para ingresar Hora inicial del mantenimiento -->
                <input type="time" class="form-control" id="hora_inicio" required>
              </div>
              <div class="col-md-3">
                <label for="fecha_final" class="form-label">F. Finalización</label>
                <!-- Caja de texto para ingresar fecha final del mantenimiento-->
                <input type="date" class="form-control" id="fecha_final" required>
              </div>
              <div class="col-md-3">
                <label for="hora_final" class="form-label">Hora</label>
                <!-- Caja de texto para ingresar la hora final del mantenimiento -->
                <input type="time" class="form-control" id="hora_final" required>
              </div>
            </div>
            <br />
            <div class="row">
              <div class="col-md-3">
                <label for="tipo_asistencia" class="form-label">Tipo de Asistencia</label>
                 <!-- Seleccionar el tipo de asistencia -->
                <select id="asistencia" class="form-control" aria-label="Default select example" style="width: 100%;">
                  <option selected>Seleccione el tipo de asistencia</option>
                  <option value="1">Remoto</option>
                  <option value="2">Telefono</option>
                  <option value="3">Presencial</option>
                </select>
              </div>
              <div class="col-md-3">
                <label for="lista_tipo_matto" class="form-label">Tipo de Servicio</label>
                <!-- Seleccionar el tipo de servicio -->
                <select id="tipo_matto" class="form-control" aria-label="Default select example" style="width: 100%;" onchange="otro_servicio(this.value);">
                  <option selected>Seleccione el tipo de servicio</option>
                  <option value="1">Mantenimiento Preventivo</option>
                  <option value="2">Mantenimiento Correctivo</option>
                  <option value="3">Mantenimiento Pedictivo</option>
                  <option value="4">Instalación</option>
                  <option value="5">Diagnóstico</option>
                  <option value="6">Desinstalación</option>
                  <option value="7">Otro</option>
                </select>
                <div id="otro_tipo_servicio" style="display: none;">
                  <input type="text" class="form-control" id="otro_matto" value="NA">
                </div>
              </div>
              <div class="col-md-3">
                <label for="lista_protocolos" class="form-label">Listas de Protocolos</label>
                <!-- Seleccionar el protocolo para el equipo -->
                <select id="protocolos" class="form-control" aria-label="Default select example" style="width: 100%;">
                  <option selected>Seleccione el protocolo</option>
                  <option value="1">No Aplica</option>
                  <option value="2">Rayos X Portatil</option>
                  <option value="3">Rayos X Convencional</option>
                  <option value="4">Mamografo</option>
                  <option value="5">Telecomandado</option>
                  <option value="6">Digitalizador de Imágenes</option>
                </select>
              </div>
              <div class="col-md-3">
                <label for="lista_problema_reportado" class="form-label">Problemas Reportados</label>
                <!-- Seleccionar el problema reportado -->
                <select id="problemas" class="form-control" aria-label="Default select example" style="width: 100%;" onchange="otro_problema(this.value);">
                  <option selected>Seleccione el problema reportado</option>
                  <option value="1">Eléctrico</option>
                  <option value="2">Electrónico</option>
                  <option value="3">Mecánico</option>
                  <option value="4">Conexión</option>
                  <option value="5">Operativo</option>
                  <option value="6">Accesorio</option>
                  <option value="7">Inconsistencia de Software</option>
                  <option value="8">Actualización</option>
                  <option value="9">No Aplica</option>
                  <option value="10">Otro</option>
                </select>
                <div id="otro_problema_reportado" style="display: none;">
                <!-- Caja de texto para ingresar otro tipo de problema -->
                  <input type="text" class="form-control" id="otro_problema_report" value="NA">
                </div>
              </div>
            </div>
            <br>
            <div class="row">
              <div class="col-md-6">
                <label for="motivo_servicio" class="form-label">Motivo del Servicio</label>
                 <!-- Caja de texto para ingresar el motivo del servicio de mantenimiento -->
                <textarea type="text" class="form-control" id="motivo_servicio" placeholder="Ingrese el motivo del servicio" rows="3" required></textarea>
              </div>
              <div class="col-md-6">
                <label for="estado_equipo" class="form-label">Estado inicial del equipo</label>
                 <!-- Caja de texto para ingresar el estado inicial del equipo -->
                <textarea type="text" class="form-control" id="estado_equipo" placeholder="Ingrese el estado inicial del equipo" rows="3" required></textarea>
              </div>
              <div class="col-md-6">
                <label for="actividades_realizadas" class="form-label">Actividades Realizadas</label>
                 <!-- Caja de texto para ingresar las actividades realizadas en el mantenimiento -->
                <textarea type="text" class="form-control" id="actividades" placeholder="Ingrese las actividades realizadas" rows="3" required></textarea>
              </div>
              <div class="col-md-6">
                <label for="observaciones" class="form-label">Observaciones Generales</label>
                 <!-- Caja de texto para ingresar las observaciones del servicio -->
                <textarea type="text" class="form-control" id="observaciones" placeholder="Ingrese las observaciones del servicio" rows="3" required></textarea>
              </div>
            </div>
            <br />
            <div class="row">
              <div class="col-md-6">
                <div class="panel-heading">
                  <h6 class="panel-title text-center"><strong>REPUESTOS Y/O ACCESORIOS UTILIZADOS</strong></h6>
                </div>
                <div class="panel-body">
                  <div class="col-md-12">
                    <div class="form-row">
                      <div class="col-md-6">
                        <label for="cantidad" class="form-label">Cantidad</label>
                         <!-- Caja de texto para Ingresar la cantidad de repuestos utilizados -->
                        <textarea type="text" class="form-control" id="cantidad_1" placeholder="Ingrese la cantidad de repuestos utilizados" rows="2" required></textarea>
                      </div>
                      <div class="col-md-6">
                        <label for="descripcion" class="form-label">Descripción</label>
                         <!-- Caja de texto para Ingresar la descripción de los repuestos utilizados-->
                        <textarea type="text" class="form-control" id="descripcion_1" placeholder="Ingrese la descripción de los repuestos utilizados" rows="2" required></textarea>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="panel-heading">
                  <h6 class="panel-title text-center"><strong>REPUESTOS Y/O ACCESORIOS A COTIZAR</strong></h6>
                </div>
                <div class="panel-body">
                  <div class="col-md-12">
                    <div class="form-row">
                      <div class="col-md-6">
                        <label for="cantidad" class="form-label">Cantidad</label>
                         <!-- Caja de texto patra ingresar la cantidad de repuestos a cotizar -->
                        <textarea type="text" class="form-control" id="cantidad_2" placeholder="Ingrese la cantidad de repuestos a cotizar" rows="2" required></textarea>
                      </div>
                      <div class="col-md-6">
                        <label for="descripcion" class="form-label">Descripción</label>
                         <!-- Caja de texto ingresar la descripción de los repuestos a cotizar   -->
                        <textarea type="text" class="form-control" id="descripcion_2" placeholder="Ingrese la descripción de los repuestos a cotizar" rows="2" required></textarea>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <br>
            <div class="row">
              <div class="col-md-12">
                <label for="nombre_tecnico" class="form-label">Reporte realizado por:</label>
                 <!-- Seleccionar el nombre del tecnio quien realizo el reporte -->
                <select id="tecnico" class="form-control" aria-label="Default select example" style="width: 100%;"></select>
              </div>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del reporte -->
          <button type="button" id="btn_limpiar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del reporte -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- MODAL CON EL FORMULARIO PARA FIRMAR EL REPORTE -->
<div class="modal fade" id="firma_reporte" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal firmar reporte de servicio -->
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Firmar reporte</h3><!-- Titulo del modal firmar el reporte de servicio -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos para firmar el reporte de servicio -->
          <form id="form-firma-reporte" enctype="multipart/form-data">
            <!-- id = Es el identificador del formulario firmar reporte -->
            <div class="row">
              <div class="col-md-12">
                <div class="panel-heading">
                  <div class="card">
                    <div class="card-body">
                      <div class="row">
                        <div class="col-md-12">
                          <label for="no_reporte" class="form-label">No. Reporte</label>
                          <!-- Muestra el numero del reporte el cual se va a firmar -->
                          <input type="text" class="form-control" name="no_reporte" id="no_reporte" readonly>
                        </div>
                        <div class="col-md-6">
                          <label for="equipo_operativo" class="form-label">¿Equipo Operativo?</label>
                          <!-- Seleccionar si el equipo queda operativo -->
                          <select id="equipo_operativo" name="equipo_operativo" class="form-control" aria-label="Default select example" style="width: 100%;">
                            <option selected>¿El equipo queda operativo?</option>
                            <option value="Si">Si</option>
                            <option value="No">No</option>
                          </select>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Evidencias</label><!-- Titulo del de las evidencias fotogaficas -->
                            <div class="card border-primary">
                              <div class="card-body">
                                <label for="evidencia_matto" id="icon-image"></i></label>
                                <!-- Campo para subir una imagen tipo JPEG, PNG -->
                                <input type="file" name="img_evidencia1" class="input-group">
                                <!-- Campo para subir una imagen tipo JPEG, PNG -->
                                <input type="file" name="img_evidencia2" class="input-group">
                                <!-- Campo para subir una imagen tipo JPEG, PNG -->
                                <input type="file" name="img_evidencia3" class="input-group">
                                <!-- Previsualización de la imagen -->
                                <img class="img-thumbnail" id="img-preview-evidencia">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="card">
                    <div class="card-body">
                      <h6 class="panel-title text-center"><strong>ACEPTADO POR</strong></h6>
                      <div class="row">
                        <div class="panel-body">
                          <div class="col-md-12">
                            <div class="form-row">
                              <div class="col-md-6">
                                <label for="nombre_cliente" class="form-label">Nombre quien recibe</label>
                                <!-- Caja de texto para ingresar el nombre de la persona quien recibe el reporte -->
                                <input type="text" class="form-control" name="nombre_cliente" id="nombre_cliente">
                              </div>
                              <div class="col-md-6">
                                <label for="ident_cliente" class="form-label">Identificación</label>
                                <!-- Caja de texto para ingresar el numero de identificación del personal quien recibe el reporte -->
                                <input type="text" class="form-control" name="ident_cliente" id="ident_cliente">
                              </div>
                              <div class="col-md-12">
                                <div class="form-group">
                                  <label>Firma digital</label><!-- Titulo de la firma digital -->
                                  <div class="card border-primary">
                                    <div class="card-body">
                                      <label for="firm_cliente" id="icon-image"></i></label>
                                      <span id="icon-cerrar"></span>
                                      <!-- Campo para subir una imagen tipo JPEG, PNG y el evento de previsualizar la imagen-->
                                      <input type="file" name="img_firma" class="input-group" onchange="preview_firma_cl(event)">
                                      <!-- Envia la función para la firma -->
                                      <input type="hidden" name="funcion" id="funcion">
                                      <img class="img-thumbnail" id="img-preview-cli">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos de la firma del reporte -->
          <button type="button" id="btn_limpiar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos de la firma del reporte -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- CONTENIDO DEL MODULO GESTIONAR REPORTES -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestionar Reportes</h1><!-- Titulo del Modulo gestionar reportes -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Gestionar reportes</li><!-- Este item nos indica que nos encontramos en el modulo gestionar reportes -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR AREAS -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar reportes</h3>
          <div class="input-group">
            <input type="text" id="buscar_reporte" class="form-control float-left" placeholder="Ingresar el numero del reporte de servicio"><!-- Este campo es para buscar el nombre de un reporte en especifico -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            <?php
            if (empty($_REQUEST['id'])) {
              echo '<a type="button" class="btn bg-gradient-success ml-4" href="Cronograma.php" title="Para crear un reporte debes ir al cronograma / listado de matto, puedes dar click aquí">
                        <i class="fas fa-arrow-alt-circle-left"></i>
                      </a>';
            } else {
              echo '<button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_reporte" >Crear reporte</button>'; // Este boton es para crear un reporte. Al dar clic se abrira el modal crear reporte //
            }
            ?>
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de los reportes registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info">
              <!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr>
                <!-- Estos son los titulos de la tabla -->
                <th>No. Reporte</th>
                <th>Tipo Asistencia</th>
                <th>Fecha Inicio</th>
                <th>Fecha Final</th>
                <th>Equipo</th>
                <th>Serie</th>
                <th>Sede</th>
                <th>Area</th>
                <th>Tipo Servicio</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <!-- id = Es el identificador de la tabla reportes -->
            <tbody class="table-active" id="reportes">
            </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer">
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR REPORTES -->
<?php
 // Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php';
?>
<!--/.Esta es la conexión del archivo reportes.php con el archivo gestionar_reportes.js -->
<script src="/sgme_hys/Assets/js/gestionar_reportes.js"></script>
