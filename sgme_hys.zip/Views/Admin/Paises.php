<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php';
?>
<!-- Titulo de la pagina modulo gestionar paises -->
<title>SGME H&S - Modulo Paises</title>

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL PAIS EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_pais" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear paises -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-success">
        <div class="card-header">
          <h3 class="card-title">Crear paises</h3><!-- Titulo del modal crear datos pais -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos del pais -->
          <form id="form-crear-pais" class="row">
            <!-- id = Es el identificador del formulario crear pais -->
            <div class="col-md-12">
              <label for="nombre_pais" class="form-label">Nombre del país</label>
              <!-- Caja de texto para ingresar el nombre del pais -->
              <input type="text" class="form-control" id="nombre_pais" placeholder="Ingrese el nombre del país" required>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del pais -->
          <button type="button" id="btn_limpiar_1" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del pais -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DEL PAIS -->
<div class="modal fade" id="editar_pais" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crar pais -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-success">
        <div class="card-header">
          <h3 class="card-title">Editar paises</h3><!-- Titulo del modal crear datos pais -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos del pais -->
          <form id="form-editar-pais" class="row">
            <!-- id = Es el identificador del formulario ediar pais -->
            <div class="col-md-12">
              <input type="hidden" id="id_pais">
              <label for="nombre_pais" class="form-label">Nombre del país</label>
              <!-- Caja de texto para ingresar el nuevo nombre del pais -->
              <input type="text" class="form-control" id="nombre_pais_edit" placeholder="Ingrese el nombre del país" required>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del pais -->
          <button type="button" id="btn_limpiar_2" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del pais -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- CONTENIDO DEL MODULO GESTIONAR PAISES -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestionar Paises</h1><!-- Titulo del Modulo gestionar paises -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Gestionar paises</li><!-- Este item nos indica que nos encontramos en el modulo gestionar paises -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR PAISES -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar paises</h3><!-- Titulo del buscador -->
          <div class="input-group">
            <input type="text" id="buscar_pais" class="form-control float-left" placeholder="Ingresar el nombre del pais"><!-- Este campo es para buscar el nombre de un pais en especifico -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            <button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_pais">Crear pais</button><!-- Este boton es para crear un nuevo pais. Al dar clic se abrira el modal crear pais -->
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de los paises registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info">
              <!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr>
                <!-- Estos son los titulos de la tabla -->
                <th>N.</th>
                <th>Pais</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
             <!-- id = Es el identificador de la tabla paises -->
            <tbody class="table-active" id="paises">
            </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer">
          <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-end">
              <li class="page-item">
                <a class="page-link" href="#" aria-label="Previous">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
              <li class="page-item active"><a class="page-link" href="#">1</a></li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
              <li class="page-item">
                <a class="page-link" href="#" aria-label="Next">
                  <span aria-hidden="true">&raquo;</span>
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR PAISES -->
<?php
// Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php'; 
?>
<!--/.Esta es la conexión del archivo paises.php con el archivo gestionar_paises.js -->
<script src="/sgme_hys/Assets/js/gestionar_paises.js"></script>
