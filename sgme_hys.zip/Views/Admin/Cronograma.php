<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php';
?>

<!-- Titulo de la pagina modulo gestionar cronograma -->
<title>SGME H&S - Modulo Cronograma</title>

<!-- Condicional para verificar si la url trae algún dato o viene vacia -->
<?php

if (empty($_REQUEST['id_inv'])) {
  $id_inv = '';
  $nombre_equipo = '!ERROR¡ NO';
  $marca = 'HAY DATOS';
} else {
  $id_inv = $_REQUEST['id_inv'];
  $nombre_equipo = $_REQUEST['equipo'];
  $marca = $_REQUEST['marca'];
}

?>
<!-- Fin del condicional -->

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL EVENTO EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_cronograma" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear evento -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card">
        <div class="card-header bg-info">
          <h2 class="card-title" id="titulo_evento"></h2><!-- Titulo del modal crear datos del evento -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos del evento -->
          <form id="form-crear-evento" class="row">
            <!-- id = Es el identificador del formulario crear evento -->
            <div class="col-md-6">
              <label for="inventario_equipo" class="form-label">Nombre Equipo</label>
              <!-- Caja de texto con el id del equipo -->
              <input type="hidden" class="form-control" id="inventario" value="<?php echo $id_inv ?>" readonly>
              <!-- Caja de texto con el nombre y marca del equipo -->
              <label class="form-control"><?php echo $nombre_equipo ?> <?php echo $marca ?></label>
            </div>
            <div class="col-md-6">
              <label for="titulo" class="form-label">Actividad</label>
              <!-- Caja de texto para ingresar la actividad del evento -->
              <input type="text" class="form-control" id="titulo">
            </div>
            <div class="col-md-6">
              <label for="fecha_evento" class="form-label">Fecha Inicio</label>
              <!-- Caja de texto para ingresar la fecha de incio del evento -->
              <input type="date" class="form-control" name="fecha_inicio" id="fecha_inicio">
            </div>
            <div class="col-md-6">
              <label for="hora_inicio" class="form-label">Hora</label>
              <!-- Caja de texto para ingresar la hora de inicio del evento -->
              <input type="time" class="form-control" name="hora_inicio" id="hora_inicio">
            </div>
            <div class="col-md-6">
              <label for="fecha_evento" class="form-label">Fecha Final</label>
              <!-- Caja de texto para ingresar la fecha final del evento -->
              <input type="date" class="form-control" name="fecha_final" id="fecha_final">
            </div>
            <div class="col-md-6">
              <label for="hora_final" class="form-label">Hora</label>
              <!-- Caja de texto para ingresar la hora final del evento -->
              <input type="time" class="form-control" name="hora_final" id="hora_final">
            </div>
            <div class="col-md-12">
              <label for="descrip_evento" class="form-label">Descripcíon</label>
              <!-- Caja de texto para ingresar la descripción del evento -->
              <textarea type="text" class="form-control" id="descripcion" rows="2"></textarea>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del evento -->
          <button type="button" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del evento -->
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DEL EVENTO -->
<div class="modal fade" id="editar_cronograma" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crea evento -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card">
        <div class="card-header bg-info">
          <h2 class="card-title">Editar matto agendado</h2><!-- Titulo del modal crear datos del evento -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos del evento -->
          <form id="form-editar-evento" class="row">
            <!-- id = Es el identificador del formulario editar evento-->
            <div class="col-md-6">
              <input type="hidden" class="form-control" id="id_evento">
              <label for="inventario_equipo" class="form-label">Nombre Equipo</label>
              <!-- Caja de texto con el id del equipo -->
              <input type="hidden" class="form-control" id="inventario_edit" readonly>
              <!-- Caja de texto con el nombre del equipo -->
              <input type="text" class="form-control" id="nombre_equipo" readonly>
            </div>
            <div class="col-md-6">
              <label for="titulo" class="form-label">Actividad</label>
              <!-- Caja de texto para ingresar la nueva actividad del evento -->
              <input type="text" class="form-control" id="titulo_edit">
            </div>
            <div class="col-md-6">
              <label for="fecha_evento" class="form-label">Fecha Inicio</label>
              <!-- Caja de texto para ingresar la nueva fecha de inicio del evento -->
              <input type="date" class="form-control" name="fecha_inicio" id="fecha_inicio_edit">
            </div>
            <div class="col-md-6">
              <label for="hora_inicio" class="form-label">Hora</label>
              <!-- Caja de texto para ingresar la nueva hora de inicio del evento -->
              <input type="time" class="form-control" name="hora_inicio" id="hora_inicio_edit">
            </div>
            <div class="col-md-6">
              <label for="fecha_evento" class="form-label">Fecha Final</label>
              <!-- Caja de texto para ingresar la nueva fecha final del evento -->
              <input type="date" class="form-control" name="fecha_final" id="fecha_final_edit">
            </div>
            <div class="col-md-6">
              <label for="hora_final" class="form-label">Hora</label>
              <!-- Caja de texto para ingresar la nueva hora final del evento -->
              <input type="time" class="form-control" name="hora_final" id="hora_final_edit">
            </div>
            <div class="col-md-12">
              <label for="descrip_evento" class="form-label">Descripcíon</label>
              <!-- Caja de texto para ingresar la nueva descripción del evento -->
              <textarea type="text" class="form-control" id="descripcion_edit" rows="2"></textarea>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del evento -->
          <button type="button" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del evento -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- CONTENIDO DEL MODULO GESTIONAR CRONOGRMA -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Cronograma de Mantenimientos</h1><!-- Titulo del Modulo gestionar cronograma de mantemientos -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Cronograma de mattos</li><!-- Este item nos indica que nos encontramos en el modulo gestionar cronograma mattos-->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA Y EL CALENDARIO DEL MODULO CRONOGRAMA -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <ul class="nav nav-pills">
                <!-- Este item nos indica que nos encontramos en el modulo cronograma de mantenimientos -->
                <li class="nav-item"><a href="#cronograma_matto" class="nav-link active" data-toggle="tab">Cronograma mantenimiento</a></li>
                <!-- Al dar clic en este item nos direccionara al listado de mantenimientos programados -->
                <li class="nav-item"><a href="#list_matto" class="nav-link" data-toggle="tab">Listado mattos programados</a></li>
              </ul>
            </div>
            <div class="card-body">
              <div class="tab-content">
                <div class="tab-pane active" id="cronograma_matto">
                  <!-- id = Es el identificador del modulo cronograma de mantenimientos -->
                  <!-- CALENDARIO -->
                  <div id="calendar" class="fc fc-media-screen fc-direction-ltr fc-theme-bootstrap"></div><!-- id = Es el identificador del calendario -->
                </div>
                <div class="tab-pane" id="list_matto">
                  <!-- id = Es el identificador del modulo listado de mantenimientos -->
                  <div class="card card-info">
                    <div class="card-header">
                      <div class="card-title">Listado de mantenimientos programados</div><!-- Titulo del Modulo listado de mantenimientos programados -->
                    </div>
                    <div class="card-body p-0 table-responsive">
                      <!-- Esta es la tabla de los datos de las areas registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
                      <table class="table table-over text-nowrap">
                        <thead class="table-info">
                          <!-- Este es la clase de la tabla la cual define el color de la misma -->
                          <tr>
                            <!-- Estos son los titulos de la tabla -->
                            <th>N.</th>
                            <th>Equipo</th>
                            <th>Serie</th>
                            <th>Actividad</th>
                            <th>Fecha Inicio</th>
                            <th>Fecha Final</th>
                            <th>Sede</th>
                            <th>Descripcíon</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                          </tr>
                        </thead>
                        <!-- id = Es el identificador de la tabla eventos -->
                        <tbody class="table-active" id="listado_matto">
                        </tbody>
                      </table>
                      <!-- Fin de la tabla -->
                    </div>
                    <div class="card-footer"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.FIN CONTENIDO DE LA TABLA -->
  </section>
  <!-- /.FIN CONTENIDO MODULO GESTIONAR CRONOGRAMA -->
</div>


<?php
// Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php';
?>
<!--/.Esta es la conexión del archivo cronograma.php con el archivo gestionar_cronograma.js -->
<script src="/sgme_hys/Assets/js/gestionar_cronograma.js"></script>
