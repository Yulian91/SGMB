<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php';
?>
<!-- Titulo de la pagina modulo inventario de equipos -->
<title>SGME H&S - Modulo Inventario</title>

<!-- Condicional para verificar si la url trae algún dato o viene vacia -->
<?php

if (empty($_REQUEST['id'])) {
  echo "";
} else {
  $id_equipo = $_REQUEST['id'];
  $nombre_equipo = $_REQUEST['equipo'];
  $serie = $_REQUEST['serie'];
}

?>
<!-- Fin del condicional -->

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL EQUIPO EN EL INVENTARIO EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_inventario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificador del modal crear inventario -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Agregar el equipo a un contrato de arriendo o matto</h3><!-- Titulo del modal agregar un equipo a contrato -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de un equipo en el inventario -->
          <form id="form-crear-inventario" class="row">
            <!-- id = Es el identificador del formulario crear inventario -->
            <div class="col-md-6">
              <label for="nombre_equipo" class="form-label">Equipo / Serie</label>
              <!-- Muestra el id del equipo el cual se agregara al contrato -->
              <input type="hidden" class="form-control" id="equipo" value="<?php echo $id_equipo ?>" readonly>
              <!-- Muestra el nombre y la serie del equipo el cual se agregara al contrato -->
              <label class="form-control"><strong><?php echo $nombre_equipo ?></strong> / <strong><?php echo $serie ?></strong></label>
            </div>
            <div class="col-md-6">
              <label for="frecuencia_matto" class="form-label">Frecuencia de matto</label>
              <!-- Caja de texto para ingresar la frecuencia de mantenimiento del equipo -->
              <input type="text" class="form-control" id="frecuencia_matto" placeholder="Ingrese la frecuencia de mantemiento" required>
            </div>
            <div class="col-md-6">
              <label for="fijo_movil" class="form-label">Fijo / Movil</label>
              <!-- Caja de texto para ingresar si el equipo es fijo o movil -->
              <input type="text" class="form-control" id="fijo_movil" placeholder="Ingrese si el equipo es fijo o movil" required>
            </div>
            <div class="col-md-6">
              <label for="cliente" class="form-label">Cliente</label>
              <!-- Seleccionar el nombre del cliente al cual se arrendara el equipo -->
              <select id="cliente" class="form-control select2" style="width: 100%;">
                <option selected>Seleccione el tipo de usuario</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="pais" class="form-label">Pais</label>
              <!-- Seleccionar el nombre del pais del equipo -->
              <select id="pais" class="form-control select2" style="width: 100%;"></select>
            </div>
            <div class="col-md-6">
              <label for="ciudad" class="form-label">Ciudad</label>
              <!-- Seleccionar el nombre de la ciudad del equipo-->
              <select id="ciudad" class="form-control select2" style="width: 100%;"></select>
            </div>
            <div class="col-md-6">
              <label for="sede" class="form-label">Sede</label>
              <!-- Seleccionar el nombre de la sede de equipo -->
              <select id="sede" class="form-control select2" style="width: 100%;"></select>
            </div>
            <div class="col-md-6">
              <label for="area" class="form-label">Area</label>
              <!-- Seleccionar el nombre del area del equipo -->
              <select id="area" class="form-control select2" style="width: 100%;"></select>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del equipo agregado al inventario -->
          <button type="button" id="btn_no_arrendar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso del equipo al inventario -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DEL EQUIPO EN EL INVENTARIO -->
<div class="modal fade" id="editar_inventario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal editar equipo en el inventario -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Editar equipo en contrato de arrndo o matto</h3><!-- Titulo del modal editar un equipo a contrato -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para editar los datos del equipo en el inventario -->
          <form id="form-editar-inventario" class="row">
            <!-- id = Es el identificador del formulario editar inventario -->
            <div class="col-md-6">
              <input type="hidden" id="editar_invent">
              <label for="nombre_equipo" class="form-label">Nombre equipo</label>
              <!-- Muestra el nombre del equipo -->
              <input type="hidden" class="form-control" id="id_equipo" readonly>
              <!-- Muestra el id del equipo -->
              <input type="text" class="form-control" id="equipo_edit" readonly>
            </div>
            <div class="col-md-6">
              <label for="frecuencia_matto" class="form-label">Frecuencia de matto</label>
              <!-- Caja de texto para ingresar la nueva frecuencia de mantenimiento -->
              <input type="text" class="form-control" id="frec_matto_edit" placeholder="Ingrese la frecuencia de mantemiento" required>
            </div>
            <div class="col-md-6">
              <label for="fijo_movil" class="form-label">Fijo / Movil</label>
              <!-- Caja de texto para ingresar el dato si el equipo es fijo o movil -->
              <input type="text" class="form-control" id="fijo_movil_edit" placeholder="Ingrese si el equipo es fijo o movil" required>
            </div>
            <div class="col-md-6">
              <label for="cliente" class="form-label">Cliente</label>
              <!-- Seleccionar el nuevo cliente del equipo -->
              <select id="cliente_edit" class="form-control select2" style="width: 100%;"></select>
            </div>
            <div class="col-md-6">
              <label for="pais" class="form-label">Pais</label>
              <!--Seleccionar el nuevo pais del equipodel equipo-->
              <select id="pais_edit" class="form-control select2" style="width: 100%;"></select>
            </div>
            <div class="col-md-6">
              <label for="ciudad" class="form-label">Ciudad</label>
              <!-- Seleccionar la nueva ciudad del equipo -->
              <select id="ciudad_edit" class="form-control select2" style="width: 100%;"></select>
            </div>
            <div class="col-md-6">
              <label for="sede" class="form-label">Sede</label>
              <!-- Seleccionar la nueva sede del equipo -->
              <select id="sede_edit" class="form-control select2" style="width: 100%;"></select>
            </div>
            <div class="col-md-6">
              <label for="area" class="form-label">Area</label>
              <!-- Seleccionar la nueva area del equipo -->
              <select id="area_edit" class="form-control select2" style="width: 100%;"></select>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos editados del equipo en el inventario -->
          <button type="button" id="btn_limpiar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del equipo en el inventario-->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- CONTENIDO DEL MODULO GESTIONAR INVENTARIO EQUIPOS -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Equipos en Contrato de Arriendo y/o Matto</h1><!-- Titulo del Modulo Equipos en Contrato de Arriendo y/o Matto -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Equipos contrato arrndo y/o matto</li><!-- Este item nos indica que nos encontramos en el modulo gestionar inventario -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO INVENTARIO EQUIPOS -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar equipos</h3><!-- Titulo del buscador -->
          <div class="input-group">
            <input type="text" id="buscar_inventario" class="form-control float-left" placeholder="Ingresar el numero de inventario del equipo biomedico"><!-- Este campo es para buscar el nombre de un equipo en el inventario -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            <!-- Condicional para verificar si la url viene con algún dato o viene vacia -->
            <?php
            if (empty($_REQUEST['id'])) {
              echo '<a type="button" class="btn bg-gradient-success ml-4" href="Equipos.php" title="Click para agregar un equipo a un contrato de arriendo o matto">
                        <i class="fas fa-arrow-alt-circle-left"></i>
                      </a>';
            } else {
              echo '<button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_inventario">Agregar equipo</button>'; // Este boton es para agregar el equipo al inventario. Al dar clic se abrira el modal crear inventario  //
            }
            ?>
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de las equipos agregados al inventario en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info">
              <!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr>
                <!-- Estos son los titulos de la tabla -->
                <th>N.</th>
                <th>Equipo</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Serie</th>
                <th>Fre. Matto</th>
                <th>Cliente</th>
                <th>Ciudad</th>
                <th>Sede</th>
                <th>Area</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <!-- id = Es el identificador de la tabla inventario -->
            <tbody class="table-active" id="datos_inventario">
            </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer">
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO INVENTARIO EQUIPOS -->
<?php
// Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php';
?>
<!--/.Esta es la conexión del archivo inventario_equipos.php con el archivo gestionar_inventario.js -->
<script src="/sgme_hys/Assets/js/gestionar_inventario.js"></script>