<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php'; 
?>
<!-- Titulo de la pagina modulo gestionsedes -->
<title>SGME H&S - Modulo Sedes</title>

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL SEDE EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_sede" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear sede -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Crear sede</h3><!-- Titulo del modal crear datos de la sede -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de las sedes -->
          <form id="form-crear-sede" class="row">
            <div class="col-md-12">
              <label for="nombre_sede" class="form-label">Nombre de la sede</label>
              <!-- Caja de texto para ingresar el nombre de la sede -->
              <input type="text" class="form-control" id="nombre" placeholder="Ingrese el nombre de la sede" required>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos de la sede -->
          <button type="button" id="btn_limpiar_1" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos de la sede -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DEL SEDE -->
<div class="modal fade" id="editar_sede" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear sede -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Editar sede</h3><!-- Titulo del modal editar los datos de la sede -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de la sede -->
          <form id="form-editar-sede" class="row">
            <!-- id = Es el identificador del formulario editar sede -->
            <div class="col-md-12">
              <input type="hidden" id="id_sede">
              <label for="nombre_sede" class="form-label">Nombre de la sede</label>
              <!-- Caja de texto para ingresar el nuevo nombre de la sede -->
              <input type="text" class="form-control" id="nombre_edit" placeholder="Ingrese el nombre de la sede" required>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos de la sede -->
          <button type="button" id="btn_limpiar_2" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos de la sede -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- CONTENIDO DEL MODULO GESTIONAR SEDES -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestionar Sedes</h1><!-- Titulo del Modulo gestionar sedes -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Gestionar sedes</li><!-- Este item nos indica que nos encontramos en el modulo gestionar sedes -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIONAR SEDES -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar sede</h3><!-- Titulo del buscador -->
          <div class="input-group">
            <input type="text" id="buscar_sede" class="form-control float-left" placeholder="Ingresar el nombre de la sede"><!-- Este campo es para buscar el nombre de una sede en especifico -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            <button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_sede">Crear sede</button><!-- Este boton es para crear una sede. Al dar clic se abrira el modal crear sede -->
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de las sedes registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info">
              <!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr>
                <!-- Estos son los titulos de la tabla -->
                <th>N.</th>
                <th>Sede</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <!-- id = Es el identificador de la tabla sedes -->
            <tbody class="table-active" id="sedes">
            </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer">
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR SEDES -->
<?php
// Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php'; 
?>
<!--/.Esta es la conexión del archivo sedes.php con el archivo gestionar_sedes.js -->
<script src="/sgme_hys/Assets/js/gestionar_sede.js"></script>
