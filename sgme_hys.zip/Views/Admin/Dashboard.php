<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php';
?>

<!-- Titulo de la pagina modulo gestionar dashboard -->
<title>SGME H&S - Dashboard</title>

<!-- CONTENIDO DEL MODULO GESTIONAR DASHBOARD -->
<div class="content-wrapper" style="min-height: 568px;">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Dashboard</h1><!-- Titulo del modulo dashboard -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item"><a href="/sgme_hys/Views/Admin/Dashboard.php">Inicio</a></li>
            <!-- Este item nos indica que nos encontramos en el modulo dashboard -->
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- Contenido principal -->
  <section class="content">
    <div class="row">
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-info">
          <div class="inner">
            <h3 id="total_usuarios"></h3>
            <p>Usuarios Registrados</p>
          </div>
          <div class="icon">
            <i class="ion ion-bag"></i>
          </div>
           <!-- Link para visulizar el modulo de usuarios -->
          <a href="/sgme_hys/Views/Admin/Usuarios.php" class="small-box-footer">Mas info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-success">
          <div class="inner">
            <h3 id="total_clientes"><sup style="font-size: 20px"></sup></h3>
            <p>Clientes Registrados</p>
          </div>
          <div class="icon">
            <i class="ion ion-stats-bars"></i>
          </div>
          <!-- Link para visulizar el modulo de clientes -->
          <a href="/sgme_hys/Views/Admin/Clientes.php" class="small-box-footer">Mas info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-warning">
          <div class="inner">
            <h3 id="total_equipos"></h3>
            <p>Inventario Equipos</p>
          </div>
          <div class="icon">
            <i class="ion ion-person-add"></i>
          </div>
          <!-- Link para visulizar el modulo de equipos -->
          <a href="/sgme_hys/Views/Admin/Equipos.php" class="small-box-footer">Mas info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-danger">
          <div class="inner">
            <h3 id="total_reportes"></h3>
            <p>Reportes Servicio</p>
          </div>
          <div class="icon">
            <i class="ion ion-pie-graph"></i>
          </div>
          <!-- Link para visulizar el modulo reportes de servicio -->
          <a href="/sgme_hys/Views/Admin/Reportes.php" class="small-box-footer">Mas info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="card card-info">
          <div class="card-header">
            <div class="card-title">Mantenimientos programados pendientes</div><!-- Titulo -->
          </div>
          <div class="card-body p-0 table-responsive">
            <!-- Esta es la tabla de los datos de los mantenimientos programados que se encuentran pendientes. 
            En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
            <table class="table table-over text-nowrap">
              <thead class="table-info">
                <!-- Este es la clase de la tabla la cual define el color de la misma -->
                <tr>
                  <!-- Estos son los titulos de la tabla -->
                  <th>N.</th>
                  <th>Equipo</th>
                  <th>Serie</th>
                  <th>Actividad</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Final</th>
                  <th>Sede</th>
                  <th>Descripcíon</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <!-- id = Es el identificador de la tabla eventos -->
              <tbody class="table-active" id="listado_matto">
              </tbody>
            </table>
            <!-- Fin de la tabla -->
          </div>
          <div class="card-footer"></div>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="card card-info">
          <div class="card-header">
            <div class="card-title">Solicitudes de servicio pendientes</div><!-- Titulo -->
          </div>
          <div class="card-body p-0 table-responsive">
            <!-- Esta es la tabla de los datos de las solicitudes de servicio pendientes en la base de datos. 
            En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
            <table class="table table-over text-nowrap">
              <thead class="table-info">
                <!-- Este es la clase de la tabla la cual define el color de la misma -->
                <tr>
                  <!-- Estos son los titulos de la tabla -->
                  <th># Solicitud</th>
                  <th>Fecha</th>
                  <th>Equipo</th>
                  <th>Cliente / Empresa</th>
                  <th>Solicitado por</th>
                  <th>Tipo Solicitud</th>
                  <th>Prioridad</th>
                  <th>Motivo Servicio</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <!-- id = Es el identificador de la tabla solicitudes -->
              <tbody class="table-active" id="solicitudes">
              </tbody>
            </table>
            <!-- Fin de la tabla -->
          </div>
          <div class="card-footer"></div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
  </section>

</div>

<?php
// Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php';
?>
<!--/.Esta es la conexión del archivo dashboard.php con el archivo gestionar_dasboard.js -->
<script src="/sgme_hys/Assets/js/gestionar_dashboard.js"></script>
