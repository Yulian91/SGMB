<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php'; 
?>
<!-- Titulo de la pagina modulo gestionar solicitud -->
<title>SGME H&S - Modulo Solicitudes</title>

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL AREA EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_solicitud" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear solicitud-->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Solicitud de servicio</h3><!-- Titulo del modal crear datos de la solicitud -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de la solicitud -->
          <form id="form-crear-solicitud" class="row">
            <div class="col-md-6">
              <input type="hidden" id="id_solicitud">
              <label for="equipo_biomedico" class="form-label">Equipo</label>
              <!-- Seleccionar el nombre de un equipo -->
              <select id="equipo" class="form-control select2" style="width: 100%;"></select>
            </div>
            <div class="col-md-6">
              <label for="tipo_solicitud" class="form-label">Tipo solicitud</label>
              <!-- Seleccionar el tipo de solicitud -->
              <select id="tipo" class="form-control" aria-label="Default select example" style="width: 100%;" onchange="otro_servicio(this.value);">
                <option selected>Seleccione el tipo de solicitud</option>
                <option value="Matto Correctivo">Mantenimiento Correctivo</option>
                <option value="Instalación">Instalación</option>
                <option value="Desinstalación">Desinstalación</option>
                <option value="Diagnóstico">Diagnóstico</option>
                <option value="0">Otro</option>
              </select>
              <div id="otro_tipo_solicitud" style="display: none;">
              <!-- Caja de texto para ingresar otra solicitud -->
                <input type="text" class="form-control" id="otro_solicitud" value="NA">
              </div>
            </div>
            <div class="col-md-6">
              <label for="prioridad_solicitud" class="form-label">Prioridad</label>
              <!-- seleccionar la prioridad de la solicitud -->
              <select id="prioridad" class="form-control" aria-label="Default select example" style="width: 100%;">
                <option selected>Seleccione la prioridad de la solicitud</option>
                <option value="ALTA">Alta</option>
                <option value="NORMAL">Normal</option>
                <option value="BAJA">Baja</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="usuario" class="form-label">Solicitado por</label>
              <!-- Caja de texto para ingresar el nombre de quien solicita el mantenimiento -->
              <input type="text" class="form-control" id="usuario" placeholder="Ingrese el nombre de quien solicita el matto" required>
            </div>
            <div class="col-md-12">
              <label for="descripcion_solicitud" class="form-label">Motivo del servicio</label>
              <!-- Caja de texto para ingresarb el motivo del servicio -->
              <textarea type="text" name="motivo" class="form-control" id="motivo_solicitud" placeholder="Ingrese el motivo del servicio" rows="3" required></textarea>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos de la solicitud -->
          <button type="button" id="btn_limpiar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos de la solicitud -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DE LA SOLICITUD -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestionar Solicitudes</h1><!-- Titulo del Modulo gestionar solicitudes -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Gestionar solicitudes</li><!-- Este item nos indica que nos encontramos en el modulo gestionar solicitudes -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR SOLICITUDES -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar solicitud</h3><!-- Titulo del buscador -->
          <div class="input-group">
            <input type="text" id="buscar_solicitudes" class="form-control float-left" placeholder="Ingresar el numero de solicitud"><!-- Este campo es para buscar el nombre de una solicitud en especifico -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            <button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_solicitud">Crear solicitud</button><!-- Este boton es para crear una solicitud. Al dar clic se abrira el modal crear solicitud -->
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de las solicitudes registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info">
              <!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr>
                <!-- Estos son los titulos de la tabla -->
                <th># Solicitud</th>
                <th>Fecha</th>
                <th>Equipo</th>
                <th>Cliente / Empresa</th>
                <th>Solicitado por</th>
                <th>Tipo Solicitud</th>
                <th>Prioridad</th>
                <th>Motivo Servicio</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <!-- id = Es el identificador de la tabla solicitudes -->
            <tbody class="table-active" id="solicitudes">
            </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer">
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR SOLICITUDES -->
<?php
// Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php';
?>
<!--/.Esta es la conexión del archivo solicitud.php con el archivo gestionar_solicitudes.js -->
<script src="/sgme_hys/Assets/js/gestionar_solicitudes.js"></script>
