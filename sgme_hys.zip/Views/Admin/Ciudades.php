<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php';
?>
<!-- Titulo de la pagina modulo gestionar ciudad -->
<title>SGME H&S - Modulo Ciudades</title>

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DE LA CIUDAD EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_ciudad" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal crear ciudad -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Crear ciudad</h3><!-- Titulo del modal crear datos de la ciudad ciudad -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de la ciudad -->
          <form id="form-crear-ciudad" class="row">
            <!-- id = Es el identificador del formulario crear ciudad -->
            <div class="col-md-12">
              <!-- Titulo nombre de la ciudad -->
              <label for="nombre_ciudad" class="form-label">Nombre de la ciudad</label>
              <!-- Caja de texto para ingresar el nombre de la ciudad -->
              <input type="text" class="form-control" id="nombre" placeholder="Ingrese el nombre de la ciudad" required>
            </div>
        </div>
        <div class="card-footer">
          <!-- Boton para guardar los datos de la ciudad -->
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button>
          <!-- Boton para cancelar el ingreso de los datos de la ciudad -->
          <button type="button" id="btn_limpiar_1" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button>
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DE LA CIUDAD -->
<div class="modal fade" id="editar_ciudad" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!--  id = Es la identificación del modal editar ciudad -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Editar ciudad</h3><!-- Titulo del modal editar datos de la ciudad -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de la ciudad -->
          <form id="form-editar-ciudad" class="row">
            <!-- id = Es el identificador del formulario editar ciudad -->
            <div class="col-md-12">
              <input type="hidden" id="id_ciudad"><!-- id = Con este id se identifica el area la cual se quiere editar los datos de la ciudad -->
              <label for="nombre_ciudad" class="form-label">Nombre de la ciudad</label><!-- Titulo del nombre de la ciudad -->
              <input type="text" class="form-control" id="nombre_edit" placeholder="Ingrese el nombre de la ciudad" required><!-- Caja de texto para ingresar el nuevo nombre de la ciudad -->
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los nuevos datos de la ciudad -->
          <button type="button" id="btn_limpiar_2" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el nuevo ingreso de los datos de la ciudad -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- CONTENIDO DEL MODULO GESTIONAR CIUDADES -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestionar Ciudades</h1><!-- Titulo del Modulo gestionar ciuades -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Gestionar ciudades</li><!-- Este item nos indica que nos encontramos en el modulo gestionar ciudades -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR CIUDADES -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar ciudad</h3><!-- Titulo del buscador -->
          <div class="input-group">
            <input type="text" id="buscar_ciudad" class="form-control float-left" placeholder="Ingresar el nombre de la ciudad"><!-- Este campo es para buscar el nombre de una ciudad en especifico -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            <button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_ciudad">Crear ciudad</button><!-- Este boton es para crear una nueva ciudad. Al dar clic se abrira el modal crear ciudad -->
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de las ciudades registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info">
              <!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr>
                <!-- Estos son los titulos de la tabla -->
                <th>N.</th>
                <th>Ciudad</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <!-- id = Es el identificador de la tabla ciudades -->
            <tbody class="table-active" id="ciudades">
            </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer">
        </div>
      </div>
    </div>
    <!-- /.FIN CONTENIDO DE LA TABLA -->
  </section>
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR CIUDADES -->
<?php
// Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php';
?>
<!--/.Esta es la conexión del archivo ciudades.php con el archivo gestionar_ciudades.js -->
<script src="/sgme_hys/Assets/js/gestionar_ciudades.js"></script>
