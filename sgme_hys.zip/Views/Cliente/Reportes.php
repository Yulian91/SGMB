<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php'; 
?>
<!-- Titulo de la pagina modulo de reportes -->
<title>SGME H&S - Modulo Reportes</title>

<!-- CONTENIDO DEL MODULO GESTIONAR REPORTES -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestionar Reportes</h1><!-- Titulo del Modulo gestionar reportes -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="/sgme_hys/Views/Cliente/Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Gestionar reportes</li><!-- Este item nos indica que nos encontramos en el modulo gestionar reportes -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR AREAS -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar reportes</h3>
          <div class="input-group">
            <input type="text" id="buscar_reporte" class="form-control float-left" placeholder="Ingresar el numero del reporte de servicio"><!-- Este campo es para buscar el nombre de un reporte en especifico -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de los reportes registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info">
              <!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr>
                <!-- Estos son los titulos de la tabla -->
                <th>No. Reporte</th>
                <th>Tipo Asistencia</th>
                <th>Fecha Inicio</th>
                <th>Fecha Final</th>
                <th>Equipo</th>
                <th>Serie</th>
                <th>Sede</th>
                <th>Area</th>
                <th>Tipo Servicio</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <!-- id = Es el identificador de la tabla reportes -->
            <tbody class="table-active" id="reportes">
            </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer">
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR REPORTES -->
<?php
 // Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php';
?>
<!--/.Esta es la conexión del archivo reportes.php con el archivo gestionar_reportes.js -->
<script src="/sgme_hys/Assets/js/gestionar_reportes.js"></script>
