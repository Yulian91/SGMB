<?php
// Codigo para activar la sesión en curso //
session_start();
// Esta es la conexión con el archivo header.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php';
?>
<!-- Titulo de la pagina modulo gestionar datos personales -->
<title>SGME H&S - Datos Personales</title>


<!-- MODAL CON EL FORMULARIO PARA CAMBIAR LA CONTRASEÑA DEL USUARIO EN LA BASE DE DATOS -->
<div class="modal fade" id="cambio_clave" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <!-- id = Es la identificación del modal cambiar contraseña -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Cambio de Contraseña</h3><!-- Titulo del modal cambiar contraseña -->
          <button data-dismiss="modal" aria-label="Close" class="close">
            <!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <div class="text-center">
            <!-- Ruta de la imagen del avatar del usuario -->
            <img src="/sgme_hys/Assets/Util/img/avatar_1.png" class="profile-user-img img-fluid img-circle">
          </div>
          <br>
          <div class="text-center">
            <!-- El nombre y apellido del usuario que se encuentra en la sesión -->
            <b> <?php echo $_SESSION['nombre']; ?> </b><br />
            <b> <?php echo $_SESSION['apellido']; ?> </b>
          </div>
          <br>
          <!-- Formulario para cambiar la contraseña del usuario -->
          <form id="form-clave" class="row">
            <!-- id = Es el identificador del formulario cambiar clave -->
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-unlock-alt"></i></span>
              </div>
              <!-- Caja de texto para ingresar la contraseña anterior del usuario -->
              <input id="clave_anterior" type="password" class="form-control" placeholder="Ingrese la contraseña actual" required>
              <div class="input-group-append">
                <!-- Boton para mostrar la contraseña al usuario -->
                <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword1()"> <span class="fa fa-eye-slash icon"></span> </button>
              </div>
            </div>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-lock"></i></span>
              </div>
              <!-- Caja de texto para ingresar la nueva contraseña del usuario -->
              <input id="nueva_clave" type="password" class="form-control" placeholder="Ingrese la nueva contraseña" required>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar el cambio de la contraseña -->
          <button type="button" id="btn_limpiar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de la nueva contraseña -->
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- CONTENIDO DEL MODULO GESTIONAR DATOS PERSONALES -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Datos Personales</h1><!-- Titulo del Modulo gestionar datos personales -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Datos personales</li><!-- Este item nos indica que nos encontramos en el modulo gestionar datos personales -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR DATOS PERSONALES -->
  <section>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-5">
            <div class="card card-info card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <!-- Ruta de la imagen del avatar del usuario -->
                  <img src="/sgme_hys/Assets/Util/img/avatar_1.png" class="profile-user-img img-fluid img-circle">
                </div>
                <!-- id = Es el identificador del usuario al cual se modificara los datos personales -->
                <input id="id_usuario" type="hidden" value="<?php echo $_SESSION['id'] ?>">
                <!-- Proyecta el id del usuario que se encuentra en sesión -->
                <h3 id="nombre" class="profile-username text-center"></h3>
                <!--  -->
                <p id="apellidos" class="profile-username text-center"></p>
                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <i class="fas fa-address-card mr-1">Identificación</i>
                    <!-- Proyecta el numero de identificación del usuario que se encuentra en sesión -->
                    <a id="identificacion" class="float-right text-dark"></a>
                  </li>
                  <li class="list-group-item">
                    <i class="fas fa-user mr-1">Tipo Usuario</i>
                    <!-- Proyecta el tipo de usuario que se encuentra en sesión -->
                    <a id="tipo_usu" class="float-right badge badge-primary"></a>
                  </li>
                  <li class="list-group-item">
                    <i class="fas fa-at mr-1">E-mail</i>
                    <!-- Proyecta el correo electronico del usuario que se encuentra en sesión -->
                    <a id="email" class="float-right text-dark"></a>
                  </li>
                  <li class="list-group-item">
                    <i class="fas fa-mobile mr-1">Telefono</i>
                    <!-- Proyecta el telefono del usuario que se encuentra en sesión -->
                    <a id="telefono" class="float-right text-dark"></a>
                  </li>
                  <li class="list-group-item">
                    <i class="fas fa-map-marker-alt mr-1">Dirección</i>
                    <!-- Proyecta la dirección del usuario que se encuentra en sesión -->
                    <a id="direccion" class="float-right text-dark"></a>
                  </li>
                </ul>
                <div class="row">
                  <div class="col-md-6">
                    <!-- Boton para editar los datos personales del usuario que se encuentra en sesión -->
                    <button class="edit btn btn-block bg-gradient-success">Editar datos</button>
                  </div>
                  <div class="col-md-6">
                    <!-- Boton para cambiar la contraseña del usuario que se encuentra en sesión-->
                    <button type="button" class="btn btn-block bg-gradient-warning" data-toggle="modal" data-target="#cambio_clave">Cambiar contraseña</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- FORMULARIO PARA EDITAR LOS DATOS PERSONALES DEL USUARIO -->
          <div class="col-md-7">
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Editar datos personales</h3>
              </div>
              <div class="card-footer">
                <!-- Formulario para ingresar los datos personales del usuario que se encuentra en sesión -->
                <form id="form-usuario" class="form-horizontal">
                  <!-- id = Es el identificador del formulario editar datos personales -->
                  <div class="form-group row">
                    <label for="nombre" class="col-sm-2 col-form-label">Nombre</label>
                    <div class="col-sm-10">
                      <!-- Caja de texto para ingresar el nuevo nombre usuario -->
                      <input type="text" id="nombre_usu" class="form-control">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="apellidos" class="col-sm-2 col-form-label">Apellidos</label>
                    <div class="col-sm-10">
                      <!-- Caja de texto para ingresar el nuevo apellido del usuario -->
                      <input type="text" id="apellidos_usu" class="form-control">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="identificacion" class="col-sm-2 col-form-label">Identificación</label>
                    <div class="col-sm-10">
                      <!-- Caja de texto para ingresar el nuevo numero de identificación del usuario -->
                      <input type="text" id="identificacion_usu" class="form-control">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="email" class="col-sm-2 col-form-label">Correo</label>
                    <div class="col-sm-10">
                      <!-- Caja de texto para ingresar el nuevo correo electronico del usuario -->
                      <input type="text" id="email_usu" class="form-control">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="contacto" class="col-sm-2 col-form-label">Telefono</label>
                    <div class="col-sm-10">
                      <!-- Caja de texto para ingresar el nuevo telefono del usuario -->
                      <input type="text" id="contacto_usu" class="form-control">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="direccion" class="col-sm-2 col-form-label">Dirección</label>
                    <div class="col-sm-10">
                      <!-- Caja de texto para ingresar la nueva dirección del usuario -->
                      <input type="text" id="direccion_usu" class="form-control">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="offset-sm-2 col-sm-10 float-right">
                      <button class="btn btn-block btn-outline-success">Guardar</button><!-- Boton para guardar los datos personales del usuario-->
                    </div>
                  </div>
                </form>
                <!-- Fin del formulario -->
              </div>
            </div>
          </div>
          <!-- FIN CODIGO FORMULARIO -->
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR DATOS PERSONALES -->
<?php
// Esta es la conexión con el archivo footer.php //
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php'; 
?>
<!--/.Esta es la conexión del archivo datos_personales.php con el archivo usuario.js -->
<script src="/sgme_hys/Assets/js/usuario.js"></script>