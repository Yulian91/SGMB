<?php
// Codigo para activar la sesión en curso //
session_start();
// Ruta para acceder al modelo del reporte.
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/reporte.php';
$reporte = new  Reporte();

/* Función crear reporte, esta función recibe los datos post enviados desde el formulario crear reporte del archivo gestionar_reporte.js */
if ($_POST['funcion'] == 'crear_reporte') {
  $inventario = $_POST['inventario'];
  $tipo_servicio = $_POST['tipo_servicio'];
  $otro_servicio = $_POST['otro_servicio'];
  $tipo_asistencia = $_POST['tipo_asistencia'];
  $fecha_inicio = $_POST['fecha_inicio'];
  $hora_inicio = $_POST['hora_inicio'];
  $fecha_final = $_POST['fecha_final'];
  $hora_final = $_POST['hora_final'];
  $protocolos = $_POST['protocolos'];
  $problemas_report = $_POST['problemas_report'];
  $otro_problema = $_POST['otro_problema'];
  $motivo_servicio = $_POST['motivo_servicio'];
  $estado_equipo = $_POST['estado_equipo'];
  $actividades = $_POST['actividades'];
  $observaciones = $_POST['observaciones'];
  $repto_utilizados = $_POST['repto_utilizados'];
  $descrip_utilizados = $_POST['descrip_utilizados'];
  $repto_cotizar = $_POST['repto_cotizar'];
  $descrip_cotizar = $_POST['descrip_cotizar'];
  $tecnico = $_POST['tecnico'];
  $reporte->crear_reporte($inventario,$tipo_servicio,$otro_servicio,$tipo_asistencia,$fecha_inicio,$hora_inicio,$fecha_final,
  $hora_final,$protocolos,$problemas_report,$otro_problema,$motivo_servicio,$estado_equipo,$actividades,$observaciones,
  $repto_utilizados,$descrip_utilizados,$repto_cotizar,$descrip_cotizar,$tecnico);
}
/* Fin Función crear reporte */
else
/* Función para buscar los datos del reporte, esta función realiza la consulta a la base de datos y trae los datos del reporte. */
if ($_POST['funcion'] == 'buscar_datos_reporte') {
  $json = array();
  $reporte->buscar_reportes();
  foreach ($reporte->objetos as $objeto) {
    $json[] = array(
      'id_reporte' => $objeto->id_reporte,
      'id_inventario' => $objeto->inventario,
      'cliente' => $objeto->cliente,
      'equipo' => $objeto->nombre_equipo,
      'no_activo' => $objeto->no_activo,
      'marca' => $objeto->marca,
      'modelo' => $objeto->modelo,
      'serie' => $objeto->serie,
      'sede' => $objeto->nombre_sede,
      'area' => $objeto->nombre_area,
      'fijo_movil' => $objeto->fijo_movil,
      'tipo_servicio' => $objeto->tipo_servicio,
      'fecha_inicio' => $objeto->fecha_inicio,
      'hora_inicio' => $objeto->hora_inicio,
      'fecha_final' => $objeto->fecha_final,
      'hora_final' => $objeto->hora_final,
      'protocolos' => $objeto->protocolo_matto,
      'motivo_servicio' => $objeto->motivo_servicio,
      'tipo_asistencia' => $objeto->nombre_asistencia,
      'problemas' => $objeto->nombre_problema_report,
      'otro_problema' => $objeto->otro_problema,
      'actividades' => $objeto->actividad_realizada,
      'observaciones' => $objeto->observa_general,
      'repto_utilizados' => $objeto->cant_repto_utilizados,
      'repto_cotizar' => $objeto->cant_repto_cotizar,
      'descrip_utilizados' => $objeto->descrip_repto_utilizados,
      'descrip_cotizar' => $objeto->descrip_repto_cotizar,
      'estado' => $objeto->estatus_reporte,
      'id_tipo_sesion' => $_SESSION['id_tipo']
    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
  $jsonstring = json_encode($json);
  echo $jsonstring;
  // FIN CODIGO
}
/* Fin Función buscar datos del reporte */
else
/* Función para seleccionar el equipo, trae dos parametros y los proyecta en el formulario del cronograma */
if ($_POST['funcion'] == 'select_equipo') {
  $equipo->select_equipo();
  foreach ($equipo->objetos as $objeto) {
    $json[] = array(
      'id' => $objeto->id_equipo,
      'nombre' => $objeto->nombre_equipo,
      'marca' => $objeto->marca,
      'modelo' => $objeto->modelo
    );
  }
  $jsonstring = json_encode($json);
  echo $jsonstring;
}
/* Fin Función seleccionar equipo */
else
/* Función para finalizar el reporte, esta función recibe el id del reporte enviado desde el evento estado_finalizado del archivo gestionar_reporte.js */
if ($_POST['funcion'] == 'estado_finalizado') {
  $id_reporte = $_POST['id_reporte'];
  $reporte->estado_finalizado($id_reporte);
}
else
/* Función eliminar datos del reporte, esta función recibe el id del reporte enviado desde el evento eliminar del archivo gestionar_reporte.js . */
if ($_POST['funcion'] == 'eliminar') {
  $id = $_POST['id'];
  $reporte->eliminar($id);
}
/* Fin Función eliminar */
else
/* Función para contar el total de clientes, proyecta el total de los clientes en el dashboard */
if ($_POST['funcion'] == 'total_reportes') {
  $json = array();
  $reporte->total_reportes();
  foreach ($reporte->objetos as $objeto) {
    $json[] = array(
      'total_reportes' => $objeto->total_registro,
    );
  }
  $jsonstring = json_encode($json[0]);
  echo $jsonstring;
}
/* Fin Función total clientes */
