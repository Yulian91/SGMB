<?php
// Codigo para activar la sesión en curso //
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/ciudad.php'; // Ruta para acceder al modelo de la ciudad.
$ciudad = new  Ciudad();

/* Función crear ciudad, esta función recibe los datos post enviados desde el formulario crear ciudad del archivo
    gestionar_ciudad.js . */
if ($_POST['funcion']=='crear_ciudad') {
    $nombre = $_POST['nombre'];
    $ciudad->Crear_Ciudad($nombre);
}
/* Fin Función crear ciudad */
else

/* Función editar ciudad, esta función recibe los datos post enviados desde el formulario editar ciudad del archivo
    gestionar_ciudad.js . */
if ($_POST['funcion']=='editar_ciudad') {
    $id_ciudad = $_POST['id_ciudad'];
    $nombre = $_POST['nombre'];
    $ciudad->editar_ciudad($id_ciudad,$nombre);
    
}
/* Fin Función editar ciudad */
else

/* Función para buscar los datos de la ciudad, esta función realiza la consulta a la base de datos y trae los datos de la ciudad. */
if ($_POST['funcion']=='buscar_datos_ciudad') {
    $json=array();
    $ciudad->buscador_ciudades();
    foreach ($ciudad->objetos as $objeto) {
        $json[]=array(
            'id_ciudad'=>$objeto->id_ciudad,
            'nombre'=>$objeto->nombre_ciudad,
            'estatus'=>$objeto->estatus_ciudad
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}
else

/* Función inhabilitar los datos de la ciudad, esta función recibe el id de la ciudad enviado desde el evento inhabilitar del archivo
    gestionar_ciudad.js */
if ($_POST['funcion']=='inhabilitar') {
    $id = $_POST['id'];
    $ciudad->inhabilitar($id);
}
/* Fin Función inhabilitar */
else

/* Función habilitar los datos de la ciudad, esta función recibe el id de la ciudad enviado desde el evento habilitar del archivo
    gestionar_ciudad.js */
if ($_POST['funcion']=='habilitar') {
    $id = $_POST['id'];
    $ciudad->habilitar($id);
}
/* Fin Función habilitar */
else

/* Función eliminar datos de la ciudad, esta función recibe el id de la ciudad enviado desde el evento eliminar del archivo gestionar_ciudad.js . */
if ($_POST['funcion']=='eliminar') {
    $id = $_POST['id'];
    $ciudad->eliminar($id);
}
/* Fin Función eliminar */
else

/* Función para seleccionar la ciudad, trae dos parametros y los proyecta en el formulario de agregar un equipo a un contrato de matto */
if ($_POST['funcion']=='select_ciudad') {
    $ciudad->select_ciudad();
    $json = array();
    foreach ($ciudad->objetos as $objeto) {
        $json[]=array(
            'id_ciudad'=>$objeto->id_ciudad,
            'nombre_ciudad'=>$objeto->nombre_ciudad
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
/* Fin Función seleccionar area */
