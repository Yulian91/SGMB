<?php
// Codigo para activar la sesión en curso //
session_start();
// Ruta para acceder al modelo del Area.
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/area.php'; 
$area = new  Area();

/* Función crear área, esta función recibe los datos post enviados desde el formulario crear area del archivo
    gestionar_area.js . */
if ($_POST['funcion']=='crear_area') {
    $nombre = $_POST['nombre'];
    $area->Crear_Area($nombre);
}
/* Fin Función crear area */
else
/* Función ediar área, esta función recibe los datos post enviados desde el formulario editar area del archivo
    gestionar_area.js . */
if ($_POST['funcion']=='editar_area') {
    $id_area = $_POST['id_area'];
    $nombre = $_POST['nombre'];
    $area->editar_area($id_area,$nombre);
    
}
/* Fin Función crear area */
else
/* Función buscar datos del área, esta función realiza la consulta a la base de datos y trae los datos del area. */
if ($_POST['funcion']=='buscar_datos_area') {
    $json=array();
    $area->buscador_areas();
    foreach ($area->objetos as $objeto) {
        $json[]=array(
            'id_area'=>$objeto->id_area,
            'nombre'=>$objeto->nombre_area,
            'estatus'=>$objeto->estatus_area
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}
/* Fin Función buscar datos del area*/
else
/* Función inhabilitar datos del área, esta función recibe el id del area enviado desde el evento inhabilitar del archivo
    gestionar_area.js */
if ($_POST['funcion']=='inhabilitar') {
    $id = $_POST['id'];
    $area->inhabilitar($id);
}
/* Fin Función inhabilitar */
else
/* Función habilitar datos del área, esta función recibe el id del area enviado desde el evento Habilitar del archivo
    gestionar_area.js . */
if ($_POST['funcion']=='habilitar') {
    $id = $_POST['id'];
    $area->habilitar($id);
}
/* Fin Función habilitar */
else
/* Función eliminar datos del área, esta función recibe el id del area enviado desde el evento eliminar del archivo
    gestionar_area.js . */
if ($_POST['funcion']=='eliminar') {
    $id = $_POST['id'];
    $area->eliminar($id);
}
/* Fin Función eliminar */
else
/* Función para seleccionar el area, trae dos parametros y los proyecta en el formulario de agregar un equipo a un contrato de matto */
if ($_POST['funcion']=='select_area') {
    $area->select_area();
    $json = array();
    foreach ($area->objetos as $objeto) {
        $json[]=array(
            'id_area'=>$objeto->id_area,
            'nombre_area'=>$objeto->nombre_area
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
/* Fin Función seleccionar area */

?>