<?php
// Codigo para activar la sesión en curso //
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/det_reporte.php';  // Ruta para acceder al modelo del det_reporte.
$det_reporte = new  Det_Reporte();

/* Función firmar reporte, esta función recibe los datos post enviados desde el formulario firmar reporte del archivo gestionar_reporte.js */
if ($_POST['funcion'] == 'firma_reporte') {
  $id_reporte = $_POST['no_reporte'];
  $nombre_cliente = $_POST['nombre_cliente'];
  $ident_cliente = $_POST['ident_cliente'];
  $equipo_oprtvo = $_POST['equipo_operativo'];
  if (($_FILES['img_firma']['type'] == 'image/jpeg') || ($_FILES['img_firma']['type'] == 'image/png') || ($_FILES['img_evidencia1']['type'] == 'image/jpeg') || ($_FILES['img_evidencia1']['type'] == 'image/png' || ($_FILES['img_evidencia2']['type'] == 'image/jpeg') || ($_FILES['img_evidencia2']['type'] == 'image/png') || ($_FILES['img_evidencia3']['type'] == 'image/jpeg') || ($_FILES['img_evidencia3']['type'] == 'image/png'))) {
    $name_firma_cli = uniqid() . '-' . $_FILES['img_firma']['name'];
    $name_img_evidencia1 = uniqid() . '-' . $_FILES['img_evidencia1']['name'];
    $name_img_evidencia2 = uniqid() . '-' . $_FILES['img_evidencia2']['name'];
    $name_img_evidencia3 = uniqid() . '-' . $_FILES['img_evidencia3']['name'];
    $ruta_1 = '../Assets/img/firmas/' . $name_firma_cli;
    $ruta_2 = '../Assets/img/evidencias/' . $name_img_evidencia1;
    $ruta_3 = '../Assets/img/evidencias/' . $name_img_evidencia2;
    $ruta_4 = '../Assets/img/evidencias/' . $name_img_evidencia3;
    move_uploaded_file($_FILES['img_firma']['tmp_name'], $ruta_1);
    move_uploaded_file($_FILES['img_evidencia1']['tmp_name'], $ruta_2);
    move_uploaded_file($_FILES['img_evidencia2']['tmp_name'], $ruta_3);
    move_uploaded_file($_FILES['img_evidencia3']['tmp_name'], $ruta_4);
    $det_reporte->firma_reporte($id_reporte, $nombre_cliente, $ident_cliente, $name_firma_cli, $equipo_oprtvo, $name_img_evidencia1, $name_img_evidencia2, $name_img_evidencia3);
    $json = array();
    $json[] = array(
      'id' => $id_reporte,
      'ruta' => $ruta_1, $ruta_2, $ruta_3, $ruta_4,
      'alert' => 'edit'
    );
    $jsonstring = json_encode($json[0]);
    echo $jsonstring;
  } else {
    $json = array();
    $json[] = array(
      'alert' => 'noedit'
    );
    $jsonstring = json_encode($json[0]);
    echo $jsonstring;
  }
}
/* Fin Función  */