    <?php
    session_start(); // Sesión iniciada.
    session_destroy(); // destroy de la sesión en curso y salir del sistema.
    header('Location: ../index.php'); // Ruta del index.php
    ?>