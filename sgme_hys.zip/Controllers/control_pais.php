<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/paises.php'; // Ruta para acceder al modelo del pais.
$paises = new  Paises();

/* Función crear pais, esta función recibe los datos post enviados desde el formulario crear pais del archivo gestionar_paises.js */
if ($_POST['funcion']=='crear_pais') {
    $nombre = $_POST['nombre'];
    $paises->crear_pais($nombre);
}
/* Fin Función crear pais */
else
/* Función editar pais, esta función recibe los datos post enviados desde el formulario editar pais del archivo gestionar_paises.js */
if ($_POST['funcion']=='editar_pais') {
    $id_pais = $_POST['id_pais'];
    $nombre = $_POST['nombre'];
    $paises->editar_pais($id_pais,$nombre);
}
/* Fin Función editar pais */
else
/* Función para buscar los datos del pais, esta función realiza la consulta a la base de datos y trae los datos del pais. */
if ($_POST['funcion']=='buscar_datos_paises') {
    $json=array();
    $paises->buscar_pais();
    foreach ($paises->objetos as $objeto) {
        $json[]=array(
            'id_pais'=>$objeto->id_pais,
            'nombre'=>$objeto->nombre_pais,
            'estatus'=>$objeto->estatus_pais
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}
/* Fin Función buscar datos del pais*/
else
/* Función inhabilitar datos del pais, esta función recibe el id del pais enviado desde el evento inhabilitar del archivo gestionar_paises.js */
if ($_POST['funcion']=='inhabilitar') {
    $id = $_POST['id'];
    $paises->inhabilitar($id);
}
/* Fin Función inhabilitar */
else
/* Función habilitar datos del pais, esta función recibe el id del pais enviado desde el evento Habilitar del archivo gestionar_paises.js . */
if ($_POST['funcion']=='habilitar') {
    $id = $_POST['id'];
    $paises->habilitar($id);
}
/* Fin Función habilitar */
else
/* Función eliminar datos del pais, esta función recibe el id del pais enviado desde el evento eliminar del archivo gestionar_paises.js . */
if ($_POST['funcion']=='eliminar') {
    $id = $_POST['id'];
    $paises->eliminar_pais($id);
}
/* Fin Función eliminar */
else
/* Función para seleccionar el pais, trae dos parametros y los proyecta en el formulario agregar un equipo a un contrato de matto */
if ($_POST['funcion']=='select_pais') {
    $paises->select_pais();
    $json = array();
    foreach ($paises->objetos as $objeto) {
        $json[]=array(
            'id_pais'=>$objeto->id_pais,
            'nombre_pais'=>$objeto->nombre_pais
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
/* Fin Función seleccionar pais */

?>