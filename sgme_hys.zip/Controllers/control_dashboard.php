<?php
// Codigo para activar la sesión en curso //
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/dashboard.php'; // Ruta para acceder al modelo del dashboard.
$dashboard = new  Dashboard();

/* Función para buscar los datos del usuario, esta función realiza la consulta a la base de datos y trae los datos del usuario, los proyecta en el dashboard. */
if ($_POST['funcion']=='datos') {
    $dashboard->datos('usuario');
    $json = array();
    foreach ($dashboard->objetos as $objeto) {
        $json[]=array(
            'usuario'=>$objeto->usuario,
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
/* Fin Función buscar datos del usuario */