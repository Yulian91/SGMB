<?php
// Codigo para activar la sesión en curso //
session_start();
// Ruta para acceder al modelo del cronograma.
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/cronograma.php'; 
$cronograma = new  Cronograma();

/* Función crear evento, esta función recibe los datos post enviados desde el formulario crear cronograma del archivo gestionar_cronograma.js */
if ($_POST['funcion'] == 'crear_evento') {
  $inventario = $_POST['inventario'];
  $titulo = $_POST['titulo'];
  $fecha_inicio = $_POST['fecha_inicio'];
  //$hora_inicio = $_POST['hora_inicio'];
  $fecha_final = $_POST['fecha_final'];
  //$hora_final = $_POST['hora_final'];
  $descripcion = $_POST['descripcion'];
  $cronograma->crear_cronograma($inventario, $titulo, $fecha_inicio, $fecha_final, $descripcion);
}
/* Fin Función crear evento */
else
/* Función editar evento, esta función recibe los datos post enviados desde el formulario editar cronograma del archivo gestionar_cronograma.js */
if ($_POST['funcion'] == 'editar_evento') {
  $id_cronograma = $_POST['id_cronograma'];
  $inventario = $_POST['inventario'];
  $titulo = $_POST['titulo'];
  $fecha_inicio = $_POST['fecha_inicio'];
  //$hora_inicio = $_POST['hora_inicio'];
  $fecha_final = $_POST['fecha_final'];
  //$hora_final = $_POST['hora_final'];
  $descripcion = $_POST['descripcion'];
  $cronograma->editar_cronograma($id_cronograma, $inventario, $titulo, $fecha_inicio, $fecha_final, $descripcion);
}
/* Fin Función editar evento */
else
/* Función para buscar los datos del evento, esta función realiza la consulta a la base de datos y trae los datos del evento. */
if ($_POST['funcion'] == 'buscar_datos_evento') {
  $json = array();
  $cronograma->buscar_eventos();
  foreach ($cronograma->objetos as $objeto) {
    $json[] = array(
      'id_cronograma' => $objeto->id,
      'id_inventario' => $objeto->inventario,
      'id_equipo' => $objeto->equipo,
      'nombre_eq' => $objeto->nombre,
      'marca_eq' => $objeto->marca,
      'modelo_eq' => $objeto->modelo,
      'serie_eq' => $objeto->serie,
      'sede' => $objeto->nombre_sede,
      'area' => $objeto->nombre_area,
      'titulo' => $objeto->titulo,
      'f_inicio' => $objeto->fecha_inicio,
      'f_final' => $objeto->fecha_final,
      'color' => $objeto->color,
      'descripcion' => $objeto->descripcion,
      'estado' => $objeto->estatus

    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
  $jsonstring = json_encode($json, JSON_UNESCAPED_UNICODE);
  echo $jsonstring;
  // FIN CODIGO
}
else
/* Función para buscar los datos del evento, esta función realiza la consulta a la base de datos y trae los datos del evento. */
if ($_POST['funcion'] == 'eventos') {
  $json = array();
  $cronograma->eventos();
  foreach ($cronograma->objetos as $objeto) {
    $json[] = array(
      'id' => $objeto->id,
      //'inventory'=>$objeto->inventory,
      //'id_equipo'=>$objeto->equipo,
      //'nombre_eq'=>$objeto->nombre,
      //'serie_eq'=>$objeto->serie,
      'title' => $objeto->title,
      'start' => $objeto->start,
      //'h_inicio'=>$objeto->hora_inicio,
      'end' => $objeto->end,
      //'h_final'=>$objeto->hora_final,
      'color' => $objeto->color,
      //'description'=>$objeto->description,
      //'estatus'=>$objeto->estatus

    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
  $jsonstring = json_encode($json, JSON_UNESCAPED_UNICODE);
  echo $jsonstring;
  // FIN CODIGO
}
/* Fin Función eventos */
else
/* Función para buscar los datos del evento pendientes, esta función realiza la consulta a la base de datos y trae los datos de los eventos que se encuentran pendientes */
if ($_POST['funcion'] == 'buscar_datos_pendiente') {
  $json = array();
  $cronograma->buscar_eventos_pendiente();
  foreach ($cronograma->objetos as $objeto) {
    $json[] = array(
      'id_cronograma' => $objeto->id,
      'id_inventario' => $objeto->inventario,
      'id_equipo' => $objeto->equipo,
      'nombre_eq' => $objeto->nombre,
      'marca_eq' => $objeto->marca,
      'modelo_eq' => $objeto->modelo,
      'serie_eq' => $objeto->serie,
      'sede' => $objeto->nombre_sede,
      'area' => $objeto->nombre_area,
      'titulo' => $objeto->titulo,
      'f_inicio' => $objeto->fecha_inicio,
      'f_final' => $objeto->fecha_final,
      'color' => $objeto->color,
      'descripcion' => $objeto->descripcion,
      'estado' => $objeto->estatus,
      'id_tipo_sesion' => $_SESSION['id_tipo']


    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
  $jsonstring = json_encode($json, JSON_UNESCAPED_UNICODE);
  echo $jsonstring;
  // FIN CODIGO
}
/* Fin Función habilitar */
else
/* Función para cambiar el estado, esta función recibe el id del evento enviado desde el evento estado_proceso del archivo gestionar_cronograma.js */
if ($_POST['funcion'] == 'estado_proceso') {
  $id = $_POST['id'];
  $cronograma->estado_proceso($id);
}
/* Fin Función estado */
else
/* Función para reactivar el evento, esta función recibe el id del evento enviado desde el evento estado_reactivar del archivo gestionar_cronograma.js */
if ($_POST['funcion'] == 'estado_reactivar') {
  $id = $_POST['id'];
  $cronograma->estado_reactivar($id);
}
/* Fin Función reactivar evento */
else
/* Función para cancelar el evento, esta función recibe el id del evento enviado desde el evento estado_proceso del archivo gestionar_cronograma.js */
if ($_POST['funcion'] == 'cancelar_evento') {
  $id = $_POST['id'];
  $cronograma->estado_cancelar($id);
}
/* Fin Función cancelar evento */
else
/* Función para cerrar el evento, esta función recibe el id del evento enviado desde el evento estado_cerrado del archivo gestionar_cronograma.js */
if ($_POST['funcion'] == 'estado_cerrado') {
  $id = $_POST['id'];
  $cronograma->estado_cerrado($id);
}
/* Fin Función cerrar evento */
else
/* Función eliminar datos del evento, esta función recibe el id del evento enviado desde el evento eliminar del archivo gestionar_cronograma.js */
if ($_POST['funcion'] == 'eliminar') {
  $id = $_POST['id'];
  $cronograma->eliminar($id);
}
/* Fin Función eliminar */
