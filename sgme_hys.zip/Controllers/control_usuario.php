<?php
// Codigo para activar la sesión en curso //
session_start();
// Ruta para acceder al modelo del usuario.
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/usuario.php'; 
$usuario = new  Usuario();

/* Funcion para loguearse */
if ($_POST['funcion'] == 'login') {
  $ident = $_POST['ident'];
  $pass = $_POST['pass'];
  $usuario->Login($ident);
  $msg = '';
  if (!empty($usuario->objetos)) {
    $contrasena = $usuario->objetos[0]->contrasena;
    if ($pass == $contrasena) {
      $_SESSION['id'] = $usuario->objetos[0]->id;
      $_SESSION['nombre'] = $usuario->objetos[0]->nombre;
      $_SESSION['apellido'] = $usuario->objetos[0]->apellido;
      $_SESSION['correo'] = $usuario->objetos[0]->correo;
      $_SESSION['ident'] = $usuario->objetos[0]->ident;
      $_SESSION['telefono'] = $usuario->objetos[0]->telefono;
      $_SESSION['direccion'] = $usuario->objetos[0]->direccion;
      $_SESSION['id_tipo'] = $usuario->objetos[0]->id_tipo;
      $_SESSION['tipo_usuario'] = $usuario->objetos[0]->tipo_usuario;
      $msg = 'success';
    } else {
      $msg = 'error';
    }
  } else {
    $msg = 'error';
  }
  $json = array(
    'msg' => $msg
  );
  $jsonstring = json_encode($json);
  echo $jsonstring;
}
// fin Funcion loguearse.
else
/* Funcion para verificar la sesión entrante */
if ($_POST['funcion'] == 'verificar_session') {
  if (!empty($_SESSION['id'])) {
    $json = array(
      'id'=>$_SESSION['id'],
      'nombre'=>$_SESSION['nombre'],
      'apellido'=>$_SESSION['apellido'],
      'correo'=>$_SESSION['correo'],
      'ident'=>$_SESSION['ident'],
      'telefono'=>$_SESSION['telefono'],
      'direccion'=>$_SESSION['direccion'],
      'id_tipo'=>$_SESSION['id_tipo'],
      'tipo_usuario'=>$_SESSION['tipo_usuario'],
    );
  } else {
    $json = array();
  }
  $jsonstring = json_encode($json);
  echo $jsonstring;
}
/* Fin Función verificar sesión */
else
/* Función crear usuario, esta función recibe los datos post enviados desde el formulario crear usuario del archivo gestionar_usuario.js */
if ($_POST['funcion'] == 'crear_usuario') {
  $nombre = $_POST['nombre'];
  $apellido = $_POST['apellido'];
  $email = $_POST['email'];
  $identificacion = $_POST['identificacion'];
  $contacto = $_POST['contacto'];
  $direccion = $_POST['direccion'];
  $contrasena = $_POST['contrasena'];
  $tipo = $_POST['tipo'];
  $usuario->Crear_Usuario($nombre, $apellido, $email, $identificacion, $contacto, $direccion, $contrasena, $tipo);
}
/* Fin Función crear usuario */
else
/* Función editar los datos personales del usuario, esta función recibe los datos post enviados desde el formulario editar usuario del archivo usuario.js */
if ($_POST['funcion'] == 'editar_datos') {
  $id_usuario = $_POST['id_usuario'];
  $nombre = $_POST['nombre'];
  $apellidos = $_POST['apellidos'];
  $identificacion = $_POST['identificacion'];
  $email = $_POST['email'];
  $contacto = $_POST['contacto'];
  $direccion = $_POST['direccion'];
  $usuario->editar_datos($id_usuario, $nombre, $apellidos, $identificacion, $email, $contacto, $direccion);
}
/* Fin Función editar datos personales del usuario */
else
/* Función editar usuario, esta función recibe los datos post enviados desde el formulario editar usuario del archivo gestionar_usuario.js */
if ($_POST['funcion'] == 'editar_usuario') {
  $id_usuario = $_POST['id_usuario'];
  $nombre = $_POST['nombre'];
  $apellidos = $_POST['apellidos'];
  $identificacion = $_POST['identificacion'];
  $email = $_POST['email'];
  $contacto = $_POST['contacto'];
  $direccion = $_POST['direccion'];
  $contrasena = $_POST['contrasena'];
  $tipo = $_POST['tipo'];
  $usuario->editar_usuario($id_usuario, $nombre, $apellidos, $identificacion, $email, $contacto, $direccion, $contrasena, $tipo);
}
/* Fin Función editar usuario */
else
/* Función para buscar los datos del usuario, esta función realiza la consulta a la base de datos y trae los datos del usuario. */
if ($_POST['funcion'] == 'buscar_usuario') {
  $json = array();
  $usuario->obtener_datos($_POST['dato']);
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'nombre' => $objeto->nombre,
      'apellidos' => $objeto->apellidos,
      'email' => $objeto->email,
      'identificacion' => $objeto->identificacion,
      'tipo' => $objeto->nombre_tipo,
      'contacto' => $objeto->telefono,
      'direccion' => $objeto->direccion
    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN USUARIO.JS
  $jsonstring = json_encode($json[0]);
  echo $jsonstring;
  // FIN CODIGO
}
/* Fin Función buscar datos del usuario */
else
/* Función para capturar los datos del usuario, esta función realiza la consulta a la base de datos y trae los datos personales del usuario logueado. */
if ($_POST['funcion'] == 'capturar_datos') {
  $json = array();
  $id_usuario = $_POST['id_usuario'];
  $usuario->obtener_datos($id_usuario);
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'nombre' => $objeto->nombre,
      'apellidos' => $objeto->apellidos,
      'identificacion' => $objeto->identificacion,
      'email' => $objeto->email,
      'contacto' => $objeto->telefono,
      'direccion' => $objeto->direccion
    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN USUARIO.JS
  $jsonstring = json_encode($json[0]);
  echo $jsonstring;
  // FIN CODIGO
}
/* Fin Función editar solicitud */
else
/* Función para cambiar la contraseña del usuario, esta función recibe el id del usuario enviado desde el evento cambiar_clave del archivo gestionar_usuario.js */
if ($_POST['funcion'] == 'cambiar_clave') {
  $id_usuario = $_POST['id_usuario'];
  $clave_anterior = $_POST['clave_anterior'];
  $nueva_clave = $_POST['nueva_clave'];
  $usuario->cambio_clave($id_usuario, $clave_anterior, $nueva_clave);
}
/* Fin Función cambiar contraseña */
else
/* Función para buscar los datos del usuario, esta función realiza la consulta a la base de datos y trae los datos del usuario. */
if ($_POST['funcion'] == 'buscar_datos_usuarios') {
  $json = array();
  $usuario->buscador_usuarios();
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'id' => $objeto->id_usuario,
      'nombre' => $objeto->nombre,
      'apellidos' => $objeto->apellidos,
      'email' => $objeto->email,
      'identificacion' => $objeto->identificacion,
      'tipo' => $objeto->nombre_tipo,
      'contacto' => $objeto->telefono,
      'direccion' => $objeto->direccion,
      'contrasena' => $objeto->contrasena,
      'tipo_usuario' => $objeto->tipo_usu,
      'estatus' => $objeto->estatus_usu
    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN USUARIO.JS
  $jsonstring = json_encode($json);
  echo $jsonstring;
  // FIN CODIGO
}
/* Fin Función buscar datos del usuario*/
else
/* Función inhabilitar datos del usuario, esta función recibe el id del usuario enviado desde el evento inhabilitar del archivo gestionar_usuario.js */
if ($_POST['funcion'] == 'inhabilitar') {
  $id = $_POST['id'];
  $usuario->inhabilitar($id);
}
/* Fin Función inhabilitar */
else
/* Función habilitar datos del usuario, esta función recibe el id del usuario enviado desde el evento Habilitar del archivo gestionar_usuario.js . */
if ($_POST['funcion'] == 'habilitar') {
  $id = $_POST['id'];
  $usuario->habilitar($id);
}
/* Fin Función habilitar */
else
/* Función eliminar datos del usuario, esta función recibe el id del usuario enviado desde el evento eliminar del archivo gestionar_usuario.js . */
if ($_POST['funcion'] == 'eliminar') {
  $id = $_POST['id'];
  $usuario->eliminar($id);
}
/* Fin Función eliminar */
else
/* Función para seleccionarl usuario, trae los parametros y los proyecta en el formulario solicitud de servicio */
if ($_POST['funcion'] == 'select_usuario') {
  $usuario->select_usuario();
  $json = array();
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'id_usuario' => $objeto->id_usuario,
      'nombre' => $objeto->nombre,
      'apellido' => $objeto->apellidos
    );
  }
  $jsonstring = json_encode($json);
  echo $jsonstring;
}
/* Fin Función seleccionar usuario */
else
/* Función para seleccionar tecnico, trae los parametros y los proyecta en el formulario crear reporte de servicio */
if ($_POST['funcion'] == 'select_tecnico_usu') {
  $json = array();
  $usuario->select_tecnico_usu();
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'id' => $objeto->id_usuario,
      'nombre' => $objeto->nombre,
      'apellido' => $objeto->apellidos
    );
  }
  $jsonstring = json_encode($json);
  echo $jsonstring;
}
/* Fin Función seleccionar tecnico */
else
/* Función para contar el total de usuario, proyecta el total de los usuarios en el dashboard */
if ($_POST['funcion'] == 'total_usuarios') {
  $json = array();
  $usuario->total_usuarios();
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'total_usuarios' => $objeto->total_registro,
    );
  }
  $jsonstring = json_encode($json[0]);
  echo $jsonstring;
}
/* Fin Función total usuarios */
