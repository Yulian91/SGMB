<?php
// Codigo para activar la sesión en curso //
session_start();
// Ruta para acceder al modelo del solicitud.
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/solicitud.php';
$solicitud = new  Solicitud();

/* Función crear solicitud, esta función recibe los datos post enviados desde el formulario crear solicitud del archivo gestionar_solicitud.js */
if ($_POST['funcion'] == 'crear_solicitud') {
  $inventario = $_POST['inventario'];
  $tipo = $_POST['tipo'];
  $prioridad = $_POST['prioridad'];
  $usuario = $_POST['usuario'];
  $motivo = $_POST['motivo'];
  $solicitud->Crear_Solicitud($inventario, $tipo, $prioridad, $usuario, $motivo);
}
/* Fin Función crear solicitud */
else
/* Función editar solicitud, esta función recibe los datos post enviados desde el formulario editar solicitud del archivo gestionar_solicitud.js */
if ($_POST['funcion'] == 'editar_solicitud') {
  $id_solicitud = $_POST['id_solicitud'];
  $inventario = $_POST['inventario'];
  $tipo = $_POST['tipo'];
  $prioridad = $_POST['prioridad'];
  $usuario = $_POST['usuario'];
  $motivo = $_POST['motivo'];
  $solicitud->Editar_Solicitud($id_solicitud, $inventario, $tipo, $prioridad, $usuario, $motivo);
}
/* Fin Función editar solicitud */
else
/* Función para buscar los datos de la solicitud, esta función realiza la consulta a la base de datos y trae los datos de la solicitud. */
if ($_POST['funcion'] == 'buscar_datos_solicitud') {
  $solicitud->buscador_solicitudes();
  $json = array();
  foreach ($solicitud->objetos as $objeto) {
    $json[] = array(
      'id_solicitud' => $objeto->id_solicitud,
      'id_inventario' => $objeto->inventario,
      'fecha_solicitud' => $objeto->fecha_hora,
      'nombre_equipo' => $objeto->nombre_equipo,
      'marca_equipo' => $objeto->marca_equipo,
      'id_cliente' => $objeto->id_cliente,
      'nombre_cliente' => $objeto->nombre_cliente,
      'usuario_cliente' => $objeto->usuario_cli,
      'tipo_solicitud' => $objeto->tipo_sol,
      'prioridad' => $objeto->prioridad_sol,
      'motivo' => $objeto->motivo_servicio,
      'estatus_sol' => $objeto->estatus_sol,
      'id_tipo_sesion' => $_SESSION['id_tipo']

    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
  $jsonstring = json_encode($json);
  echo $jsonstring;
  // FIN CODIGO
}
/* Fin Función buscar solicitudes */
else
/* Función para buscar las solicitudes pendientes, esta función realiza la consulta a la base de datos y trae los datos de las solicitudes pendientes. */
if ($_POST['funcion'] == 'buscar_datos_solicitud_pend') {
  $solicitud->buscar_solicitudes_pend();
  $json = array();
  foreach ($solicitud->objetos as $objeto) {
    $json[] = array(
      'id_solicitud' => $objeto->id_solicitud,
      'id_inventario' => $objeto->inventario,
      'fecha_solicitud' => $objeto->fecha_hora,
      'nombre_equipo' => $objeto->nombre_equipo,
      'marca_equipo' => $objeto->marca_equipo,
      'nombre_cliente' => $objeto->nombre_cliente,
      'usuario_cliente' => $objeto->usuario_cli,
      'tipo_solicitud' => $objeto->tipo_sol,
      'prioridad' => $objeto->prioridad_sol,
      'motivo' => $objeto->motivo_servicio,
      'estatus_sol' => $objeto->estatus_sol,
      'id_tipo_sesion' => $_SESSION['id_tipo']

    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
  $jsonstring = json_encode($json);
  echo $jsonstring;
  // FIN CODIGO
}
/* Fin Función buscar solicitudes pendientes*/
else
/* Función para cambiar el estado de la solicitud a proceso, esta función recibe el id de la solicitud enviado desde el evento estado_proceso del archivo gestionar_solicitud.js */
if ($_POST['funcion'] == 'estado_proceso') {
  $id = $_POST['id'];
  $solicitud->estado_proceso($id);
}
/* Fin Función cambiar estado de la solicitud */
else
/* Función para reactivar una solicitud, esta función recibe el id de la solicitud enviado desde el evento estado_reactivar del archivo gestionar_solicitud.js */
if ($_POST['funcion'] == 'estado_reactivar') {
  $id = $_POST['id'];
  $solicitud->estado_reactivar($id);
}
/* Fin Función reactivar la solicitud */
else
/* Función para cerrar la solicitud, esta función recibe el id de la solicitud enviado desde el evento estado_cerrado del archivo gestionar_solicitud.js */
if ($_POST['funcion'] == 'estado_cerrado') {
  $id = $_POST['id'];
  $solicitud->estado_cerrado($id);
}
/* Fin Función para cerrar la solicitud*/
else
/* Función para cancelar la solicitud, esta función recibe el id de la solicitud enviado desde el evento inhabilitar del archivo gestionar_solicitud.js */
if ($_POST['funcion'] == 'cancelar_solicitud') {
  $id = $_POST['id'];
  $solicitud->estado_cancelar($id);
}
/* Fin Función cancelar la solicitud */
else
/* Función inhabilitar datos del pais, esta función recibe el id del pais enviado desde el evento inhabilitar del archivo gestionar_paises.js */
if ($_POST['funcion'] == 'num_solicitud') {
  $solicitud->num_solicitud();
  $json = array();
  foreach ($solicitud->objetos as $objeto) {
    $json[] = array(
      'no_solicitud' => $objeto->no_solicitud,
    );
  }
  $jsonstring = json_encode($json);
  echo $jsonstring;
}
/* Fin Función habilitar */
else
/* Función eliminar datos de la solicitud, esta función recibe el id de la solicitud enviado desde el evento eliminar del archivo gestionar_solicitud.js */
if ($_POST['funcion'] == 'eliminar') {
  $id = $_POST['id'];
  $solicitud->eliminar($id);
}
/* Fin Función eliminar */
else
/* Función para contar el total de clientes, proyecta el total de los clientes en el dashboard */
if ($_POST['funcion'] == 'total_solicitudes') {
  $json = array();
  $solicitud->total_solicitudes();
  foreach ($solicitud->objetos as $objeto) {
    $json[] = array(
      'total_solicitudes' => $objeto->total_registro,
    );
  }
  $jsonstring = json_encode($json[0]);
  echo $jsonstring;
}
/* Fin Función total clientes */
