<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/usuario.php';
$usuario = new  Usuario();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require '../vendor/autoload.php';

if ($_POST['funcion'] == 'verificar_datos') {
  $identificacion = $_POST['identificacion'];
  $email = $_POST['email'];
  $usuario->verificar_datos($identificacion, $email);
}

if ($_POST['funcion'] == 'recuperar_password') {
  $identificacion = $_POST['identificacion'];
  $email = $_POST['email'];
  $codigo = generar_cod(10);
  $usuario->remplazar($identificacion, $email, $codigo);
  //Create an instance; passing `true` enables exceptions
  $mail = new PHPMailer(true);

  try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp-mail.outlook.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'ardimal1991@hotmail.com';                     //SMTP username
    $mail->Password   = 'secret';                               //SMTP password del correo
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('ardimal1991@hotmail.com', 'Administrador H&S');
    $mail->addAddress($email);     //Add a recipient
    //$mail->addAddress('ellen@example.com');               //Name is optional
    //$mail->addReplyTo('info@example.com', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Restablecer Constraseña';
    $mail->Body    = 'Su nueva contraseña es: <b>' . $codigo . '</b>';
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    $mail->SMTPDebug = false;
    $mail->do_debug = false;
    $mail->send();
    echo 'enviado';
  } catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  }
}

function generar_cod($longitud)
{
  $key = '';
  $patron = '1234567890abcdefghijklmnñopqrstuvwxyz';
  $max = strlen($patron) - 1;
  for ($i = 0; $i < $longitud; $i++) {
    $key .= $patron{
      mt_rand(0, $max)};
  }
  return $key;
}
