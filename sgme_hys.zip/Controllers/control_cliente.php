<?php
// Codigo para activar la sesión en curso //
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/cliente.php'; // Ruta para acceder al modelo del cliente.
$cliente = new  Cliente();

/* Función crear cliente, esta función recibe los datos post enviados desde el formulario crear cliente del archivo gestionar_cliente.js . */
if ($_POST['funcion']=='crear_cliente') {
    $nombre = $_POST['nombre'];
    $nit = $_POST['nit'];
    $telefono = $_POST['telefono'];
    $tipo_contrato = $_POST['tipo_contrato'];
    $num_contrato = $_POST['num_contrato'];
    $direccion = $_POST['direccion'];
    $contacto = $_POST['contacto'];
    $email = $_POST['email'];
    $cliente->Crear_Cliente($nombre,$nit,$telefono,$tipo_contrato,$num_contrato,$direccion,$contacto,$email);
}
/* Fin Función crear cliente */
else
/* Función editar cliente, esta función recibe los datos post enviados desde el formulario editar cliente del archivo gestionar_cliente.js */
if ($_POST['funcion']=='editar_cliente') {
    $id_cliente = $_POST['id_cliente'];
    $nombre = $_POST['nombre'];
    $nit = $_POST['nit'];
    $telefono = $_POST['telefono'];
    $tipo_contrato = $_POST['tipo_contrato'];
    $num_contrato = $_POST['num_contrato'];
    $direccion = $_POST['direccion'];
    $contacto = $_POST['contacto'];
    $email = $_POST['email'];
    $cliente->editar_cliente($id_cliente,$nombre,$nit,$telefono,$tipo_contrato,$num_contrato,$direccion,$contacto,$email);
    
}
/* Fin Función editar cliente */
else
/* Función para buscar los datos del cliente, esta función realiza la consulta a la base de datos y trae los datos del cliente. */
if ($_POST['funcion']=='buscar_datos_cliente') {
    $json=array();
    $cliente->buscador_clientes();
    foreach ($cliente->objetos as $objeto) {
        $json[]=array(
            'id_cliente'=>$objeto->id_cliente,
            'fecha_registro'=>$objeto->fecha_reg,
            'nombre_cliente'=>$objeto->nombre_rz,
            'nit_cliente'=>$objeto->nit_cliente,
            'telefono_cliente'=>$objeto->telefono_cliente,
            'tipo_contrato'=>$objeto->tipo_contrato,
            'num_contrato'=>$objeto->num_contrato,
            'direccion_cliente'=>$objeto->direccion_ciudad,
            'email_cliente'=>$objeto->email_cliente,
            'nombre_contacto'=>$objeto->nombre_contacto,
            'estatus'=>$objeto->estatus_cliente
            
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}
/* Fin Función buscar datos del cliente*/
else
/* Función inhabilitar los datos del cliente, esta función recibe el id del cliente enviado desde el evento inhabilitar del archivo gestionar_cliente.js */
if ($_POST['funcion']=='inhabilitar') {
    $id = $_POST['id'];
    $cliente->inhabilitar($id);
}
/* Fin Función inahabilitar */
else
/* Función habilitar los datos del cliente, esta función recibe el id del cliente enviado desde el evento habilitar del archivo gestionar_cliente.js */
if ($_POST['funcion']=='habilitar') {
    $id = $_POST['id'];
    $cliente->habilitar($id);
}
/* Fin Función habilitar */
else
/* Función eliminar datos del cliente, esta función recibe el id del cliente enviado desde el evento eliminar del archivo gestionar_cliente.js */
if ($_POST['funcion']=='eliminar') {
    $id = $_POST['id'];
    $cliente->eliminar($id);
}
/* Fin Función eliminar */
else
/* Función para seleccionar el cliente, trae dos parametros y los proyecta en el formulario de agregar un equipo a un contrato de matto */
if ($_POST['funcion']=='select_cliente') {
    $cliente->select_cliente();
    $json = array();
    foreach ($cliente->objetos as $objeto) {
        $json[]=array(
            'id'=>$objeto->id_cliente,
            'nombre'=>$objeto->nombre_rz
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
/* Fin Función seleccionar cliente */
else
/* Función para seleccionar el contacto del cliente, trae dos parametros y los proyecta en el formulario de agregar un equipo a un contrato de matto */
if ($_POST['funcion']=='select_cliente_usu') {
    $cliente->select_cliente_usu();
    $json = array();
    foreach ($cliente->objetos as $objeto) {
        $json[]=array(
            'id'=>$objeto->contacto_usu,
            'nombre'=>$objeto->nombre,
            'apellido'=>$objeto->apellidos
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
/* Fin Función seleccionar el contacto del cliente */
else
/* Función para contar el total de clientes, proyecta el total de los clientes en el dashboard */
if ($_POST['funcion'] == 'total_clientes') {
  $json = array();
  $cliente->total_clientes();
  foreach ($cliente->objetos as $objeto) {
    $json[] = array(
      'total_clientes' => $objeto->total_registro,
    );
  }
  $jsonstring = json_encode($json[0]);
  echo $jsonstring;
}
/* Fin Función total clientes */