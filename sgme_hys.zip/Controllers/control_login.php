<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/usuario.php'; // Ruta para acceder al modelo del usuario.
session_start();
$user = $_POST['user']; 
$pass = $_POST['pass'];
$usuario = new Usuario();

/* Condicional, según el tipo de usuario, el sistema lo direcciona a la vista */

if (!empty($_SESSION['tipo_usu'])) {
  switch ($_SESSION['tipo_usu']) {
    case 1:
      header('Location: ../Views/Admin/Dashboard.php');
      break;

    case 2:
      header('Location: ../Views/Admin/Dashboard.php');
      break;

    case 3:
      header('Location: ../Views/Tecnico/tecn_principal.php');
      break;

    case 4:
      header('Location: ../Views/Cliente/Dashboard.php');
      break;
  }
}
// Fin del condicional if.
else {

  /* Código para realizar la consulta a la base de datos e ingresar al sistema */
  $usuario->Login($user, $pass);
  if (!empty($usuario->objetos)) {
    foreach ($usuario->objetos as $objeto) {
      $_SESSION['usuario'] = $objeto->id_usuario;
      $_SESSION['tipo_usu'] = $objeto->tipo_usu;
      $_SESSION['nombre'] = $objeto->nombre;
      $_SESSION['apellidos'] = $objeto->apellidos;
    }
    switch ($_SESSION['tipo_usu']) {
      case 1:
        header('Location: ../Views/Admin/Dashboard.php');
        break;

      case 2:
        header('Location: ../Views/Admin/Dashboard.php');
        break;

      case 3:
        header('Location: ../Views/Tecnico/tecn_principal.php');
        break;

      case 4:
        header('Location: ../Views/Cliente/Dashboard.php');
        break;
    }
  } else {
    header('Location: ../index.php');
  }
}
// Fin del condicional.
