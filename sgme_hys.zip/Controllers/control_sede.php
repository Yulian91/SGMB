<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/sede.php'; // Ruta para acceder al modelo del sede.
$sede = new  Sede();

/* Función crear sede, esta función recibe los datos post enviados desde el formulario crear sede del archivo gestionar_sedes.js */
if ($_POST['funcion']=='crear_sede') {
    $nombre = $_POST['nombre'];
    $sede->crear_Sede($nombre);
}
/* Fin Función crear sede */
else
/* Función editar sede, esta función recibe los datos post enviados desde el formulario editar sede del archivo gestionar_sedes.js */
if ($_POST['funcion']=='editar_sede') {
    $id_sede = $_POST['id_sede'];
    $nombre = $_POST['nombre'];
    $sede->editar_sede($id_sede,$nombre);
    
}
/* Fin Función editar sede */
else
/* Función para buscar los datos de la sede, esta función realiza la consulta a la base de datos y trae los datos de la sede. */
if ($_POST['funcion']=='buscar_datos_sede') {
    $json=array();
    $sede->buscador_sedes();
    foreach ($sede->objetos as $objeto) {
        $json[]=array(
            'id_sede'=>$objeto->id_sede,
            'nombre'=>$objeto->nombre_sede,
            'estatus'=>$objeto->estatus_sede
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}
/* Fin Función buscar datos de la sede*/
else
/* Función inhabilitar datos de la sede, esta función recibe el id de la sede enviado desde el evento inhabilitar del archivo gestionar_sedes.js */
if ($_POST['funcion']=='inhabilitar') {
    $id = $_POST['id'];
    $sede->inhabilitar($id);
}
/* Fin Función inhabilitar */
else
/* Función habilitar datos de la sede, esta función recibe el id de la sede enviado desde el evento Habilitar del archivo gestionar_sedes.js . */
if ($_POST['funcion']=='habilitar') {
    $id = $_POST['id'];
    $sede->habilitar($id);
}
/* Fin Función habilitar */
else
/* Función eliminar datos de la sede, esta función recibe el id de la sede enviado desde el evento eliminar del archivo gestionar_sedes.js . */
if ($_POST['funcion']=='eliminar') {
    $id = $_POST['id'];
    $sede->eliminar($id);
}
/* Fin Función eliminar */
else
/* Función para seleccionar la sede, trae dos parametros y los proyecta en el formulario agregar un equipo a un contrato de matto */
if ($_POST['funcion']=='select_sede') {
    $sede->select_sede();
    $json = array();
    foreach ($sede->objetos as $objeto) {
        $json[]=array(
            'id_sede'=>$objeto->id_sede,
            'nombre_sede'=>$objeto->nombre_sede
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
/* Fin Función seleccionar pais */

?>