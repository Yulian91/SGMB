<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/equipo.php'; // Ruta para acceder al modelo del cronograma.
$equipo = new  Equipo();

/* Función crear equipo, esta función recibe los datos post enviados desde el formulario crear equipo del archivo gestionar_equipo.js */
if ($_POST['funcion']=='crear_equipo') {
    $nombre_equipo = $_POST['nombre_equipo'];
    $n_activo = $_POST['n_activo'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $serie = $_POST['serie'];
    $pro_terc = $_POST['pro_terc'];
    $estado = $_POST['estado'];
    $garantia = $_POST['garantia'];
    $equipo->Crear_Equipo($nombre_equipo,$n_activo,$marca,$modelo,$serie,$pro_terc,$estado,$garantia);
}
/* Fin Función crear equipo */
else
/* Función editar equipo, esta función recibe los datos post enviados desde el formulario editar equipo del archivo gestionar_equipo.js */
if ($_POST['funcion']=='editar') {
    $id_editado = $_POST['id_editado'];
    $nombre_equipo = $_POST['nombre'];
    $n_activo = $_POST['n_activo'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $serie = $_POST['serie'];
    $pro_terc = $_POST['pro_terc'];
    $estado = $_POST['estado'];
    $garantia = $_POST['garantia'];
    $equipo->editar($id_editado,$nombre_equipo,$n_activo,$marca,$modelo,$serie,$pro_terc,$estado,$garantia);
    
}
/* Fin Función editar equipo */
else
/* Función para buscar los datos del equipo, esta función realiza la consulta a la base de datos y trae los datos del equipo. */
if ($_POST['funcion']=='buscar_datos_equipo') {
    $json=array();
    $equipo->buscador_equipos();
    foreach ($equipo->objetos as $objeto) {
        $json[]=array(
            'id_equipo'=>$objeto->id_equipo,
            'nombre'=>$objeto->nombre,
            'no_activo'=>$objeto->no_activo,
            'marca'=>$objeto->marca,
            'modelo'=>$objeto->modelo,
            'serie'=>$objeto->serie,
            'propio_tercero'=>$objeto->propio_tercero,
            'estado'=>$objeto->estado,
            'garantia'=>$objeto->garantia,
            'estatus'=>$objeto->estatus_eq
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}
/* Fin Función buscar datos equipo */
else
/* Función para arrendar un equipo, esta función recibe el id del equipo enviado desde el evento arrendar del archivo gestionar_equipo.js */
if ($_POST['funcion']=='arrendar') {
    $id_equipo = $_POST['id_equipo'];
    $equipo->arrendar($id_equipo);
}
/* Fin Función arrendar */
else
/* Función para sacar de arriendo un equipo, esta función recibe el id del equipo enviado desde el evento no_arrendar del archivo gestionar_equipo.js */
if ($_POST['funcion']=='no_arrendar') {
    $id = $_POST['id'];
    $equipo->no_arrendar($id);
}
/* Fin Función no arrendar */
else
/* Función para seleccionar el equipo, trae dos parametros y los proyecta en el formulario de agregar un equipo a un contrato de matto */
if ($_POST['funcion']=='select_equipo') {
    $equipo->select_equipo();
    $json = array();
    foreach ($equipo->objetos as $objeto) {
        $json[]=array(
            'id'=>$objeto->id_equipo,
            'nombre'=>$objeto->nombre,
            'modelo'=>$objeto->modelo,
            'serie'=>$objeto->serie
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
/* Fin Función seleccionar equipo */
else
/* Función eliminar datos del equipo, esta función recibe el id del equipo enviado desde el evento eliminar del archivo gestionar_equipo.js */
if ($_POST['funcion']=='eliminar_eq') {
    $id = $_POST['id'];
    $equipo->eliminar_eq($id);
}
/* Fin Función eliminar */
?>