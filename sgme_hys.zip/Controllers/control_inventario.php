<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Models/inventario.php'; // Ruta para acceder al modelo del cronograma.
$inventario = new  Inventario();

/* Función crear inventario, esta función recibe los datos post enviados desde el formulario crear inventario del archivo gestionar_inventario.js */
if ($_POST['funcion']=='crear_inventario') {
    $id_equipo = $_POST['id_equipo'];
    $frecuencia_mtto = $_POST['frecuencia_mtto'];
    $fijo_movil = $_POST['fijo_movil'];
    $cliente = $_POST['cliente'];
    $pais = $_POST['pais'];
    $ciudad = $_POST['ciudad'];
    $sede = $_POST['sede'];
    $area = $_POST['area'];
    $inventario->Crear_Inventario($id_equipo,$frecuencia_mtto,$fijo_movil,$cliente,$pais,$ciudad,$sede,$area);
}
/* Fin Función crear inventario */
else
/* Función editar inventario, esta función recibe los datos post enviados desde el formulario editar inventario del archivo gestionar_inventario.js */
if ($_POST['funcion']=='editar') {
    $id_editado = $_POST['id_editado'];
    $equipo = $_POST['equipo'];
    $frecuencia_mtto = $_POST['frecuencia_mtto'];
    $fijo_movil = $_POST['fijo_movil'];
    $cliente = $_POST['cliente'];
    $pais = $_POST['pais'];
    $ciudad = $_POST['ciudad'];
    $sede = $_POST['sede'];
    $area = $_POST['area'];
    $inventario->editar($id_editado,$equipo,$frecuencia_mtto,$fijo_movil,$cliente,$pais,$ciudad,$sede,$area);
}
/* Fin Función editar inventario */
else
/* Función para buscar los datos del inventario, esta función realiza la consulta a la base de datos y trae los datos del equipo que se encuentra en el inventario. */
if ($_POST['funcion']=='buscar_datos_inventario') {
    $json=array();
    $inventario->buscar_inventario();
    foreach ($inventario->objetos as $objeto) {
        $json[]=array(
            'id_inventario'=>$objeto->id_inventario,
            'fecha'=>$objeto->fecha_ingreso,
            'id_equipo'=>$objeto->equipo,
            'nombre_equipo'=>$objeto->nombre,
            'no_activo'=>$objeto->no_activo,
            'marca'=>$objeto->marca,
            'modelo'=>$objeto->modelo,
            'serie'=>$objeto->serie,
            'frecuencia'=>$objeto->frecuencia_matto,
            'fijo_movil'=>$objeto->fijo_movil,
            'id_cliente'=>$objeto->cliente,
            'nombre_cliente'=>$objeto->nombre_rz,
            'pais'=>$objeto->ubi_pais,
            'ciudad'=>$objeto->ubi_ciudad,
            'sede'=>$objeto->ubi_sede,
            'area'=>$objeto->ubi_area,
            'id_pais'=>$objeto->pais,
            'id_ciudad'=>$objeto->ciudad,
            'id_sede'=>$objeto->sede,
            'id_area'=>$objeto->area
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}
/* Fin Función buscar datos del inventario */
else
/* Función para seleccionar el equipo, trae dos parametros y los proyecta en el formulario del inventario */
if ($_POST['funcion']=='select_inventario') {
    $inventario->select_inventario();
    $json = array();
    foreach ($inventario->objetos as $objeto) {
        $json[]=array(
            'id'=>$objeto->id_inventario,
            'nombre_equipo'=>$objeto->nombre_equipo,
            'marca'=>$objeto->marca,
            'serie'=>$objeto->serie
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
/* Fin Función seleccionar equipo */
else
/* Función eliminar datos del equipo en el inventario, esta función recibe el id del equipo enviado desde el evento eliminar del archivo gestionar_inventario.js */
if ($_POST['funcion']=='eliminar_inv') {
    $id_inv = $_POST['id_inv'];
    $inventario->eliminar_inv($id_inv);
}
/* Fin Función eliminar */
else
/* Función para contar el total de clientes, proyecta el total de los clientes en el dashboard */
if ($_POST['funcion'] == 'total_equipos') {
  $json = array();
  $inventario->total_equipos();
  foreach ($inventario->objetos as $objeto) {
    $json[] = array(
      'total_equipos' => $objeto->total_registro,
    );
  }
  $jsonstring = json_encode($json[0]);
  echo $jsonstring;
}
/* Fin Función total clientes */
